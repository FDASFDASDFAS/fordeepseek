#pragma once

#include <cstdint>
#include <optional>
#include <utility>

namespace tw::runtime
{
    enum class StatusCode : std::uint8_t
    {
        Ok,
        Unsupported,
        Unavailable,
        InvalidArgument,
        InvalidState,
        StaleIdentity,
        WrongThread,
        BudgetExceeded,
        IoFailure,
        RuntimeFailure,
        UnsafeTeardown
    };

    enum class Subsystem : std::uint8_t
    {
        None,
        Lifecycle,
        Hooks,
        Configuration,
        Entities,
        Commands,
        Prediction,
        Rendering,
        Jobs,
        Features
    };

    struct Error final
    {
        StatusCode code{ StatusCode::Ok };
        Subsystem subsystem{ Subsystem::None };
        std::uint16_t operation{};
        long nativeCode{};

        [[nodiscard]] constexpr bool terminal() const noexcept
        {
            return code == StatusCode::UnsafeTeardown;
        }
    };

    class Status final
    {
    public:
        constexpr Status() noexcept = default;
        constexpr explicit Status(Error error) noexcept : error_(error) {}

        [[nodiscard]] static constexpr Status success() noexcept { return {}; }
        [[nodiscard]] static constexpr Status failure(Error error) noexcept { return Status{ error }; }
        [[nodiscard]] constexpr bool ok() const noexcept { return error_.code == StatusCode::Ok; }
        [[nodiscard]] constexpr explicit operator bool() const noexcept { return ok(); }
        [[nodiscard]] constexpr const Error& error() const noexcept { return error_; }

    private:
        Error error_{};
    };

    template <typename T>
    class Result final
    {
    public:
        [[nodiscard]] static Result success(T value) { return Result{ std::move(value) }; }
        [[nodiscard]] static Result failure(Error error) { return Result{ error }; }

        [[nodiscard]] bool ok() const noexcept { return value_.has_value(); }
        [[nodiscard]] explicit operator bool() const noexcept { return ok(); }
        [[nodiscard]] const T& value() const& { return *value_; }
        [[nodiscard]] T& value() & { return *value_; }
        [[nodiscard]] T&& value() && { return std::move(*value_); }
        [[nodiscard]] const Error& error() const noexcept { return error_; }

    private:
        explicit Result(T value) : value_(std::move(value)) {}
        explicit Result(Error error) : error_(error) {}

        std::optional<T> value_{};
        Error error_{ StatusCode::RuntimeFailure, Subsystem::None, 0, 0 };
    };
}
