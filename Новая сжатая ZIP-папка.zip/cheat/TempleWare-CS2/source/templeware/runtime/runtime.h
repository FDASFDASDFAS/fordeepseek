#pragma once

#include <Windows.h>
#include <atomic>
#include <chrono>
#include <cstdio>

#include "lifecycle.h"

namespace Runtime
{
    enum class LifecycleState : unsigned char
    {
        Dormant,
        Starting,
        InitializingRenderer,
        Active,
        StopRequested,
        RestoringGameState,
        DetachingCallbacks,
        DrainingCallbacks,
        ReleasingResources,
        Stopped,
        FailedPinned
    };

    enum class LifecycleError : unsigned char
    {
        None,
        DuplicateInstance,
        SingletonCreationFailed,
        StopEventCreationFailed,
        WorkerThreadCreationFailed,
        WindowMessageRegistrationFailed,
        WindowSubclassInstallFailed,
        WindowSubclassRemoveFailed,
        WindowThreadUnresponsive,
        RendererResourceInitializationFailed,
        RendererLockTimeout,
        PresentHookInitializationFailed,
        ComponentInitializationFailed,
        HookRemovalFailed,
        InitialHookDisableFailed,
        FinalHookDisableFailed,
        WndProcRestoreFailed,
        WndProcChainChanged,
        CallbackDrainFailed,
        MinHookUninitializeFailed,
        FinalizerCreationFailed,
        FinalizerWaitFailed,
        ManualMapReleaseFailed
    };

    inline std::atomic_bool unloadRequested{ false };
    inline std::atomic_bool shuttingDown{ false };
    inline std::atomic<LifecycleState> lifecycleState{ LifecycleState::Dormant };
    inline std::atomic<LifecycleError> lifecycleError{ LifecycleError::None };
    inline tw::runtime::CallbackGate callbackGate{};
    inline HANDLE stopEvent = nullptr;
    inline HANDLE singletonHandle = nullptr;

    inline const char* ToString(LifecycleState state)
    {
        switch (state)
        {
        case LifecycleState::Dormant: return "Dormant";
        case LifecycleState::Starting: return "Starting";
        case LifecycleState::InitializingRenderer: return "InitializingRenderer";
        case LifecycleState::Active: return "Active";
        case LifecycleState::StopRequested: return "StopRequested";
        case LifecycleState::RestoringGameState: return "RestoringGameState";
        case LifecycleState::DetachingCallbacks: return "DetachingCallbacks";
        case LifecycleState::DrainingCallbacks: return "DrainingCallbacks";
        case LifecycleState::ReleasingResources: return "ReleasingResources";
        case LifecycleState::Stopped: return "Stopped";
        case LifecycleState::FailedPinned: return "FailedPinned";
        }
        return "Unknown";
    }

    inline const char* ToString(LifecycleError error)
    {
        switch (error)
        {
        case LifecycleError::None: return "None";
        case LifecycleError::DuplicateInstance: return "DuplicateInstance";
        case LifecycleError::SingletonCreationFailed: return "SingletonCreationFailed";
        case LifecycleError::StopEventCreationFailed: return "StopEventCreationFailed";
        case LifecycleError::WorkerThreadCreationFailed: return "WorkerThreadCreationFailed";
        case LifecycleError::WindowMessageRegistrationFailed: return "WindowMessageRegistrationFailed";
        case LifecycleError::WindowSubclassInstallFailed: return "WindowSubclassInstallFailed";
        case LifecycleError::WindowSubclassRemoveFailed: return "WindowSubclassRemoveFailed";
        case LifecycleError::WindowThreadUnresponsive: return "WindowThreadUnresponsive";
        case LifecycleError::RendererResourceInitializationFailed: return "RendererResourceInitializationFailed";
        case LifecycleError::RendererLockTimeout: return "RendererLockTimeout";
        case LifecycleError::PresentHookInitializationFailed: return "PresentHookInitializationFailed";
        case LifecycleError::ComponentInitializationFailed: return "ComponentInitializationFailed";
        case LifecycleError::HookRemovalFailed: return "HookRemovalFailed";
        case LifecycleError::InitialHookDisableFailed: return "InitialHookDisableFailed";
        case LifecycleError::FinalHookDisableFailed: return "FinalHookDisableFailed";
        case LifecycleError::WndProcRestoreFailed: return "WndProcRestoreFailed";
        case LifecycleError::WndProcChainChanged: return "WndProcChainChanged";
        case LifecycleError::CallbackDrainFailed: return "CallbackDrainFailed";
        case LifecycleError::MinHookUninitializeFailed: return "MinHookUninitializeFailed";
        case LifecycleError::FinalizerCreationFailed: return "FinalizerCreationFailed";
        case LifecycleError::FinalizerWaitFailed: return "FinalizerWaitFailed";
        case LifecycleError::ManualMapReleaseFailed: return "ManualMapReleaseFailed";
        }
        return "Unknown";
    }

    inline bool CanTransition(LifecycleState from, LifecycleState to)
    {
        if (from == to)
            return true;
        if (from == LifecycleState::FailedPinned || from == LifecycleState::Stopped)
            return false;
        if (to == LifecycleState::FailedPinned)
            return true;

        switch (from)
        {
        case LifecycleState::Dormant: return to == LifecycleState::Starting;
        case LifecycleState::Starting: return to == LifecycleState::InitializingRenderer || to == LifecycleState::StopRequested;
        case LifecycleState::InitializingRenderer: return to == LifecycleState::Active || to == LifecycleState::StopRequested;
        case LifecycleState::Active: return to == LifecycleState::StopRequested;
        case LifecycleState::StopRequested: return to == LifecycleState::DetachingCallbacks;
        case LifecycleState::DetachingCallbacks: return to == LifecycleState::DrainingCallbacks;
        case LifecycleState::DrainingCallbacks: return to == LifecycleState::RestoringGameState;
        case LifecycleState::RestoringGameState: return to == LifecycleState::ReleasingResources;
        case LifecycleState::ReleasingResources: return to == LifecycleState::Stopped;
        case LifecycleState::Stopped:
        case LifecycleState::FailedPinned:
            return false;
        }
        return false;
    }

    inline void EmitDiagnostic(LifecycleState state, LifecycleError error)
    {
        char message[192]{};
        sprintf_s(message, "[TempleWare] lifecycle=%s error=%s\n", ToString(state), ToString(error));
        OutputDebugStringA(message);
    }

    inline void SetLifecycleState(LifecycleState state)
    {
        LifecycleState previous = lifecycleState.load(std::memory_order_acquire);
        for (;;)
        {
            if (!CanTransition(previous, state))
                return;
            if (previous == state || lifecycleState.compare_exchange_weak(previous, state, std::memory_order_acq_rel))
                break;
        }
        if (previous != state)
            EmitDiagnostic(state, lifecycleError.load(std::memory_order_acquire));
    }

    inline void Fail(LifecycleError error)
    {
        LifecycleError expected = LifecycleError::None;
        lifecycleError.compare_exchange_strong(expected, error, std::memory_order_acq_rel);
        lifecycleState.store(LifecycleState::FailedPinned, std::memory_order_release);
        EmitDiagnostic(LifecycleState::FailedPinned, lifecycleError.load(std::memory_order_acquire));
    }

    inline void SetError(LifecycleError error)
    {
        LifecycleError expected = LifecycleError::None;
        lifecycleError.compare_exchange_strong(expected, error, std::memory_order_acq_rel);
        EmitDiagnostic(lifecycleState.load(std::memory_order_acquire), lifecycleError.load(std::memory_order_acquire));
    }

    inline LifecycleState GetLifecycleState()
    {
        return lifecycleState.load(std::memory_order_acquire);
    }

    inline LifecycleError GetLifecycleError()
    {
        return lifecycleError.load(std::memory_order_acquire);
    }

    inline bool AcquireSingleton()
    {
        wchar_t name[64]{};
        swprintf_s(name, L"Local\\TempleWare.%lu", GetCurrentProcessId());

        SetLastError(ERROR_SUCCESS);
        HANDLE handle = CreateMutexW(nullptr, FALSE, name);
        if (handle == nullptr)
        {
            Fail(LifecycleError::SingletonCreationFailed);
            return false;
        }

        if (GetLastError() == ERROR_ALREADY_EXISTS)
        {
            CloseHandle(handle);
            Fail(LifecycleError::DuplicateInstance);
            return false;
        }

        singletonHandle = handle;
        return true;
    }

    inline void ReleaseSingleton()
    {
        if (singletonHandle != nullptr)
            CloseHandle(singletonHandle);
        singletonHandle = nullptr;
    }

    inline bool Initialize()
    {
        lifecycleError.store(LifecycleError::None, std::memory_order_release);
        SetLifecycleState(LifecycleState::Starting);
        unloadRequested.store(false, std::memory_order_release);
        shuttingDown.store(false, std::memory_order_release);

        if (!AcquireSingleton())
            return false;

        stopEvent = CreateEventW(nullptr, TRUE, FALSE, nullptr);

        if (stopEvent != nullptr)
            return true;

        stopEvent = nullptr;
        Fail(LifecycleError::StopEventCreationFailed);
        ReleaseSingleton();
        return false;
    }

    inline void RequestUnload()
    {
        unloadRequested.store(true, std::memory_order_release);
		shuttingDown.store(true, std::memory_order_release);
		callbackGate.closeFeatureAdmission();
        const LifecycleState state = GetLifecycleState();
        if (state == LifecycleState::Starting || state == LifecycleState::InitializingRenderer || state == LifecycleState::Active)
            SetLifecycleState(LifecycleState::StopRequested);
        if (stopEvent != nullptr)
            SetEvent(stopEvent);
    }

    inline bool ShouldUnload()
    {
        return unloadRequested.load(std::memory_order_acquire);
    }

    inline bool IsShuttingDown()
    {
        return shuttingDown.load(std::memory_order_acquire);
    }

    inline void BeginShutdown()
    {
        RequestUnload();
    }

    inline void SealCallbackGate()
    {
        callbackGate.sealAfterSourcesDetached();
    }

    inline DWORD WaitForUnload(DWORD timeout)
    {
        return stopEvent != nullptr ? WaitForSingleObject(stopEvent, timeout) : WAIT_FAILED;
    }

    class CallbackGuard
    {
    public:
        CallbackGuard() noexcept : lease_(callbackGate.enter()) {}
        ~CallbackGuard() = default;

        CallbackGuard(const CallbackGuard&) = delete;
        CallbackGuard& operator=(const CallbackGuard&) = delete;

        [[nodiscard]] bool FeatureAdmitted() const noexcept
        {
            return lease_ && lease_.featureAdmitted();
        }

    private:
        tw::runtime::CallbackGate::Lease lease_{};
    };

    inline DWORD WaitForCallbacks(DWORD timeout = 5000)
    {
        if (timeout == INFINITE)
        {
            callbackGate.waitForDrain();
            return WAIT_OBJECT_0;
        }
        return callbackGate.waitForDrain(std::chrono::milliseconds{ timeout }) ? WAIT_OBJECT_0 : WAIT_TIMEOUT;
    }

    inline void Shutdown()
    {
        if (stopEvent != nullptr)
            CloseHandle(stopEvent);

        stopEvent = nullptr;
    }
}
