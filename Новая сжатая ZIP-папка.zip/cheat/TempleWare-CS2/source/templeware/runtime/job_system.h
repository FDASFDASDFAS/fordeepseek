#pragma once

#include "result.h"

#include <condition_variable>
#include <cstddef>
#include <deque>
#include <functional>
#include <mutex>
#include <stop_token>
#include <thread>
#include <vector>

namespace tw::runtime
{
    class JobSystem final
    {
    public:
        using Job = std::function<void(std::stop_token)>;

        explicit JobSystem(std::size_t workerCount, std::size_t capacity);
        ~JobSystem();

        JobSystem(const JobSystem&) = delete;
        JobSystem& operator=(const JobSystem&) = delete;

        [[nodiscard]] Status submit(Job job);
        void stop() noexcept;
        [[nodiscard]] std::size_t pending() const noexcept;

    private:
        void run(std::stop_token token);

        const std::size_t capacity_;
        mutable std::mutex mutex_{};
        std::condition_variable_any available_{};
        std::deque<Job> queue_{};
        std::vector<std::jthread> workers_{};
        bool accepting_{ true };
    };
}
