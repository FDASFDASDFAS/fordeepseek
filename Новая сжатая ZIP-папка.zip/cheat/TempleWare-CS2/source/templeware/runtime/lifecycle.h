#pragma once

#include "result.h"

#include <array>
#include <atomic>
#include <chrono>
#include <condition_variable>
#include <cstddef>
#include <cstdint>
#include <mutex>

namespace tw::runtime
{
    enum class LifecycleState : std::uint8_t
    {
        Dormant,
        Starting,
        Active,
        StopRequested,
        DetachingCallbacks,
        DrainingCallbacks,
        RestoringState,
        ReleasingResources,
        Stopped,
        FailedPinned
    };

    [[nodiscard]] bool canTransition(LifecycleState from, LifecycleState to) noexcept;

    class LifecycleMachine final
    {
    public:
        [[nodiscard]] LifecycleState state() const noexcept;
        [[nodiscard]] Status transition(LifecycleState next) noexcept;
        [[nodiscard]] Status requestStop() noexcept;
        void failPinned(Error cause) noexcept;
        [[nodiscard]] Error firstFailure() const noexcept;

    private:
        std::atomic<LifecycleState> state_{ LifecycleState::Dormant };
        mutable std::mutex failureMutex_{};
        Error firstFailure_{};
    };

    using RollbackFunction = Status (*)(void*) noexcept;

    class RollbackLedger final
    {
    public:
        static constexpr std::size_t capacity = 64;

        [[nodiscard]] Status record(RollbackFunction function, void* context) noexcept;
        [[nodiscard]] Status rollback() noexcept;
        void commit() noexcept;
        [[nodiscard]] std::size_t size() const noexcept;

    private:
        struct Step final
        {
            RollbackFunction function{};
            void* context{};
        };

        std::array<Step, capacity> steps_{};
        std::size_t size_{};
        bool committed_{};
    };

    class CallbackGate final
    {
    public:
        class Lease final
        {
        public:
            Lease() noexcept = default;
            Lease(Lease&& other) noexcept;
            Lease& operator=(Lease&& other) noexcept;
            ~Lease();

            Lease(const Lease&) = delete;
            Lease& operator=(const Lease&) = delete;

            [[nodiscard]] explicit operator bool() const noexcept { return gate_ != nullptr; }
            [[nodiscard]] bool featureAdmitted() const noexcept { return featureAdmitted_; }

        private:
            friend class CallbackGate;
            Lease(CallbackGate* gate, bool admitted) noexcept : gate_(gate), featureAdmitted_(admitted) {}
            void release() noexcept;

            CallbackGate* gate_{};
            bool featureAdmitted_{};
        };

        [[nodiscard]] Lease enter() noexcept;
        void closeFeatureAdmission() noexcept;
        void sealAfterSourcesDetached() noexcept;
        void waitForDrain() noexcept;
        [[nodiscard]] bool waitForDrain(std::chrono::milliseconds timeout) noexcept;
        [[nodiscard]] std::size_t activeCount() const noexcept;

    private:
        void leave() noexcept;

        mutable std::mutex mutex_{};
        std::condition_variable drained_{};
        std::size_t active_{};
        bool featureAdmissionOpen_{ true };
        bool sealed_{};
    };
}
