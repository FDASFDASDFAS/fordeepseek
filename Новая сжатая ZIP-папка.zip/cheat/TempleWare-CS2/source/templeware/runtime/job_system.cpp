#include "job_system.h"

#include <utility>

namespace tw::runtime
{
    JobSystem::JobSystem(const std::size_t workerCount, const std::size_t capacity)
        : capacity_(capacity)
    {
        workers_.reserve(workerCount);
        for (std::size_t index = 0; index < workerCount; ++index)
            workers_.emplace_back([this](const std::stop_token token) { run(token); });
    }

    JobSystem::~JobSystem()
    {
        stop();
    }

    Status JobSystem::submit(Job job)
    {
        if (!job)
            return Status::failure({ StatusCode::InvalidArgument, Subsystem::Jobs, 1, 0 });
        {
            std::scoped_lock lock{ mutex_ };
            if (!accepting_)
                return Status::failure({ StatusCode::InvalidState, Subsystem::Jobs, 2, 0 });
            if (queue_.size() >= capacity_)
                return Status::failure({ StatusCode::BudgetExceeded, Subsystem::Jobs, 3, 0 });
            queue_.push_back(std::move(job));
        }
        available_.notify_one();
        return Status::success();
    }

    void JobSystem::stop() noexcept
    {
        {
            std::scoped_lock lock{ mutex_ };
            accepting_ = false;
            queue_.clear();
        }
        for (auto& worker : workers_)
            worker.request_stop();
        available_.notify_all();
        workers_.clear();
    }

    std::size_t JobSystem::pending() const noexcept
    {
        std::scoped_lock lock{ mutex_ };
        return queue_.size();
    }

    void JobSystem::run(const std::stop_token token)
    {
        while (!token.stop_requested())
        {
            Job job;
            {
                std::unique_lock lock{ mutex_ };
                available_.wait(lock, token, [this] { return !queue_.empty() || !accepting_; });
                if (token.stop_requested() || (!accepting_ && queue_.empty()))
                    return;
                if (queue_.empty())
                    continue;
                job = std::move(queue_.front());
                queue_.pop_front();
            }
            job(token);
        }
    }
}
