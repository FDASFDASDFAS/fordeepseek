#include "lifecycle.h"

#include <utility>

namespace tw::runtime
{
    bool canTransition(const LifecycleState from, const LifecycleState to) noexcept
    {
        if (from == to)
            return true;
        if (from == LifecycleState::FailedPinned || from == LifecycleState::Stopped)
            return false;
        if (to == LifecycleState::FailedPinned)
            return true;

        switch (from)
        {
        case LifecycleState::Dormant: return to == LifecycleState::Starting;
        case LifecycleState::Starting: return to == LifecycleState::Active || to == LifecycleState::StopRequested;
        case LifecycleState::Active: return to == LifecycleState::StopRequested;
        case LifecycleState::StopRequested: return to == LifecycleState::DetachingCallbacks;
        case LifecycleState::DetachingCallbacks: return to == LifecycleState::DrainingCallbacks;
        case LifecycleState::DrainingCallbacks: return to == LifecycleState::RestoringState;
        case LifecycleState::RestoringState: return to == LifecycleState::ReleasingResources;
        case LifecycleState::ReleasingResources: return to == LifecycleState::Stopped;
        case LifecycleState::Stopped:
        case LifecycleState::FailedPinned:
            return false;
        }
        return false;
    }

    LifecycleState LifecycleMachine::state() const noexcept
    {
        return state_.load(std::memory_order_acquire);
    }

    Status LifecycleMachine::transition(const LifecycleState next) noexcept
    {
        auto current = state();
        for (;;)
        {
            if (!canTransition(current, next))
                return Status::failure({ StatusCode::InvalidState, Subsystem::Lifecycle, 1, 0 });
            if (current == next || state_.compare_exchange_weak(current, next, std::memory_order_acq_rel))
                return Status::success();
        }
    }

    Status LifecycleMachine::requestStop() noexcept
    {
        for (;;)
        {
            auto current = state();
            if (current == LifecycleState::StopRequested ||
                current == LifecycleState::DetachingCallbacks ||
                current == LifecycleState::DrainingCallbacks ||
                current == LifecycleState::RestoringState ||
                current == LifecycleState::ReleasingResources ||
                current == LifecycleState::Stopped)
                return Status::success();
            if (current == LifecycleState::FailedPinned)
                return Status::failure(firstFailure());
            if (current != LifecycleState::Starting && current != LifecycleState::Active)
                return Status::failure({ StatusCode::InvalidState, Subsystem::Lifecycle, 2, 0 });
            if (state_.compare_exchange_weak(current, LifecycleState::StopRequested, std::memory_order_acq_rel))
                return Status::success();
        }
    }

    void LifecycleMachine::failPinned(const Error cause) noexcept
    {
        {
            std::scoped_lock lock{ failureMutex_ };
            if (firstFailure_.code == StatusCode::Ok)
                firstFailure_ = cause;
        }
        state_.store(LifecycleState::FailedPinned, std::memory_order_release);
    }

    Error LifecycleMachine::firstFailure() const noexcept
    {
        std::scoped_lock lock{ failureMutex_ };
        return firstFailure_;
    }

    Status RollbackLedger::record(const RollbackFunction function, void* const context) noexcept
    {
        if (committed_ || function == nullptr || size_ == capacity)
            return Status::failure({ StatusCode::InvalidState, Subsystem::Lifecycle, 3, 0 });
        steps_[size_++] = { function, context };
        return Status::success();
    }

    Status RollbackLedger::rollback() noexcept
    {
        Error firstError{};
        while (size_ != 0)
        {
            const Step step = steps_[--size_];
            const Status result = step.function(step.context);
            if (!result && firstError.code == StatusCode::Ok)
                firstError = result.error();
        }
        committed_ = true;
        return firstError.code == StatusCode::Ok ? Status::success() : Status::failure(firstError);
    }

    void RollbackLedger::commit() noexcept
    {
        size_ = 0;
        committed_ = true;
    }

    std::size_t RollbackLedger::size() const noexcept
    {
        return size_;
    }

    CallbackGate::Lease::Lease(Lease&& other) noexcept
        : gate_(std::exchange(other.gate_, nullptr)), featureAdmitted_(other.featureAdmitted_)
    {
    }

    CallbackGate::Lease& CallbackGate::Lease::operator=(Lease&& other) noexcept
    {
        if (this != &other)
        {
            release();
            gate_ = std::exchange(other.gate_, nullptr);
            featureAdmitted_ = other.featureAdmitted_;
        }
        return *this;
    }

    CallbackGate::Lease::~Lease()
    {
        release();
    }

    void CallbackGate::Lease::release() noexcept
    {
        if (gate_ != nullptr)
            gate_->leave();
        gate_ = nullptr;
    }

    CallbackGate::Lease CallbackGate::enter() noexcept
    {
        std::scoped_lock lock{ mutex_ };
        if (sealed_)
            return {};
        ++active_;
        return Lease{ this, featureAdmissionOpen_ };
    }

    void CallbackGate::closeFeatureAdmission() noexcept
    {
        std::scoped_lock lock{ mutex_ };
        featureAdmissionOpen_ = false;
    }

    void CallbackGate::sealAfterSourcesDetached() noexcept
    {
        std::scoped_lock lock{ mutex_ };
        featureAdmissionOpen_ = false;
        sealed_ = true;
    }

    void CallbackGate::waitForDrain() noexcept
    {
        std::unique_lock lock{ mutex_ };
        drained_.wait(lock, [this] { return active_ == 0; });
    }

    bool CallbackGate::waitForDrain(const std::chrono::milliseconds timeout) noexcept
    {
        std::unique_lock lock{ mutex_ };
        return drained_.wait_for(lock, timeout, [this] { return active_ == 0; });
    }

    std::size_t CallbackGate::activeCount() const noexcept
    {
        std::scoped_lock lock{ mutex_ };
        return active_;
    }

    void CallbackGate::leave() noexcept
    {
        std::scoped_lock lock{ mutex_ };
        if (active_ != 0 && --active_ == 0)
            drained_.notify_all();
    }
}
