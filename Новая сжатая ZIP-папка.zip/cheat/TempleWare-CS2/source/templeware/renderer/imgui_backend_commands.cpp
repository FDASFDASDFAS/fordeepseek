#include "imgui_backend_commands.h"

#include "../../../external/imgui/imgui.h"
#include "../menu/gui/fonts.h"

#include <type_traits>

namespace tw::renderer
{
    namespace
    {
        ImU32 color(const Color& value)
        {
            return ImGui::ColorConvertFloat4ToU32({ value.r, value.g, value.b, value.a });
        }
    }

    void submitImGui(const RenderFrame& frame)
    {
        ImDrawList* drawList = ImGui::GetBackgroundDrawList();
        for (const auto& command : frame.commands)
        {
            std::visit([drawList](const auto& value)
            {
                using Command = std::decay_t<decltype(value)>;
                if constexpr (std::is_same_v<Command, Line>)
                {
                    drawList->AddLine({ value.from.x, value.from.y }, { value.to.x, value.to.y }, color(value.color), value.thickness);
                }
                else if constexpr (std::is_same_v<Command, Rectangle>)
                {
                    if (value.filled)
                        drawList->AddRectFilled({ value.minimum.x, value.minimum.y }, { value.maximum.x, value.maximum.y }, color(value.color));
                    else
                        drawList->AddRect({ value.minimum.x, value.minimum.y }, { value.maximum.x, value.maximum.y }, color(value.color), 0.0f, 0, value.thickness);
                }
                else if constexpr (std::is_same_v<Command, Circle>)
                {
                    if (value.filled)
                        drawList->AddCircleFilled({ value.center.x, value.center.y }, value.radius, color(value.color));
                    else
                        drawList->AddCircle({ value.center.x, value.center.y }, value.radius, color(value.color), 0, value.thickness);
                }
                else if constexpr (std::is_same_v<Command, Text>)
                {
                    ImVec2 position{ value.position.x, value.position.y };
                    ImFont* const font = value.size > 0.0f ? fonts::Esp() : ImGui::GetFont();
                    const float fontSize = value.size > 0.0f ? value.size : ImGui::GetFontSize();
                    if (value.centered)
                        position.x -= font->CalcTextSizeA(fontSize, FLT_MAX, 0.0f, value.value.c_str()).x * 0.5f;
                    drawList->AddText(font, fontSize, position, color(value.color), value.value.c_str());
                }
            }, command);
        }
    }
}
