#pragma once

#include <cstdint>
#include <memory>
#include <mutex>
#include <string>
#include <variant>
#include <vector>

namespace tw::renderer
{
    struct Point final { float x{}; float y{}; };
    struct Color final { float r{}; float g{}; float b{}; float a{ 1.0f }; };

    struct Line final
    {
        Point from{};
        Point to{};
        Color color{};
        float thickness{ 1.0f };
    };

    struct Rectangle final
    {
        Point minimum{};
        Point maximum{};
        Color color{};
        float thickness{ 1.0f };
        bool filled{};
    };

    struct Circle final
    {
        Point center{};
        float radius{};
        Color color{};
        float thickness{ 1.0f };
        bool filled{};
    };

    struct Text final
    {
        Point position{};
        Color color{};
        std::string value{};
        bool centered{};
        // 0 keeps the overlay's default font. Anything else selects the small
        // ESP face, which is rasterised at exactly that size.
        float size{};
    };

    using DrawCommand = std::variant<Line, Rectangle, Circle, Text>;

    struct RenderFrame final
    {
        std::uint64_t sessionEpoch{};
        std::uint64_t deviceGeneration{};
        std::uint64_t sequence{};
        std::vector<DrawCommand> commands{};
    };

    class FramePublication final
    {
    public:
        void publish(RenderFrame frame);
        [[nodiscard]] std::shared_ptr<const RenderFrame> consume() const noexcept;
        void invalidate(std::uint64_t sessionEpoch, std::uint64_t deviceGeneration);

    private:
        mutable std::mutex mutex_{};
        std::shared_ptr<const RenderFrame> frame_{ std::make_shared<const RenderFrame>() };
    };

    class BackendGeneration final
    {
    public:
        [[nodiscard]] std::uint64_t current() const noexcept;
        [[nodiscard]] std::uint64_t onResourcesCreated() noexcept;
        void onBeforeResize() noexcept;
        [[nodiscard]] bool resourcesValid() const noexcept;

    private:
        mutable std::mutex mutex_{};
        std::uint64_t generation_{};
        bool valid_{};
    };
}
