#include "render_commands.h"

#include <utility>

namespace tw::renderer
{
    void FramePublication::publish(RenderFrame frame)
    {
        auto complete = std::make_shared<const RenderFrame>(std::move(frame));
        std::scoped_lock lock{ mutex_ };
        frame_ = std::move(complete);
    }

    std::shared_ptr<const RenderFrame> FramePublication::consume() const noexcept
    {
        std::scoped_lock lock{ mutex_ };
        return frame_;
    }

    void FramePublication::invalidate(const std::uint64_t sessionEpoch, const std::uint64_t deviceGeneration)
    {
        publish(RenderFrame{ sessionEpoch, deviceGeneration });
    }

    std::uint64_t BackendGeneration::current() const noexcept
    {
        std::scoped_lock lock{ mutex_ };
        return generation_;
    }

    std::uint64_t BackendGeneration::onResourcesCreated() noexcept
    {
        std::scoped_lock lock{ mutex_ };
        valid_ = true;
        return ++generation_;
    }

    void BackendGeneration::onBeforeResize() noexcept
    {
        std::scoped_lock lock{ mutex_ };
        valid_ = false;
    }

    bool BackendGeneration::resourcesValid() const noexcept
    {
        std::scoped_lock lock{ mutex_ };
        return valid_;
    }
}
