#pragma once

#include "render_commands.h"

namespace tw::renderer
{
    void submitImGui(const RenderFrame& frame);
}
