#include "shell.h"
#include "styling.h"
#include "fonts.h"

#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <Windows.h>

#include <cstdio>
#include <string>
#include <vector>

static std::string s_capturingId;

struct KeybindReg
{
    int*  key;
    bool* value;
};
static std::vector<KeybindReg> s_registry;

// Keys are stored as Win32 virtual-key codes, which is also how the ImGui
// win32 backend on this build indexes io.KeysDown.
static const char* KeyToLabel(int key) noexcept
{
    switch (key)
    {
    case VK_LSHIFT:
    case VK_RSHIFT:
    case VK_SHIFT:    return "SHF";
    case VK_LMENU:
    case VK_RMENU:
    case VK_MENU:     return "ALT";
    case VK_LCONTROL:
    case VK_RCONTROL:
    case VK_CONTROL:  return "CTR";
    case VK_LBUTTON:  return "M1";
    case VK_RBUTTON:  return "M2";
    case VK_MBUTTON:  return "M3";
    case VK_XBUTTON1: return "M4";
    case VK_XBUTTON2: return "M5";
    case VK_SPACE:    return "SPC";
    case VK_DELETE:   return "DEL";
    case VK_TAB:      return "TAB";
    case VK_CAPITAL:  return "CAP";
    default: break;
    }
    if (key >= 'A' && key <= 'Z')
    {
        static char buf[2];
        buf[0] = static_cast<char>(key);
        buf[1] = '\0';
        return buf;
    }
    if (key >= '0' && key <= '9')
    {
        static char buf[2];
        buf[0] = static_cast<char>(key);
        buf[1] = '\0';
        return buf;
    }
    if (key >= VK_F1 && key <= VK_F12)
    {
        static char buf[4];
        std::snprintf(buf, sizeof(buf), "F%d", 1 + (key - VK_F1));
        return buf;
    }
    return "?";
}

static int ScanPressedKey() noexcept
{
    for (int k = 'A'; k <= 'Z'; ++k)
        if (ImGui::IsKeyPressed(k, false)) return k;
    for (int k = '0'; k <= '9'; ++k)
        if (ImGui::IsKeyPressed(k, false)) return k;
    for (int k = VK_F1; k <= VK_F12; ++k)
        if (ImGui::IsKeyPressed(k, false)) return k;

    if (ImGui::IsKeyPressed(VK_SHIFT,   false)) return VK_SHIFT;
    if (ImGui::IsKeyPressed(VK_MENU,    false)) return VK_MENU;
    if (ImGui::IsKeyPressed(VK_CONTROL, false)) return VK_CONTROL;
    if (ImGui::IsKeyPressed(VK_TAB,     false)) return VK_TAB;
    if (ImGui::IsKeyPressed(VK_CAPITAL, false)) return VK_CAPITAL;
    if (ImGui::IsKeyPressed(VK_SPACE,   false)) return VK_SPACE;

    if (ImGui::IsMouseClicked(ImGuiMouseButton_Middle)) return VK_MBUTTON;
    if (ImGui::IsMouseClicked(3))                       return VK_XBUTTON1;
    if (ImGui::IsMouseClicked(4))                       return VK_XBUTTON2;

    return 0;
}

static bool KeyWentDown(int key) noexcept
{
    switch (key)
    {
    case VK_LBUTTON:  return ImGui::IsMouseClicked(ImGuiMouseButton_Left);
    case VK_RBUTTON:  return ImGui::IsMouseClicked(ImGuiMouseButton_Right);
    case VK_MBUTTON:  return ImGui::IsMouseClicked(ImGuiMouseButton_Middle);
    case VK_XBUTTON1: return ImGui::IsMouseClicked(3);
    case VK_XBUTTON2: return ImGui::IsMouseClicked(4);
    default:          return ImGui::IsKeyPressed(key, false);
    }
}

namespace ksd
{

void DrawKeybindButton(const char* id, int* key, bool* value, float rowY) noexcept
{
    if (value)
        s_registry.push_back({ key, value });

    const bool capturing = !s_capturingId.empty() && s_capturingId == id;

    if (capturing)
    {
        if (ImGui::IsKeyPressed(VK_ESCAPE, false))
        {
            s_capturingId.clear();
        }
        else if (ImGui::IsKeyPressed(VK_DELETE, false))
        {
            *key = 0;
            s_capturingId.clear();
        }
        else
        {
            const int pressed = ScanPressedKey();
            if (pressed != 0)
            {
                *key = pressed;
                s_capturingId.clear();
            }
        }
    }

    constexpr float btnW     = 26.f;
    constexpr float btnH     = 11.f;
    constexpr float fontSize = 9.f;
    const float     btnX = ksd::PanelRightX() - btnW;
    const float     btnY = rowY + 1.f;
    const ImRect    btnBb(ImVec2(btnX, btnY), ImVec2(btnX + btnW, btnY + btnH));

    const bool hovered = btnBb.Contains(ImGui::GetMousePos()) && ksd::PopUpsAreClosed();
    const bool clicked = hovered && ImGui::IsMouseReleased(ImGuiMouseButton_Left);

    if (clicked)
    {
        if (!capturing)
            s_capturingId = id;
        else
            s_capturingId.clear();
    }

    ImDrawList* dl = ImGui::GetWindowDrawList();

    char label[16];
    if (capturing)
        std::snprintf(label, sizeof(label), "[...]");
    else if (*key == 0)
        std::snprintf(label, sizeof(label), "[-]");
    else
        std::snprintf(label, sizeof(label), "[%s]", KeyToLabel(*key));

    const ImVec2 tsz = fonts::Verdana()->CalcTextSizeA(fontSize, FLT_MAX, 0.f, label);
    dl->AddText(fonts::Verdana(), fontSize,
        btnBb.Min + ImVec2((btnW - tsz.x) * 0.5f, (btnH - tsz.y) * 0.5f),
        capturing ? style::rgba(220, 220, 220) : style::rgba(160, 160, 160),
        label);
}

void Keybind(const char* labelText, int* key, bool special) noexcept
{
    constexpr float itemHeight = 14.0f;
    const ImVec2 drawPos = ksd::CursorPos();
    ImGui::GetWindowDrawList()->AddText(fonts::Verdana(), fonts::kUiSize,
        ImVec2(drawPos.x + 20.0f, drawPos.y + 1.0f),
        special ? style::col::textSpecial() : style::col::text(), labelText);
    ksd::AddItem(ImVec2(150.0f, itemHeight));

    char id[24];
    std::snprintf(id, sizeof(id), "##key_%p", static_cast<void*>(key));
    DrawKeybindButton(id, key, nullptr, drawPos.y);
}

void ProcessKeybinds() noexcept
{
    const bool capturing = !s_capturingId.empty();
    for (const KeybindReg& e : s_registry)
    {
        if (!capturing && *e.key != 0 && KeyWentDown(*e.key))
            *e.value = !*e.value;
    }
    s_registry.clear();
}

}
