#include "fonts.h"

#include <string>

namespace
{
	ImFont* g_Verdana = nullptr;
	ImFont* g_VerdanaBold = nullptr;
	ImFont* g_TabLetter = nullptr;
	ImFont* g_Brand = nullptr;
	ImFont* g_Esp = nullptr;
	ImFont* g_Fallback = nullptr;

	ImFont* LoadTtfFromFile(ImFontAtlas* atlas, const char* path, float sizePx, ImFontConfig* cfg, const ImWchar* ranges)
	{
		if (!path || path[0] == '\0')
			return nullptr;
		return atlas->AddFontFromFileTTF(path, sizePx, cfg, ranges);
	}
}

namespace fonts
{
	void Init(ImGuiIO& io) noexcept
	{
		static const ImWchar ranges[] = { 0x0020, 0x00FF, 0x2122, 0x2122, 0 };

		const std::string verdanaPath = "C:\\Windows\\Fonts\\verdana.ttf";
		const std::string verdanaBoldPath = "C:\\Windows\\Fonts\\verdanab.ttf";
		// The wordmark wants a lighter face than the rest of the menu. Segoe UI
		// Light ships with every supported Windows, but the load is still
		// guarded below and falls back to regular Verdana, which is thinner
		// than the bold face the wordmark used to borrow.
		const std::string segoeLightPath = "C:\\Windows\\Fonts\\segoeuil.ttf";

		ImFontConfig uiCfg;
		uiCfg.OversampleH = uiCfg.OversampleV = 1;
		uiCfg.PixelSnapH = true;

		g_Verdana = LoadTtfFromFile(io.Fonts, verdanaPath.c_str(), kUiSize, &uiCfg, ranges);
		g_VerdanaBold = LoadTtfFromFile(io.Fonts, verdanaBoldPath.c_str(), kUiSize, &uiCfg, ranges);
		if (!g_VerdanaBold)
			g_VerdanaBold = g_Verdana;

		// Display sizes: oversample so the curves stay smooth, and let the
		// glyphs sit on subpixel positions so centring is not quantised.
		ImFontConfig displayCfg;
		displayCfg.OversampleH = 2;
		displayCfg.OversampleV = 2;
		displayCfg.PixelSnapH = false;

		g_TabLetter = LoadTtfFromFile(io.Fonts, verdanaBoldPath.c_str(), kTabLetterSize, &displayCfg, ranges);
		g_Brand     = LoadTtfFromFile(io.Fonts, segoeLightPath.c_str(),  kBrandSize,     &displayCfg, ranges);
		if (!g_Brand)
			g_Brand = LoadTtfFromFile(io.Fonts, verdanaPath.c_str(), kBrandSize, &displayCfg, ranges);

		// The ESP draws over the game, not over the menu's flat panels, so it
		// keeps the pixel snapping that stops small glyphs smearing.
		g_Esp = LoadTtfFromFile(io.Fonts, verdanaPath.c_str(), kEspSize, &uiCfg, ranges);

		if (!g_Verdana)
		{
			g_Fallback = io.Fonts->AddFontDefault();
			g_Verdana = g_Fallback;
			g_VerdanaBold = g_Fallback;
		}
		if (!g_TabLetter)
			g_TabLetter = g_VerdanaBold;
		if (!g_Brand)
			g_Brand = g_Verdana;
		if (!g_Esp)
			g_Esp = g_Verdana;
	}

	ImFont* Verdana() noexcept { return g_Verdana ? g_Verdana : ImGui::GetFont(); }
	ImFont* VerdanaBold() noexcept { return g_VerdanaBold ? g_VerdanaBold : Verdana(); }
	ImFont* TabLetter() noexcept { return g_TabLetter ? g_TabLetter : VerdanaBold(); }
	ImFont* Brand() noexcept { return g_Brand ? g_Brand : VerdanaBold(); }
	ImFont* Esp() noexcept { return g_Esp ? g_Esp : Verdana(); }

	ImVec2 CalcUiTextSize(const char* text) noexcept
	{
		return Verdana()->CalcTextSizeA(kUiSize, FLT_MAX, 0.f, text);
	}
}
