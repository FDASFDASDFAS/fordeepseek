#include "shell.h"
#include "styling.h"
#include "fonts.h"

#include <algorithm>
#include <cmath>
#include <cstring>
#include <vector>

static constexpr float kMenuW        = 620.f;
static constexpr float kMenuH        = 540.f;
static constexpr float kHeaderH      = 34.f;
static constexpr float kTabH         = 30.f;
static constexpr float kContentX     = 16.f;
static constexpr float kContentY     = 82.f;
static constexpr float kContentPadR  = 16.f;
static constexpr float kContentPadB  = 16.f;
static constexpr float kItemSpacingY = 4.f;
static constexpr float kRollDuration = 0.12f;
// Wordmark underline: seconds per breath, how far it dims at the trough, how
// tall the hairline is, and how far it runs past the wordmark on each side.
static constexpr float kBrandBarPeriod = 2.60f;
static constexpr float kBrandBarFloor  = 0.30f;
static constexpr float kBrandBarHeight = 1.00f;
static constexpr float kBrandBarPad    = 46.00f;
static constexpr float kTabGlowDuration = 0.10f;

// Wordmark hue cycle. kBrandHueCycle is the seconds per full sweep;
// kBrandHueSpread is how much of the spectrum sits inside the word at once, so
// the letters read as one gradient sliding through it rather than as eight
// unrelated colours. Saturation is held below 1 to match the muted chrome.
static constexpr float kBrandHueCycle  = 6.0f;
static constexpr float kBrandHueSpread = 0.55f;
static constexpr float kBrandSat       = 0.62f;

struct ShellState
{
    ImVec2 windowPos  = {};
    ImVec2 windowSize = { kMenuW, kMenuH };
    int    currentTab = 0;
    int    prevTab    = -1;

    float  rollProgress    = 1.f;
    float  rollStartOffset = 0.f;
    float  contentOffsetY  = 0.f;
    bool   contentClipPushed = false;

    ksd::ChildState*  activeChild = nullptr;
    std::unordered_map<std::string, ksd::ChildState> children;
    std::vector<ksd::ChildState*> frameChildren;

    std::string selectedItem;
    std::unordered_map<std::string, bool> itemActive;
    std::unordered_map<int, float> tabGlowProgress;
    bool blockInput = false;
    bool interactive = true;
    bool menuDragActive  = false;
    ImVec2 menuDragOffset = {};

    std::string scrollDragId;
    float scrollDragGrab = 0.f;

    ImVec2 menuPos     = {};
    bool   menuPosInit = false;
};

static ShellState g;

static std::string ChildDisplayName(const char* name)
{
    std::string s(name);
    const auto hash = s.find('#');
    if (hash != std::string::npos)
        s = s.substr(0, hash);
    return s;
}

static void RefreshWindowRect() noexcept
{
    g.windowPos  = ImGui::GetWindowPos();
    g.windowSize = ImGui::GetWindowSize();
}

static void ComputeChildLayout(ksd::ChildState& c)
{
    const ImVec2 boundsMin = g.windowPos
        + ImVec2(kContentX - 1.f, kContentY - 1.f + g.contentOffsetY);
    const ImVec2 boundsSize = ImVec2(
        g.windowSize.x - kContentX - kContentPadR,
        g.windowSize.y - kContentY - kContentPadB);

    const ImVec2 minSize = ImVec2(
        (boundsSize.x - 2.f) * 0.224f,
        (boundsSize.y - 2.f) * 0.134f);
    const ImVec2 step = ImVec2(
        (boundsSize.x - minSize.x - 2.f) / 9.f,
        (boundsSize.y - minSize.y - 2.f) / 10.f);

    c.pos  = boundsMin + ImVec2(c.xPos * step.x, c.yPos * step.y);
    c.size = ImVec2(minSize.x + c.xSize * step.x, minSize.y + c.ySize * step.y);
}

static bool IsInside(const ImVec2& p, const ImVec2& min, const ImVec2& size) noexcept
{
    return p.x > min.x && p.y > min.y
        && p.x < min.x + size.x && p.y < min.y + size.y;
}

static bool IsMouseOverChildWidgetArea(const ImVec2& mouse) noexcept
{
    for (const ksd::ChildState* child : g.frameChildren)
    {
        const ImVec2 clipMin(child->pos.x + 2.f,                child->pos.y + 4.f);
        const ImVec2 clipMax(child->pos.x + child->size.x - 15.f, child->pos.y + child->size.y - 3.f);
        if (mouse.x > clipMin.x && mouse.y > clipMin.y &&
            mouse.x < clipMax.x && mouse.y < clipMax.y)
            return true;
    }
    return false;
}

static bool IsMouseOverSidebarTab(const ImVec2& mouse) noexcept
{
    return mouse.x >= g.windowPos.x + 10.f && mouse.x < g.windowPos.x + g.windowSize.x - 10.f &&
        mouse.y >= g.windowPos.y + kHeaderH && mouse.y < g.windowPos.y + kHeaderH + kTabH;
}

static bool IsMenuDragZone(const ImVec2& mouse) noexcept
{
    const ImRect topBar(g.windowPos, g.windowPos + ImVec2(g.windowSize.x, kHeaderH));
    if (topBar.Contains(mouse))
        return true;

    const ImRect content(
        g.windowPos + ImVec2(kContentX - 1.f, kContentY - 1.f),
        g.windowPos + ImVec2(g.windowSize.x - kContentPadR, g.windowSize.y - kContentPadB));
    if (!content.Contains(mouse))
        return false;
    return !IsMouseOverChildWidgetArea(mouse);
}

static void HandleMainWindowDrag() noexcept
{
    if (g.blockInput || !g.selectedItem.empty() || ksd::AnyComboOpen())
    {
        g.menuDragActive = false;
        return;
    }
    const ImVec2 mouse = ImGui::GetMousePos();
    if (ImGui::IsMouseClicked(ImGuiMouseButton_Left))
    {
        if (IsMenuDragZone(mouse) && !IsMouseOverSidebarTab(mouse))
        {
            g.menuDragActive = true;
            g.menuDragOffset = mouse - g.windowPos;
        }
        else
        {
            g.menuDragActive = false;
        }
    }
    if (!g.menuDragActive)
        return;
    if (!ImGui::IsMouseDown(ImGuiMouseButton_Left))
    {
        g.menuDragActive = false;
        return;
    }
    g.menuPos = mouse - g.menuDragOffset;
}

// A hairline under the wordmark that breathes: the whole bar brightens and dims
// as one, rather than a wave travelling across it. Two mirrored gradients fade
// it out at both ends so it reads as an underline and not as a cut-off rule.
static void DrawBrandBreath(ImDrawList* dl, ImVec2 barMin, ImVec2 barMax)
{
    if (barMax.x - barMin.x <= 2.f)
        return;

    const float accentR = std::clamp(vars::colorAccent[0], 0.f, 1.f);
    const float accentG = std::clamp(vars::colorAccent[1], 0.f, 1.f);
    const float accentB = std::clamp(vars::colorAccent[2], 0.f, 1.f);
    const float accentA = std::clamp(vars::colorAccent[3], 0.f, 1.f);

    // Cosine rather than sine so the cycle starts at the dim end and eases
    // through both turning points instead of snapping at the peak.
    const float breath = 0.5f - 0.5f * std::cos(
        6.2831853f * static_cast<float>(ImGui::GetTime()) / kBrandBarPeriod);
    const float level = kBrandBarFloor + (1.f - kBrandBarFloor) * breath;

    const int barAlpha = static_cast<int>(
        static_cast<float>(style::menuAlpha) * accentA * level);
    if (barAlpha <= 0)
        return;

    const int r = static_cast<int>(accentR * 255.f);
    const int g = static_cast<int>(accentG * 255.f);
    const int b = static_cast<int>(accentB * 255.f);
    const ImU32 core = style::rgba(r, g, b, barAlpha);
    const ImU32 edge = style::rgba(r, g, b, 0);

    const float mid = (barMin.x + barMax.x) * 0.5f;
    style::drawGradientH(dl, barMin, ImVec2(mid, barMax.y), edge, core);
    style::drawGradientH(dl, ImVec2(mid, barMin.y), barMax, core, edge);
}

static void DrawTabGlow(ImDrawList* dl, ImVec2 center, float progress)
{
    const float eased = progress * progress * (3.f - 2.f * progress);
    const float accentA = std::clamp(vars::colorAccent[3], 0.f, 1.f);
    const int   perLayer = static_cast<int>(
        11.f * eased * accentA * (static_cast<float>(style::menuAlpha) / 255.f));
    if (perLayer <= 0)
        return;

    const int ar = static_cast<int>(std::clamp(vars::colorAccent[0], 0.f, 1.f) * 255.f);
    const int ag = static_cast<int>(std::clamp(vars::colorAccent[1], 0.f, 1.f) * 255.f);
    const int ab = static_cast<int>(std::clamp(vars::colorAccent[2], 0.f, 1.f) * 255.f);

    const int   layers    = 16;
    const float maxRadius = 26.f * (0.4f + 0.6f * eased);
    for (int i = layers; i >= 1; --i)
    {
        const float r = maxRadius * (static_cast<float>(i) / static_cast<float>(layers));
        dl->AddCircleFilled(center, r, IM_COL32(ar, ag, ab, perLayer), 28);
    }
}

// Draws text one glyph at a time so each can take its own hue. ImGui does no
// kerning, so the per-glyph advances sum to exactly the width CalcTextSizeA
// reports for the whole string — the centring the caller computed still holds.
static void DrawRainbowText(ImDrawList* dl, ImFont* font, float fontSize,
                            ImVec2 pos, const char* text, int alpha)
{
    const std::size_t length = std::strlen(text);
    if (length == 0 || alpha <= 0)
        return;

    const float phase = static_cast<float>(ImGui::GetTime()) / kBrandHueCycle;
    for (std::size_t i = 0; i < length; ++i)
    {
        const char glyph[2] = { text[i], '\0' };
        const float along = length > 1
            ? static_cast<float>(i) / static_cast<float>(length - 1)
            : 0.f;

        float hue = phase - along * kBrandHueSpread;
        hue -= std::floor(hue);

        float r = 0.f, g = 0.f, b = 0.f;
        ImGui::ColorConvertHSVtoRGB(hue, kBrandSat, 1.f, r, g, b);
        dl->AddText(font, fontSize, pos,
            IM_COL32(static_cast<int>(r * 255.f), static_cast<int>(g * 255.f),
                     static_cast<int>(b * 255.f), alpha), glyph);

        pos.x += font->CalcTextSizeA(fontSize, FLT_MAX, 0.f, glyph).x;
    }
}

static void DrawMainChrome(ImDrawList* dl, ImVec2 pos, ImVec2 size)
{
    const float  topY = 6.f;
    const ImVec2 top(pos.x, pos.y + topY);

    dl->AddRectFilled(top, pos + size, style::col::windowBase());

    dl->AddRectFilled(top, pos + size, style::glass(18, 18, 22, style::glassWindow));
    dl->AddRectFilled(top, pos + ImVec2(size.x, kHeaderH), style::glass(12, 12, 15, 0.72f));

    // Lowercase and drawn in a light face: the name reads as a wordmark, not as
    // a shouted label. fonts::Brand() is rasterised at exactly kBrandSize.
    static constexpr const char* kBrand = "dork.cat";
    ImFont* brandFont = fonts::Brand();
    constexpr float brandSize = fonts::kBrandSize;
    const ImVec2 brandText = brandFont->CalcTextSizeA(brandSize, FLT_MAX, 0.f, kBrand);
    // The wordmark sits a touch above centre to leave room for the underline.
    const ImVec2 brandPos(
        std::round(pos.x + (size.x - brandText.x) * 0.5f),
        std::round(pos.y + 8.f + (kHeaderH - 14.f - brandText.y) * 0.5f));
    if (vars::rainbowTitle)
        DrawRainbowText(dl, brandFont, brandSize, brandPos, kBrand, style::menuAlpha);
    else
        dl->AddText(brandFont, brandSize, brandPos, style::accentU32(), kBrand);

    const float barY = std::round(brandPos.y + brandText.y + 2.f);
    const float barHalfWidth = brandText.x * 0.5f + kBrandBarPad;
    const float barCentre = pos.x + size.x * 0.5f;
    DrawBrandBreath(dl,
        ImVec2(barCentre - barHalfWidth, barY),
        ImVec2(barCentre + barHalfWidth, barY + kBrandBarHeight));

    dl->AddLine(pos + ImVec2(2.f, kHeaderH), pos + ImVec2(size.x - 2.f, kHeaderH), style::col::separator());
    dl->AddLine(pos + ImVec2(10.f, kHeaderH + kTabH), pos + ImVec2(size.x - 10.f, kHeaderH + kTabH), style::col::separator());

    const ImU32 frame = style::col::outline();
    dl->AddRectFilled(top,                              pos + ImVec2(2.f, size.y),          frame);
    dl->AddRectFilled(pos + ImVec2(size.x - 2.f, topY), pos + size,                         frame);
    dl->AddRectFilled(pos + ImVec2(2.f, size.y - 2.f),  pos + ImVec2(size.x - 2.f, size.y), frame);

}

static void DrawChildPanelFill(ImDrawList* dl, const ksd::ChildState& c)
{
    dl->AddRectFilled(c.pos, c.pos + c.size, style::col::panel());
}

static void DrawChildBorderAndTitle(ImDrawList* dl, const ksd::ChildState& c)
{
    const ImVec2 p = c.pos;
    const ImVec2 s = c.size;
    const ImU32  outer = style::col::widgetBorder();
    const ImU32  inner = style::col::childBorder(c.resizing);

    float labelW = 0.f;
    if (!c.displayName.empty())
        labelW = fonts::VerdanaBold()->CalcTextSizeA(
            fonts::kUiSize, FLT_MAX, 0.f, c.displayName.c_str()).x;

    const float gapStart = 10.f;
    const float gapEnd   = 16.f + labelW;

    dl->AddLine(p,                          p + ImVec2(0.f,        s.y),        outer);
    dl->AddLine(p + ImVec2(0.f, s.y - 1.f), p + ImVec2(s.x,        s.y - 1.f), outer);
    dl->AddLine(p + ImVec2(s.x - 1.f, 0.f), p + ImVec2(s.x - 1.f, s.y),        outer);
    dl->AddLine(p,                          p + ImVec2(gapStart,   0.f),        outer);
    dl->AddLine(p + ImVec2(gapEnd, 0.f),    p + ImVec2(s.x,        0.f),        outer);

    dl->AddLine(p + ImVec2(1.f, 1.f),        p + ImVec2(1.f,        s.y - 1.f), inner);
    dl->AddLine(p + ImVec2(1.f, s.y - 2.f),  p + ImVec2(s.x - 1.f,  s.y - 2.f), inner);
    dl->AddLine(p + ImVec2(s.x - 2.f, 1.f),  p + ImVec2(s.x - 2.f,  s.y - 1.f), inner);
    dl->AddLine(p + ImVec2(1.f, 1.f),        p + ImVec2(gapStart,   1.f),       inner);
    dl->AddLine(p + ImVec2(gapEnd, 1.f),     p + ImVec2(s.x - 1.f,  1.f),       inner);

    if (!c.displayName.empty())
    {
        const float ty = p.y - fonts::kUiSize * 0.5f;
        dl->AddText(fonts::VerdanaBold(), fonts::kUiSize,
            ImVec2(p.x + 14.f, ty + 1.f), style::rgba(15, 15, 15), c.displayName.c_str());
        dl->AddText(fonts::VerdanaBold(), fonts::kUiSize,
            ImVec2(p.x + 13.f, ty),       style::col::textTitle(),  c.displayName.c_str());
    }
}

static void UpdateRollAnimation() noexcept
{
    if (g.rollProgress >= 1.f)
    {
        g.contentOffsetY = 0.f;
        return;
    }
    const float dt = ImGui::GetIO().DeltaTime;
    g.rollProgress = std::min(g.rollProgress + dt / kRollDuration, 1.f);
    const float t     = g.rollProgress;
    const float eased = 1.f - (1.f - t) * (1.f - t);
    g.contentOffsetY  = g.rollStartOffset * (1.f - eased);
}

static void ApplyChildScroll(ksd::ChildState& c) noexcept
{
    const ImVec2 base = c.pos + ImVec2(22.f, 23.f);
    c.cursor        = base;
    c.appliedScroll = 0.f;
    if (c.scrollRatio < 0.f || c.contentHeight <= c.size.y + 1.f)
        return;
    const float overflow = c.contentHeight - c.size.y;
    const float offset   = overflow * std::clamp(c.scrollRatio, 0.f, 1.f);
    c.cursor.y      = base.y - offset;
    c.appliedScroll = offset;
}

namespace ksd {

void SetInteractive(bool interactive) noexcept
{
    g.interactive = interactive;
    g.blockInput  = !interactive;
    if (!interactive)
    {
        g.menuDragActive = false;
        g.scrollDragId.clear();
    }
}

bool Interactive() noexcept { return g.interactive; }

void ResetChildScrollStates() noexcept
{
    for (auto& [_, child] : g.children)
    {
        child.scrollRatio    = -1.f;
        child.contentBottomY = 0.f;
    }
}

void BeginMain() noexcept
{
    if (!g.menuPosInit)
    {
        const ImVec2 display = ImGui::GetIO().DisplaySize;
        g.menuPos     = ImVec2(display.x * 0.5f - kMenuW * 0.5f, display.y * 0.5f - kMenuH * 0.5f);
        g.menuPosInit = true;
    }

    if (g.prevTab != -1 && g.currentTab != g.prevTab)
    {
        const int dir     = (g.currentTab > g.prevTab) ? 1 : -1;
        g.rollStartOffset = static_cast<float>(dir) * kMenuH;
        g.rollProgress    = 0.f;
        g.contentOffsetY  = g.rollStartOffset;

        ksd::CloseAllPopups();
        g.selectedItem.clear();
        g.itemActive.clear();
    }
    g.prevTab = g.currentTab;

    if (!ImGui::IsMouseDown(ImGuiMouseButton_Left))
        g.selectedItem.clear();

    UpdateRollAnimation();
    ksd::ProcessKeybinds();

    HandleMainWindowDrag();

    ImGui::SetNextWindowSize(ImVec2(kMenuW, kMenuH), ImGuiCond_Always);
    ImGui::SetNextWindowPos(g.menuPos,               ImGuiCond_Always);

    constexpr ImGuiWindowFlags flags =
        ImGuiWindowFlags_NoTitleBar        |
        ImGuiWindowFlags_NoMove            |
        ImGuiWindowFlags_NoResize          |
        ImGuiWindowFlags_NoScrollbar       |
        ImGuiWindowFlags_NoScrollWithMouse |
        ImGuiWindowFlags_NoCollapse;

    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding,    ImVec2(0.f, 0.f));
    ImGui::PushStyleVar(ImGuiStyleVar_WindowBorderSize, 0.f);
    ImGui::PushStyleColor(ImGuiCol_WindowBg, ImVec4(0.f, 0.f, 0.f, 0.f));
    ImGui::Begin("##TempleWareMain", nullptr, flags);

    RefreshWindowRect();
    g.frameChildren.clear();
    g.contentClipPushed = false;

    DrawMainChrome(ImGui::GetWindowDrawList(), g.windowPos, g.windowSize);
}

void EndMain() noexcept
{
    if (g.contentClipPushed)
    {
        ImGui::PopClipRect();
        ImGui::GetWindowDrawList()->PopClipRect();
        g.contentClipPushed = false;
    }
    ImGui::End();
    ImGui::PopStyleColor();
    ImGui::PopStyleVar(2);
    g.activeChild = nullptr;
}

void BlurRegion(const ImVec2& min, const ImVec2& max) noexcept
{
    // No live back-buffer blur on this ImGui build; popups get an opaque base
    // so they read the same as the reference menu.
    ImGui::GetForegroundDrawList()->AddRectFilled(min, max, style::col::windowBase());
}

bool TabButton(const char* label, int* selected, int num, int total, bool legitTab, float slotWidthPx) noexcept
{
    ImDrawList* dl = ImGui::GetWindowDrawList();

    if (legitTab)
    {
        const float panelW = g.activeChild ? g.activeChild->size.x : 535.f;
        const float panelH = g.activeChild ? g.activeChild->size.y : 66.f;
        const ImVec2 base  = g.activeChild ? g.activeChild->pos : g.windowPos;

        const bool  grouped = slotWidthPx > 0.f;
        const float slotW   = grouped ? slotWidthPx : panelW / static_cast<float>(total);
        const float xOff    = grouped ? 10.f : 0.f;

        const int    idx     = std::min(num, total - 1);
        const ImVec2 slotPos = base + ImVec2(xOff + slotW * static_cast<float>(idx), 0.f);
        const ImVec2 sz(slotW, panelH);
        const ImRect bb(slotPos, slotPos + sz);

        const bool hovered = bb.Contains(ImGui::GetMousePos()) && !g.blockInput;
        const bool pressed = hovered && ImGui::IsMouseReleased(ImGuiMouseButton_Left);
        if (pressed) *selected = num;

        const ImU32 col = (*selected == num) ? style::col::tabActive()
                        : hovered            ? style::col::tabHover()
                        :                      style::col::tabIdle();

        // The reference build rasterises an SVG here; this port draws the label
        // with the UI font instead, keeping the same slot metrics.
        const ImVec2 ts = fonts::VerdanaBold()->CalcTextSizeA(fonts::kUiSize, FLT_MAX, 0.f, label);
        dl->AddText(fonts::VerdanaBold(), fonts::kUiSize,
            ImVec2(slotPos.x + (sz.x - ts.x) * 0.5f, slotPos.y + (sz.y - ts.y) * 0.5f),
            col, label);
        return pressed;
    }

    const int   tabCount = std::max(total, 1);
    const float tabsW = g.windowSize.x - 20.f;
    const float slotW = tabsW / static_cast<float>(tabCount);
    const ImVec2 slotPos = g.windowPos + ImVec2(10.f + slotW * static_cast<float>(num), kHeaderH);
    const ImRect bb(slotPos, slotPos + ImVec2(slotW, kTabH));

    const bool hovered = bb.Contains(ImGui::GetMousePos()) && !g.blockInput;
    const bool pressed = hovered && ImGui::IsMouseReleased(ImGuiMouseButton_Left);
    if (pressed) *selected = num;

    const bool isActive = (*selected == num);

    ImU32 iconCol;
    if (isActive)
        iconCol = style::accentU32();
    else if (hovered)
        iconCol = style::accentU32(static_cast<int>(115.f * static_cast<float>(style::menuAlpha) / 255.f));
    else
        iconCol = style::col::tabIdle();

    if (hovered || isActive)
        dl->AddRectFilled(slotPos + ImVec2(2.f, 3.f), slotPos + ImVec2(slotW - 2.f, kTabH - 2.f),
            style::glass(42, 42, 48, isActive ? 0.36f : 0.20f));

    ImFont* font = fonts::VerdanaBold();
    const ImVec2 ts = font->CalcTextSizeA(fonts::kUiSize, FLT_MAX, 0.f, label);
    dl->AddText(font, fonts::kUiSize,
        ImVec2(std::round(slotPos.x + (slotW - ts.x) * 0.5f),
               std::round(slotPos.y + (kTabH - ts.y) * 0.5f)),
        iconCol, label);

    if (isActive)
        dl->AddRectFilled(slotPos + ImVec2(12.f, kTabH - 2.f),
            slotPos + ImVec2(slotW - 12.f, kTabH), style::accentU32());

    return pressed;
}

bool BeginChild(const char* name, GridRect grid, bool) noexcept
{
    ksd::ChildState& c = g.children[name];
    if (!c.init)
    {
        c.name        = name;
        c.displayName = ChildDisplayName(name);
        c.init        = true;
    }

    c.xPos    = grid.x;
    c.yPos    = grid.y;
    c.xSize   = grid.w;
    c.ySize   = grid.h;
    c.dragging  = false;
    c.resizing  = false;

    RefreshWindowRect();
    ComputeChildLayout(c);
    g.frameChildren.push_back(&c);

    if (!g.contentClipPushed)
    {
        const ImVec2 cMin(g.windowPos.x + kContentX - 1.f,
                          g.windowPos.y + kContentY - 14.f);
        const ImVec2 cMax(g.windowPos.x + g.windowSize.x - kContentPadR,
                          g.windowPos.y + g.windowSize.y - kContentPadB);
        ImGui::GetWindowDrawList()->PushClipRect(cMin, cMax, true);
        ImGui::PushClipRect(cMin, cMax, true);
        g.contentClipPushed = true;
    }

    DrawChildPanelFill(ImGui::GetWindowDrawList(), c);

    g.activeChild = &c;
    ApplyChildScroll(c);

    const ImVec2 clipMin(c.pos.x + 2.f,          c.pos.y + 4.f);
    const ImVec2 clipMax(c.pos.x + c.size.x - 15.f, c.pos.y + c.size.y - 3.f);
    ImGui::PushClipRect(clipMin, clipMax, true);
    return true;
}

void EndChild() noexcept
{
    if (!g.activeChild)
        return;

    ksd::ChildState& c = *g.activeChild;
    c.prevCursor   = c.cursor;
    c.prevCursor.y += 8.f;
    const float contentBottom = c.prevCursor.y + c.appliedScroll;
    c.contentBottomY = contentBottom;
    c.contentHeight  = contentBottom - c.pos.y;

    const float maxY       = c.pos.y + c.size.y;
    const bool  needsScroll = contentBottom > maxY;
    if (!needsScroll)
        c.scrollRatio = -1.f;

    ImGui::PopClipRect();
    ksd::RenderPendingPopups();

    RefreshWindowRect();
    ComputeChildLayout(c);

    if (needsScroll)
    {
        if (c.scrollRatio < 0.f)
            c.scrollRatio = 0.f;

        const float overflow = contentBottom - maxY;
        const float scrollH  = c.size.y / ((contentBottom - c.pos.y) / c.size.y);
        const float range    = c.size.y - scrollH;
        const float trackTop = c.pos.y + 3.f;
        const float thumbH   = scrollH - 6.f;
        const ImVec2 mouse   = ImGui::GetMousePos();

        const float  thumbTop = trackTop + range * c.scrollRatio;
        const ImRect trackBb(
            ImVec2(c.pos.x + c.size.x - 7.f, c.pos.y + 1.f),
            ImVec2(c.pos.x + c.size.x - 1.f, c.pos.y + c.size.y - 1.f));
        const ImRect thumbBb(
            ImVec2(c.pos.x + c.size.x - 6.f, thumbTop),
            ImVec2(c.pos.x + c.size.x - 2.f, thumbTop + thumbH));

        if (g.interactive && g.scrollDragId.empty() && ImGui::IsMouseClicked(ImGuiMouseButton_Left) && trackBb.Contains(mouse))
        {
            g.scrollDragGrab = thumbBb.Contains(mouse) ? (mouse.y - thumbTop) : (thumbH * 0.5f);
            g.scrollDragId   = c.name;
            g.menuDragActive = false;
        }
        if (g.scrollDragId == c.name)
        {
            if (ImGui::IsMouseDown(ImGuiMouseButton_Left) && range > 0.f)
                c.scrollRatio = std::clamp((mouse.y - g.scrollDragGrab - trackTop) / range, 0.f, 1.f);
            else
                g.scrollDragId.clear();
        }

        const float offset = range * c.scrollRatio;

        ImDrawList* dl = ImGui::GetWindowDrawList();
        dl->AddRectFilled(
            ImVec2(c.pos.x + c.size.x - 7.f, c.pos.y + 1.f),
            ImVec2(c.pos.x + c.size.x - 1.f, c.pos.y + c.size.y - 1.f),
            style::col::gray40());
        dl->AddRectFilled(
            ImVec2(c.pos.x + c.size.x - 6.f, trackTop + offset),
            ImVec2(c.pos.x + c.size.x - 2.f, trackTop + offset + thumbH),
            style::col::gray65());

        // An open dropdown owns the wheel — otherwise the popup and the panel
        // underneath it both scroll on the same input.
        if (g.interactive && !AnyComboOpen()
            && IsInside(mouse, c.pos, c.size) && ImGui::GetIO().MouseWheel != 0.f)
        {
            c.scrollRatio = std::clamp(
                c.scrollRatio - ImGui::GetIO().MouseWheel * (20.f / overflow), 0.f, 1.f);
        }
    }

    DrawChildBorderAndTitle(ImGui::GetWindowDrawList(), c);
    g.activeChild = nullptr;
}

ImVec2 CursorPos() noexcept
{
    return g.activeChild ? g.activeChild->cursor : ImGui::GetWindowPos();
}

void AddItem(const ImVec2& size, bool comboSpacing) noexcept
{
    if (!g.activeChild) return;
    ksd::ChildState& c = *g.activeChild;
    c.prevCursor = c.cursor;
    c.cursor.y  += size.y + (comboSpacing ? 2.f : kItemSpacingY);
}

float ContentWidth() noexcept
{
    if (!g.activeChild) return 200.f;
    return std::clamp(g.activeChild->size.x - 90.f, 63.f, 202.f);
}

ImVec2 WindowPos()  noexcept { return g.windowPos; }
ImVec2 WindowSize() noexcept { return g.windowSize; }

float PanelRightX() noexcept
{
    if (!g.activeChild) return 0.f;
    return g.activeChild->pos.x + g.activeChild->size.x - 17.f;
}

float PanelBottomY() noexcept
{
    if (!g.activeChild) return 0.f;
    return g.activeChild->pos.y + g.activeChild->size.y - 15.f;
}

bool IsPopupBlocking()                     noexcept { return !g.selectedItem.empty(); }
bool ItemActive(const char* id)            noexcept { return g.itemActive[id]; }
void SetItemActive(const char* id, bool v) noexcept { g.itemActive[id] = v; }
const char* SelectedItem()                 noexcept { return g.selectedItem.c_str(); }
void SetSelectedItem(const char* id)       noexcept { g.selectedItem = id ? id : ""; }
bool PopUpsAreClosed()                     noexcept { return g.interactive && !ksd::AnyComboOpen(); }
int& CurrentTab()                          noexcept { return g.currentTab; }

bool ButtonBehavior(const char* id, ImRect bb, bool returnOnRelease) noexcept
{
    const bool hovered = bb.Contains(ImGui::GetMousePos());
    const bool clicked = returnOnRelease
        ? (hovered && ImGui::IsMouseReleased(ImGuiMouseButton_Left))
        : (hovered && ImGui::IsMouseClicked(ImGuiMouseButton_Left));

    if (!ksd::PopUpsAreClosed() || (!g.selectedItem.empty() && g.selectedItem != id))
        return false;

    if (hovered && clicked && !ItemActive(id) && g.selectedItem.empty())
    {
        SetItemActive(id, true);
        SetSelectedItem(id);
        return true;
    }

    if (!ImGui::IsMouseDown(ImGuiMouseButton_Left) && ItemActive(id))
    {
        SetItemActive(id, false);
        SetSelectedItem("");
    }

    return hovered && clicked;
}

}
