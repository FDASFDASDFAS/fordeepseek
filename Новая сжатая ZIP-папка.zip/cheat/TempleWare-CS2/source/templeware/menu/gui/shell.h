#pragma once

#ifndef IMGUI_DEFINE_MATH_OPERATORS
#define IMGUI_DEFINE_MATH_OPERATORS
#endif

#include "../../../../external/imgui/imgui.h"
#include "../../../../external/imgui/imgui_internal.h"

#include <string>
#include <unordered_map>

namespace ksd
{
	struct GridRect
	{
		float x = 0.f;
		float y = 0.f;
		float w = 3.f;
		float h = 10.f;
	};

	// Grid cells do not tile: a child's pixel height is a fixed minimum size
	// *plus* its grid height, so a child placed directly at the previous
	// panel's y + h overlaps it by that minimum. Stacked panels must leave this
	// many grid units between them. It is the ratio of the two layout
	// constants in ComputeChildLayout (0.134 / 0.0866), which is also where the
	// menu's 0 / 3.85 / 7.7 thirds come from.
	inline constexpr float kStackedPanelGap = 1.5473f;

	struct ChildState
	{
		std::string name;
		std::string displayName;
		float xPos = 0.f;
		float yPos = 0.f;
		float xSize = 3.f;
		float ySize = 10.f;
		bool init = false;
		bool dragging = false;
		bool resizing = false;
		ImVec2 dragClickOffset = {};
		float scrollRatio = -1.f;
		ImVec2 cursor = {};
		ImVec2 prevCursor = {};
		ImVec2 pos = {};
		ImVec2 size = {};
		float contentHeight = 0.f;
		float contentBottomY = 0.f;
		float appliedScroll = 0.f;
	};

	void BeginMain() noexcept;
	void EndMain() noexcept;
	void BlurRegion(const ImVec2& min, const ImVec2& max) noexcept;
	void ResetChildScrollStates() noexcept;
	bool TabButton(const char* label, int* selected, int num, int total, bool legitTab = false, float slotWidthPx = 0.f) noexcept;
	bool BeginChild(const char* name, GridRect grid = {}, bool legitChild = false) noexcept;
	void EndChild() noexcept;

	// Drives the fade-in/out and gates every widget while the menu is closing.
	void  SetInteractive(bool interactive) noexcept;
	bool  Interactive() noexcept;

	ImVec2 CursorPos() noexcept;
	void AddItem(const ImVec2& size, bool comboSpacing = false) noexcept;
	float ContentWidth() noexcept;
	ImVec2 WindowPos() noexcept;
	ImVec2 WindowSize() noexcept;
	float  PanelRightX() noexcept;
	float  PanelBottomY() noexcept;

	bool IsPopupBlocking() noexcept;
	bool ItemActive(const char* id) noexcept;
	void SetItemActive(const char* id, bool active) noexcept;
	const char* SelectedItem() noexcept;
	void SetSelectedItem(const char* id) noexcept;
	bool PopUpsAreClosed() noexcept;

	bool ButtonBehavior(const char* id, ImRect bb, bool returnOnRelease = false) noexcept;

	int& CurrentTab() noexcept;

	bool Button(const char* label, const ImVec2& size = ImVec2(0.f, 0.f)) noexcept;
	bool ListBox(const char* id, int* selected, const char* const* items, int count) noexcept;
	void InputText(const char* id, char* buffer, int bufferSize) noexcept;

	// Widgets
	bool Checkbox(const char* label, bool* v, bool special = false) noexcept;
	bool CheckboxKeybind(const char* label, bool* v, int* keybind, bool special = false) noexcept;
	void Keybind(const char* label, int* keybind, bool special = false) noexcept;

	void SliderInt(const char* label, int* v, int v_min, int v_max, const char* format = nullptr, int remove = 0) noexcept;
	void SliderFloat(const char* label, float* v, float v_min, float v_max, const char* format = nullptr, float scale = 0.1f) noexcept;

	bool SingleSelect(const char* label, int* current, const char* const* items, int count, float width = 0.f, bool borderless = false, const char* const* icons = nullptr) noexcept;
	bool MultiSelect(const char* label, int* flags, const char* const* items, int count) noexcept;
	void Label(const char* label, bool special = false) noexcept;
	// Word-wrapped, dimmed body copy for notes that do not fit a single line.
	void LabelWrapped(const char* label, bool dim = true) noexcept;
	void ColorButton(const char* id, float col[4], const ImVec2& pos, const ImVec2& size) noexcept;
	bool AnyComboOpen() noexcept;
	void CloseAllPopups() noexcept;
	void RenderPendingPopups() noexcept;

	void DrawKeybindButton(const char* id, int* key, bool* value, float rowY) noexcept;
	void ProcessKeybinds() noexcept;
}
