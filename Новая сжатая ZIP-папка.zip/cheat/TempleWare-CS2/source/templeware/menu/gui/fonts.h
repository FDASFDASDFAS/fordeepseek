#pragma once

#include "../../../../external/imgui/imgui.h"

struct ImFont;
struct ImGuiIO;

namespace fonts
{
	inline constexpr float kUiSize = 12.f;

	// The sidebar letters and the wordmark are drawn far larger than the 12px UI
	// face. ImGui rasterises each ImFont at one size and scales the bitmap for
	// any other, so asking the 12px atlas entry for 26px glyphs produced the
	// blurred, ragged letters. These get their own atlas entries at the exact
	// size they are drawn at.
	// kBrandSize is both the atlas size and the size the wordmark is drawn at.
	// Keep the two equal: Brand() is a light face, and light strokes are what
	// suffer most from bitmap rescaling.
	inline constexpr float kTabLetterSize = 26.f;
	inline constexpr float kBrandSize     = 15.f;

	// Player ESP labels. Smaller than the 13px default the overlays used, and
	// given its own atlas entry at exactly this size for the same reason the
	// wordmark has one: ImGui rasterises a font once and rescales the bitmap for
	// any other size, and small text is where that shows up worst.
	inline constexpr float kEspSize       = 10.f;

	// Adds the menu fonts to the atlas. Does not touch io.FontDefault, so the
	// ESP/HUD overlays keep rendering with whatever font was loaded first.
	void Init(ImGuiIO& io) noexcept;

	ImFont* Verdana() noexcept;
	ImFont* VerdanaBold() noexcept;
	ImFont* TabLetter() noexcept;
	ImFont* Brand() noexcept;
	ImFont* Esp() noexcept;

	ImVec2 CalcUiTextSize(const char* text) noexcept;
}
