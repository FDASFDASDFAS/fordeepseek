#pragma once
#include <Windows.h>
#include <d3d11.h>
#include "../../../external/imgui/imgui.h"
#include "../../../external/imgui/imgui_impl_dx11.h"
#include "../../../external/imgui/imgui_impl_win32.h"


class Menu
{
public:
    Menu();

    bool init(
        HWND& window,
        ID3D11Device* device,
        ID3D11DeviceContext* context,
        ID3D11RenderTargetView* renderTargetView
    );

    void render();
    void shutdown();
    void toggleMenu();

private:
    int activeTab;
    bool showMenu;
    float menuAnimation;
    float tabIndicatorY;
    bool showDebugMenu;
};
