﻿#include "menu.h"
#include "gui/shell.h"
#include "gui/styling.h"
#include "gui/fonts.h"
#include "../config/config.h"
#include "../config/configmanager.h"
#include "../features/feedback/hit_feedback.h"
#include "../features/model_preview/model_preview.h"
#include "../keybinds/keybinds.h"
#include "../utils/logging/log.h"
#include "../runtime/runtime.h"
#include "../hooks/hooks.h"

#include <Windows.h>

#include <algorithm>
#include <cstdarg>
#include <cstdio>
#include <iostream>
#include <string>
#include <vector>

namespace
{
    HWND g_MenuWindow = nullptr;

    constexpr float kCardRounding = 10.0f;
    constexpr float kButtonRounding = 8.0f;

    // Panel grid slots. The shell lays children out on a 9 x 10 grid, so these
    // constants keep the two-column board and its row splits exact.
    constexpr float kColLeft     = 0.0f;
    constexpr float kColRight    = 6.0f;
    constexpr float kColSpan     = 3.0f;
    constexpr float kRowFull     = 10.0f;
    constexpr float kRowThird    = 2.3f;
    constexpr float kThirdTop    = 0.0f;
    constexpr float kThirdMid    = 3.85f;
    constexpr float kThirdBottom = 7.7f;
    // Stacking two panels means leaving ksd::kStackedPanelGap between them --
    // see the note on that constant. Placing the lower panel directly at the
    // upper one's y + h is what made Chams run underneath the Effects title.
    constexpr float kPanelGap = ksd::kStackedPanelGap;

    // Height of the upper panel in each Visuals column, sized to its content:
    // the left column's ESP list is short and its world list long, the right
    // column's chams list is long and its effects list short.
    constexpr float kVisualsLeftTopH  = 4.00f;
    constexpr float kVisualsRightTopH = 4.45f;

    float EaseOutCubic(float value)
    {
        const float inverse = 1.0f - value;
        return 1.0f - inverse * inverse * inverse;
    }

    float Approach(float current, float target, float speed)
    {
        const float step = ImGui::GetIO().DeltaTime * speed;
        return current + (target - current) * (step < 1.0f ? step : 1.0f);
    }

    void CorrectImGuiMousePosition()
    {
        if (g_MenuWindow == nullptr)
            return;

        POINT mousePosition{};
        if (!GetCursorPos(&mousePosition))
            return;

        if (!ScreenToClient(g_MenuWindow, &mousePosition))
            return;

        RECT clientRect{};
        if (!GetClientRect(g_MenuWindow, &clientRect))
            return;

        const float clientWidth =
            static_cast<float>(clientRect.right - clientRect.left);
        const float clientHeight =
            static_cast<float>(clientRect.bottom - clientRect.top);

        ImGuiIO& io = ImGui::GetIO();

        if (clientWidth <= 0.0f ||
            clientHeight <= 0.0f ||
            io.DisplaySize.x <= 0.0f ||
            io.DisplaySize.y <= 0.0f)
        {
            return;
        }

        const float scaleX = io.DisplaySize.x / clientWidth;
        const float scaleY = io.DisplaySize.y / clientHeight;

        io.MousePos = ImVec2(
            static_cast<float>(mousePosition.x) * scaleX,
            static_cast<float>(mousePosition.y) * scaleY);
    }

    float* ColorPtr(ImVec4& color)
    {
        return reinterpret_cast<float*>(&color);
    }

    // Draws a color swatch on the trailing edge of the row the caller just
    // captured, matching the reference menu's checkbox-plus-swatch rows.
    void RowColor(const char* id, float color[4], float rowY)
    {
        ksd::ColorButton(id, color,
            ImVec2(ksd::PanelRightX() - 17.0f, rowY + 2.0f), ImVec2(16.0f, 10.0f));
    }

    void RowColor(const char* id, ImVec4& color, float rowY)
    {
        RowColor(id, ColorPtr(color), rowY);
    }

    void LabelFmt(const char* format, ...)
    {
        char buffer[512];
        va_list args;
        va_start(args, format);
        std::vsnprintf(buffer, sizeof(buffer), format, args);
        va_end(args);
        ksd::LabelWrapped(buffer);
    }
}

void ApplyImGuiTheme()
{
    ImGui::StyleColorsDark();

    ImGuiStyle& style = ImGui::GetStyle();
    ImVec4* colors = style.Colors;

    colors[ImGuiCol_WindowBg]       = ImVec4(0.090f, 0.050f, 0.120f, 0.98f); // Deep Windows Media Player Classic purple
    colors[ImGuiCol_ChildBg]        = ImVec4(0.060f, 0.030f, 0.080f, 0.85f);
    colors[ImGuiCol_PopupBg]        = ImVec4(0.120f, 0.070f, 0.160f, 0.98f);
    colors[ImGuiCol_Border]         = ImVec4(0.450f, 0.250f, 0.600f, 0.60f); // WMP purple chrome outline
    colors[ImGuiCol_BorderShadow]   = ImVec4(0.000f, 0.000f, 0.000f, 0.50f);
    colors[ImGuiCol_Text]           = ImVec4(0.950f, 0.920f, 1.000f, 0.98f);
    colors[ImGuiCol_TextDisabled]   = ImVec4(0.700f, 0.550f, 0.850f, 0.50f);
    colors[ImGuiCol_FrameBg]        = ImVec4(0.150f, 0.080f, 0.200f, 0.85f);
    colors[ImGuiCol_FrameBgHovered] = ImVec4(0.350f, 0.180f, 0.480f, 0.90f);
    colors[ImGuiCol_FrameBgActive]  = ImVec4(0.500f, 0.250f, 0.700f, 1.00f);
    colors[ImGuiCol_CheckMark]      = ImVec4(0.900f, 0.750f, 1.000f, 1.00f);
    colors[ImGuiCol_SliderGrab]     = ImVec4(0.600f, 0.350f, 0.800f, 1.00f);
    colors[ImGuiCol_SliderGrabActive] = ImVec4(0.800f, 0.500f, 1.000f, 1.00f);
    colors[ImGuiCol_Button]         = ImVec4(0.250f, 0.120f, 0.350f, 0.90f);
    colors[ImGuiCol_ButtonHovered]  = ImVec4(0.400f, 0.200f, 0.550f, 1.00f);
    colors[ImGuiCol_ButtonActive]   = ImVec4(0.550f, 0.280f, 0.750f, 1.00f);
    colors[ImGuiCol_Header]         = ImVec4(0.300f, 0.150f, 0.420f, 0.90f);
    colors[ImGuiCol_HeaderHovered]  = ImVec4(0.450f, 0.220f, 0.620f, 1.00f);
    colors[ImGuiCol_HeaderActive]   = ImVec4(0.600f, 0.300f, 0.820f, 1.00f);
    colors[ImGuiCol_ScrollbarBg]    = ImVec4(0.060f, 0.030f, 0.080f, 0.50f);
    colors[ImGuiCol_ScrollbarGrab]  = ImVec4(0.350f, 0.180f, 0.480f, 0.70f);
    colors[ImGuiCol_ScrollbarGrabHovered] = ImVec4(0.500f, 0.250f, 0.700f, 0.90f);
    colors[ImGuiCol_ScrollbarGrabActive]  = ImVec4(0.650f, 0.350f, 0.900f, 1.00f);
    colors[ImGuiCol_Separator]      = ImVec4(0.450f, 0.250f, 0.600f, 0.40f);
    colors[ImGuiCol_SeparatorHovered] = ImVec4(0.700f, 0.400f, 0.950f, 0.80f);
    colors[ImGuiCol_SeparatorActive]  = ImVec4(0.900f, 0.550f, 1.000f, 1.00f);

    style.WindowRounding = 12.0f;
    style.ChildRounding = kCardRounding;
    style.FrameRounding = 6.0f;
    style.PopupRounding = kButtonRounding;
    style.ScrollbarRounding = 6.0f;
    style.GrabRounding = 6.0f;
    style.TabRounding = kButtonRounding;

    style.WindowPadding = ImVec2(0, 0);
    style.ChildBorderSize = 0.0f;
    style.WindowBorderSize = 0.0f;
    style.FrameBorderSize = 0.0f;
    style.PopupBorderSize = 0.0f;

    style.ItemSpacing = ImVec2(8, 7);
    style.ItemInnerSpacing = ImVec2(6, 4);
    style.FramePadding = ImVec2(8, 4);
    style.TouchExtraPadding = ImVec2(0.0f, 0.0f);

    style.ScrollbarSize = 5.0f;
    style.GrabMinSize = 5.0f;
}

Menu::Menu()
    : activeTab(0), showMenu(true), menuAnimation(1.0f), tabIndicatorY(47.0f), showDebugMenu(false)
{
}

bool Menu::init(
    HWND& window,
    ID3D11Device* pDevice,
    ID3D11DeviceContext* pContext,
    ID3D11RenderTargetView* mainRenderTargetView)
{
    (void)mainRenderTargetView;

    g_MenuWindow = window;

    IMGUI_CHECKVERSION();
    if (ImGui::CreateContext() == nullptr)
        return false;

    ImGuiIO& io = ImGui::GetIO();
    io.ConfigFlags |= ImGuiConfigFlags_NoMouseCursorChange;

    // Font loading belongs inside init(), not at global scope.
    // This one stays first so it remains io.FontDefault for the ESP/HUD passes.
    if (io.Fonts->AddFontFromFileTTF("C:\\Windows\\Fonts\\arial.ttf", 13.0f) == nullptr)
        io.Fonts->AddFontDefault();

    // Menu-only fonts (UI text + sidebar tab glyphs).
    fonts::Init(io);

    ApplyImGuiTheme();

    if (!ImGui_ImplWin32_Init(window))
    {
        ImGui::DestroyContext();
        g_MenuWindow = nullptr;
        return false;
    }

    if (!ImGui_ImplDX11_Init(pDevice, pContext))
    {
        ImGui_ImplWin32_Shutdown();
        ImGui::DestroyContext();
        g_MenuWindow = nullptr;
        return false;
    }

    std::cout << "initialized menu\n";
    return true;
}

void Menu::render()
{
    keybind.pollInputs();

    menuAnimation = Approach(menuAnimation, showMenu ? 1.0f : 0.0f, showMenu ? 14.0f : 18.0f);
    if (!showMenu && menuAnimation < 0.01f)
    {
        menuAnimation = 0.0f;
        return;
    }

    CorrectImGuiMousePosition();

    style::menuAlpha = static_cast<int>(std::clamp(EaseOutCubic(menuAnimation), 0.0f, 1.0f) * 255.0f);
    ksd::SetInteractive(showMenu);

    static bool wasOpen = false;
    if (showMenu && !wasOpen)
        ksd::ResetChildScrollStates();
    wasOpen = showMenu;

    int& currentTab = ksd::CurrentTab();
	if (currentTab < 0 || currentTab > 3)
		currentTab = 0;

	ksd::BeginMain();

	// Temporarily unavailable until their current-runtime providers are complete.
	Config::rage.enabled = false;
	Config::movement.airStrafe = false;
	Config::movement.slowWalk = false;
	Config::movement.quickPeek = false;

	const char* tabLabels[] = { "legit", "visuals", "misc", "config" };
	for (int i = 0; i < 4; ++i)
		ksd::TabButton(tabLabels[i], &currentTab, i, 4);

    activeTab = currentTab;

    switch (currentTab)
    {
    case 0: // Legit
    {
        if (ksd::BeginChild("General##Legit", { kColLeft, 0.0f, kColSpan, kRowFull }))
        {
			ksd::Checkbox("Legit aim (gated)", &Config::legit_aim.aimbot);
			ksd::Checkbox("Require aim hold key", &Config::legit_aim.onKey);
			if (Config::legit_aim.onKey)
				ksd::Keybind("Aim hold key", &Config::legit_aim.activationKey);
			ksd::SliderFloat("Aim FOV", &Config::legit_aim.aimbot_fov, 0.1f, 30.0f, "%.1f");
			ksd::SliderFloat("Smoothing", &Config::legit_aim.smoothing, 1.0f, 10.0f, "%.1f");
			ksd::SliderFloat("Reaction time", &Config::legit_aim.reactionDelay, 0.0f, 1.0f, "%.2fs", 0.01f);
			ksd::Checkbox("Team check", &Config::legit_aim.team_check);
			{
				const float rowY = ksd::CursorPos().y;
				ksd::Checkbox("Draw FOV", &Config::legit_aim.fov_circle);
				RowColor("##aim_fov_color", Config::legit_aim.fovCircleColor, rowY);
			}
			ksd::Checkbox("Visibility check", &Config::legit_aim.visibilityCheck);
			ksd::Checkbox("Smoke check", &Config::legit_aim.smokeCheck);
			ksd::Checkbox("Disable while flashed", &Config::legit_aim.disableWhenFlashed);
			ksd::Checkbox("Only while scoped", &Config::legit_aim.onlyWhileScoped);
        }
        ksd::EndChild();

        break;
    }

	case -2: // Triggerbot (disabled)
	{
        if (ksd::BeginChild("TriggerBot##Legit", { kColRight, 0.0f, kColSpan, kRowFull }))
        {
			ksd::Checkbox("Triggerbot", &Config::trigger.enabled);
			ksd::Checkbox("Require trigger hold key", &Config::trigger.onKey);
			if (Config::trigger.onKey)
				ksd::Keybind("Trigger hold key", &Config::trigger.keybind);
			ksd::SliderFloat("Dwell delay", &Config::trigger.dwellDelay, 0.0f, 0.5f, "%.3fs", 0.001f);
			ksd::Checkbox("Team check", &Config::trigger.teamCheck);
			ksd::Checkbox("Head only", &Config::trigger.headOnly);
			ksd::Checkbox("Disable while flashed", &Config::trigger.disableWhenFlashed);
			ksd::Checkbox("Only while scoped", &Config::trigger.onlyWhileScoped);
            ksd::SliderFloat("Attack hold", &Config::trigger.attackHold, 0.01f, 0.20f, "%.3fs", 0.005f);
        }
        ksd::EndChild();
        break;
    }

	case -1: // Rage (temporarily hidden)
	{
		if (ksd::BeginChild("RageBot##Rage", { kColLeft, 0.0f, kColSpan, kRowFull }))
		{
			ksd::Checkbox("Ragebot", &Config::rage.enabled);

			static const char* weaponGroups[] = { "Pistol", "SMG", "Rifle", "Shotgun", "Sniper", "LMG" };
			ksd::SingleSelect("Weapon type", &Config::rage.selectedWeaponGroup, weaponGroups,
				static_cast<int>(std::size(weaponGroups)));
			Config::rage.selectedWeaponGroup = std::clamp(Config::rage.selectedWeaponGroup, 0,
				static_cast<int>(Config::rage.weaponGroups.size()) - 1);
			auto& weapon = Config::rage.weaponGroups[Config::rage.selectedWeaponGroup];

			static const char* hitboxes[] = { "Head", "Chest", "Stomach", "Arms", "Legs", "Feet" };
			ksd::MultiSelect("Hitboxes", &weapon.hitboxes, hitboxes, static_cast<int>(std::size(hitboxes)));
			ksd::SliderInt("Minimum hit chance", &weapon.hitchance, 0, 100, "%d%%");
			ksd::SliderInt("Minimum damage", &weapon.minDamage, 1, 125, "%d");
			ksd::SliderFloat("Point scale", &weapon.pointScale, 0.0f, 100.0f, "%.0f%%", 1.0f);
			ksd::Checkbox("Dynamic point scale", &weapon.dynamicPointScale);
			ksd::Checkbox("Prefer body aim", &weapon.bodyAim);
		}
		ksd::EndChild();

		if (ksd::BeginChild("Other##Rage", { kColRight, 0.0f, kColSpan, kRowFull }))
		{
			auto& weapon = Config::rage.weaponGroups[Config::rage.selectedWeaponGroup];
			ksd::Checkbox("Minimum damage override", &weapon.minDamageOverride);
			if (weapon.minDamageOverride)
				ksd::SliderInt("Damage override", &weapon.minDamageOverrideValue, 0, 130, "%d");
			ksd::Checkbox("Hit chance override", &weapon.hitchanceOverride);
			if (weapon.hitchanceOverride)
				ksd::SliderInt("Chance override", &weapon.hitchanceOverrideValue, 0, 100, "%d%%");
			ksd::Checkbox("Force shot", &weapon.forceShot);
			ksd::Checkbox("Force shot in air", &weapon.forceShotAir);
			ksd::SliderFloat("Maximum FOV", &weapon.maxFov, 1.0f, 180.0f, "%.0f deg", 1.0f);
			ksd::SliderInt("Backtrack ticks", &Config::rage.maxBacktrackTicks, 1, 16, "%d");
			ksd::Checkbox("Extrapolation", &Config::rage.extrapolation);
			if (Config::rage.extrapolation)
				ksd::SliderInt("Extrapolate ticks", &Config::rage.maxExtrapolateTicks, 1, 16, "%d");
			Config::anti_aim.enabled = false;
			Config::anti_aim.overridePitch = false;
            Config::anti_aim.overrideYaw = false;
        }
        ksd::EndChild();
        break;
    }

	case 1: // Visuals
    {
		if (ksd::BeginChild("Preview##Visuals", { kColRight, 0.0f, kColSpan, kRowFull }))
		{
			const ImVec2 previewMin = ksd::CursorPos();
			const float previewWidth = (std::max)(1.0f, ksd::PanelRightX() - previewMin.x);
			const float previewHeight = (std::max)(1.0f, ksd::PanelBottomY() - previewMin.y - 22.0f);
			tw::model_preview::draw(previewMin, ImVec2(
				previewMin.x + previewWidth, previewMin.y + previewHeight));
			ksd::AddItem(ImVec2(previewWidth, previewHeight));
			ksd::LabelWrapped(tw::model_preview::statusText());
		}
		ksd::EndChild();

        if (ksd::BeginChild("Visual settings##Visuals", { kColLeft, 0.0f, kColSpan, kRowFull }))
        {
            // Who to draw, then what to draw on them, then what to write beside
            // them. Team check led the list because it changes what every row
            // below it applies to.
            ksd::Checkbox("Team check", &Config::visual_esp.teamCheck);

            {
                const float rowY = ksd::CursorPos().y;
                ksd::Checkbox("Box", &Config::visual_esp.esp);
                RowColor("##esp_box_color", Config::visual_esp.espColor, rowY);
            }
            if (Config::visual_esp.esp)
            {
                ksd::SliderFloat("Thickness", &Config::visual_esp.espThickness, 1.0f, 5.0f, "%.1f");
                ksd::Checkbox("Box fill", &Config::visual_esp.espFill);
                if (Config::visual_esp.espFill)
                    ksd::SliderFloat("Fill opacity", &Config::visual_esp.espFillOpacity, 0.0f, 1.0f, "%.2f", 0.02f);
            }

            {
                const float rowY = ksd::CursorPos().y;
                ksd::Checkbox("Skeleton", &Config::visual_esp.espSkeleton);
                RowColor("##esp_skeleton_color", Config::visual_esp.skeletonColor, rowY);
            }
            if (Config::visual_esp.espSkeleton)
                ksd::SliderFloat("Skeleton thickness", &Config::visual_esp.skeletonThickness, 1.0f, 5.0f, "%.1f");

            ksd::Checkbox("Health bar", &Config::visual_esp.showHealth);
            ksd::Checkbox("Name tags", &Config::visual_esp.showNameTags);
            ksd::Checkbox("Weapon", &Config::visual_esp.showWeapon);
            ksd::Checkbox("Flashed", &Config::visual_esp.showFlashed);
            ksd::Checkbox("Scope", &Config::visual_esp.showScoped);
			ksd::Label("World");
            ksd::Checkbox("Dropped weapons", &Config::visual_esp.showItems);
            ksd::Checkbox("Grenades", &Config::visual_esp.showGrenades);
            ksd::Checkbox("Bomb", &Config::visual_esp.showBomb);
			ksd::Checkbox("Spectator list", &Config::visual_world.spectatorList);
			ksd::Checkbox("Crosshair overlay", &Config::visual_world.crosshair);
			ksd::Checkbox("Velocity counter", &Config::visual_world.velocityCounter);

            if (H::UpdateLightObject.IsHooked() && H::UpdateAggregateSceneObject.IsHooked())
            {
                const float rowY = ksd::CursorPos().y;
                ksd::Checkbox("Night mode", &Config::visual_world.Night);
                RowColor("##world_night_color", Config::visual_world.NightColor, rowY);
            }
            else
            {
                ksd::LabelWrapped("Night mode unavailable (hook not installed this session)");
                Config::visual_world.Night = false;
            }

            if (H::GetRenderFov.IsHooked())
            {
                ksd::Checkbox("Custom FOV", &Config::visual_world.fovEnabled);
                if (Config::visual_world.fovEnabled)
                    ksd::SliderFloat("FOV", &Config::visual_world.fov, 20.0f, 160.0f, "%.0f", 1.0f);
            }
            else
            {
                ksd::LabelWrapped("Custom FOV unavailable (hook not installed this session)");
                Config::visual_world.fovEnabled = false;
            }
			ksd::Label("Chams");
            {
                const float rowY = ksd::CursorPos().y;
                ksd::Checkbox("Enemy visible", &Config::visual_chams.enemyChams);
                RowColor("##chams_enemy_color", Config::visual_chams.colVisualChams, rowY);
            }
            {
                const float rowY = ksd::CursorPos().y;
                ksd::Checkbox("Enemy through walls", &Config::visual_chams.enemyChamsInvisible);
                RowColor("##chams_enemy_invis_color", Config::visual_chams.colVisualChamsIgnoreZ, rowY);
            }
            {
                const float rowY = ksd::CursorPos().y;
                ksd::Checkbox("Team visible", &Config::visual_chams.teamChams);
                RowColor("##chams_team_color", Config::visual_chams.teamcolVisualChams, rowY);
            }
            {
                const float rowY = ksd::CursorPos().y;
                ksd::Checkbox("Team through walls", &Config::visual_chams.teamChamsInvisible);
                RowColor("##chams_team_invis_color", Config::visual_chams.teamcolVisualChamsIgnoreZ, rowY);
            }
            {
                const float rowY = ksd::CursorPos().y;
                ksd::Checkbox("Local", &Config::visual_chams.localChams);
                RowColor("##chams_local_color", Config::visual_chams.localcolChams, rowY);
            }
            {
                const float rowY = ksd::CursorPos().y;
                ksd::Checkbox("Arms", &Config::visual_chams.armChams);
                RowColor("##chams_arms_color", Config::visual_chams.colArmChams, rowY);
            }
            {
                const float rowY = ksd::CursorPos().y;
                ksd::Checkbox("Viewmodel", &Config::visual_chams.viewmodelChams);
                RowColor("##chams_viewmodel_color", Config::visual_chams.colViewmodelChams, rowY);
            }
			ksd::Label("Effects");
            ksd::Checkbox("Anti-flash", &Config::visual_world.antiflash);

            ksd::Checkbox("Hit marker", &Config::feedback.hitMarker);
            ksd::Checkbox("Hit sound", &Config::feedback.hitSound);
            if (Config::feedback.hitSound)
            {
                ksd::SingleSelect("Sound", &Config::feedback.soundType, tw::features::HitFeedback::kHitSoundNames, tw::features::HitFeedback::kHitSoundCount);
                ksd::SliderFloat("Sound volume", &Config::feedback.soundVolume, 0.0f, 1.0f, "%.2f", 0.05f);
                ksd::Checkbox("Separate headshot sound", &Config::feedback.separateHeadshotSound);
                if (Config::feedback.separateHeadshotSound)
                    ksd::SingleSelect("Headshot sound", &Config::feedback.headshotSoundType,
                        tw::features::HitFeedback::kHitSoundNames, tw::features::HitFeedback::kHitSoundCount);
            }
            ksd::Checkbox("Hit logs", &Config::feedback.hitLogs);
            {
                const float rowY = ksd::CursorPos().y;
                ksd::Checkbox("Bullet tracers", &Config::feedback.bulletTracers);
                RowColor("##tracer_color", Config::feedback.tracerColor, rowY);
            }
            {
                const float rowY = ksd::CursorPos().y;
                ksd::Checkbox("Bullet impacts", &Config::feedback.bulletImpacts);
                RowColor("##impact_color", Config::feedback.impactColor, rowY);
            }
        }
        ksd::EndChild();
        break;
    }

	case 2: // Misc
    {
		if (ksd::BeginChild("Movement##Misc", { kColLeft, kThirdTop, kColSpan, kRowThird }))
		{
			ksd::Checkbox("Bunny hop", &Config::movement.bhop);
        }
        ksd::EndChild();

        if (ksd::BeginChild("Watermark##Misc", { kColLeft, kThirdMid, kColSpan, kRowFull - kThirdMid }))
        {
            ksd::Checkbox("Watermark", &Config::watermark.enabled);
            if (Config::watermark.enabled)
            {
                static const char* kCornerNames[] = { "Top left", "Top right", "Bottom left", "Bottom right" };
                ksd::SingleSelect("Position", &Config::watermark.position, kCornerNames, 4);
                ksd::Checkbox("Show FPS", &Config::watermark.showFps);
                ksd::Checkbox("Show time", &Config::watermark.showTime);
                ksd::Checkbox("Show version", &Config::watermark.showVersion);
                ksd::Checkbox("Follow menu accent", &Config::watermark.followAccent);
                if (!Config::watermark.followAccent)
                {
                    const float colorRow = ksd::CursorPos().y;
                    ksd::Label("Watermark colour");
                    RowColor("##watermark_color", Config::watermark.color, colorRow);
                }
            }
        }
        ksd::EndChild();

        if (ksd::BeginChild("Appearance##Misc", { kColRight, kThirdTop, kColSpan, kRowThird }))
        {
            // Capture the row before the label advances the cursor, the same
            // way RowColor does — reading it afterwards put the swatch a row
            // low and needed a magic offset to claw back.
            const float accentRow = ksd::CursorPos().y;
            ksd::Label("Menu accent");
            RowColor("##menu_accent", vars::colorAccent, accentRow);
            ksd::Checkbox("Rainbow title", &vars::rainbowTitle);
        }
        ksd::EndChild();

        if (ksd::BeginChild("Other##Misc", { kColRight, kThirdMid, kColSpan, kRowFull - kThirdMid }))
        {
            if (ksd::Button("Unload"))
			{
				tw::model_preview::requestCleanup();
                Runtime::RequestUnload();
			}
        }
        ksd::EndChild();
        break;
    }

	case 3: // Config
    {
        static char configName[128] = "";
        static std::vector<std::string> configList = internal_config::ConfigManager::ListConfigs();
        static int selectedConfigIndex = -1;

        if (ksd::BeginChild("General##Config", { kColLeft, 0.0f, kColSpan, kRowFull }))
        {
            ksd::Label("Config name");
            ksd::InputText("##config_name", configName, IM_ARRAYSIZE(configName));

            const float buttonWidth = ksd::ContentWidth();
            if (ksd::Button("Refresh", ImVec2(buttonWidth, 25.0f)))
                configList = internal_config::ConfigManager::ListConfigs();

            if (ksd::Button("Load", ImVec2(buttonWidth, 25.0f)) && configName[0] != '\0')
                internal_config::ConfigManager::Load(configName);

            if (ksd::Button("Save", ImVec2(buttonWidth, 25.0f)) && configName[0] != '\0')
            {
                internal_config::ConfigManager::Save(configName);
                configList = internal_config::ConfigManager::ListConfigs();
            }

            if (ksd::Button("Delete", ImVec2(buttonWidth, 25.0f)) && configName[0] != '\0')
            {
                internal_config::ConfigManager::Remove(configName);
                configList = internal_config::ConfigManager::ListConfigs();
                selectedConfigIndex = -1;
            }
        }
        ksd::EndChild();

        if (ksd::BeginChild("Saved configs##Config", { kColRight, 0.0f, kColSpan, kRowFull }))
        {
            if (configList.empty())
            {
                ksd::LabelWrapped("No saved configs");
            }
            else
            {
                std::vector<const char*> names;
                names.reserve(configList.size());
                for (const std::string& name : configList)
                    names.push_back(name.c_str());

                int listSelection = selectedConfigIndex < 0 ? 0 : selectedConfigIndex;
                if (ksd::ListBox("##config_list", &listSelection, names.data(),
                        static_cast<int>(names.size())))
                {
                    selectedConfigIndex = listSelection;
                    std::snprintf(configName, sizeof(configName), "%s",
                        configList[static_cast<size_t>(listSelection)].c_str());
                }
            }
        }
        ksd::EndChild();
        break;
    }

    case 5: // Debug
    {
        // The Appearance panel moved to the Misc tab, where it is reachable.

        if (ksd::BeginChild("Command Probe##Debug", { kColLeft, 0.0f, kColSpan, kRowFull }))
        {
            const auto commandProbe = H::GetCommandProbeSnapshot();
            const char* probeState = "awaiting callback target";
            if (commandProbe.state == tw::commands::CommandProbeState::Observing)
                probeState = "observing read-only commands";
            else if (commandProbe.state == tw::commands::CommandProbeState::ReadOnlyStable)
                probeState = "read-only path stable";
            else if (commandProbe.state == tw::commands::CommandProbeState::Rejected)
                probeState = "rejected runtime observations";

            if (ksd::Button("Copy diagnostics"))
            {
                char buf[4096];
                std::snprintf(buf, sizeof(buf),
                    "Probe: %s\n"
                    "Image: %08X / %08X\n"
                    "RTTI: %s / vtables %u / entries %u / RVA %08X\n"
                    "Target: %s / RVA %08X\n"
                    "CRC target: %s / RVA %08X\n"
                    "Samples: %llu / advances %llu / CRC %llu\n"
                    "Unavailable: %llu / op %u\n"
                    "Before: %llu / CRC %llu / same %llu / advanced %llu\n"
                    "CRC boundary: %s / samples %llu / transitions %llu\n"
                    "CRC pre: %llu / set %llu / post %llu / set %llu / unavail %llu (%u)\n"
                    "Pre-CRC commit: pass %llu / failed %llu / move %llu / buttons %llu\n"
                    "Movement snapshot: %s / samples %llu / unavail %llu / type %d\n"
                    "Jump transitions: %s / match %llu/%llu / jump %llu/%llu\n"
                    "View history: %s / samples %llu / entries %llu / view %llu\n"
                    "History matches base: first %llu / last %llu / changed %llu",
                    probeState,
                    commandProbe.imageTimestamp, commandProbe.imageSize,
                    commandProbe.inputRttiFound ? "found" : "not found", commandProbe.inputVtableCount,
                    commandProbe.largestInputVtable, commandProbe.firstInputVtableRva,
                    commandProbe.commandTargetValidated ? "validated" : "unavailable", commandProbe.commandTargetRva,
                    commandProbe.moveCrcTargetValidated ? "validated" : "unavailable", commandProbe.moveCrcTargetRva,
                    static_cast<unsigned long long>(commandProbe.passThroughs),
                    static_cast<unsigned long long>(commandProbe.advancingSequences),
                    static_cast<unsigned long long>(commandProbe.moveCrcSamples),
                    static_cast<unsigned long long>(commandProbe.unavailableSamples), commandProbe.lastOperation,
                    static_cast<unsigned long long>(commandProbe.beforeSamples),
                    static_cast<unsigned long long>(commandProbe.beforeMoveCrcSamples),
                    static_cast<unsigned long long>(commandProbe.matchingAcrossOriginal),
                    static_cast<unsigned long long>(commandProbe.advancingAcrossOriginal),
                    commandProbe.moveCrcBoundaryStable ? "stable" : "observing",
                    static_cast<unsigned long long>(commandProbe.moveCrcBoundarySamples),
                    static_cast<unsigned long long>(commandProbe.moveCrcTransitions),
                    static_cast<unsigned long long>(commandProbe.moveCrcBeforeSamples),
                    static_cast<unsigned long long>(commandProbe.moveCrcBeforePresentSamples),
                    static_cast<unsigned long long>(commandProbe.moveCrcAfterSamples),
                    static_cast<unsigned long long>(commandProbe.moveCrcAfterPresentSamples),
                    static_cast<unsigned long long>(commandProbe.moveCrcUnavailableSamples),
                    commandProbe.lastMoveCrcOperation,
                    static_cast<unsigned long long>(commandProbe.preCrcCommits),
                    static_cast<unsigned long long>(commandProbe.preCrcCommitFailures),
                    static_cast<unsigned long long>(commandProbe.movementCommits),
                    static_cast<unsigned long long>(commandProbe.buttonCommits),
                    commandProbe.movementSnapshotStable ? "stable" : "observing",
                    static_cast<unsigned long long>(commandProbe.movementSnapshotSamples),
                    static_cast<unsigned long long>(commandProbe.movementSnapshotUnavailable),
                    commandProbe.lastRawMoveType,
                    commandProbe.jumpTransitionStable ? "stable" : "observing",
                    static_cast<unsigned long long>(commandProbe.matchingButtonStateSamples),
                    static_cast<unsigned long long>(commandProbe.buttonStateSamples),
                    static_cast<unsigned long long>(commandProbe.jumpPressedSamples),
                    static_cast<unsigned long long>(commandProbe.jumpTransitionSamples),
                    commandProbe.viewHistoryReadStable ? "stable" : "observing",
                    static_cast<unsigned long long>(commandProbe.viewHistorySamples),
                    static_cast<unsigned long long>(commandProbe.viewHistoryEntries),
                    static_cast<unsigned long long>(commandProbe.historyEntriesWithView),
                    static_cast<unsigned long long>(commandProbe.firstHistoryMatchesBase),
                    static_cast<unsigned long long>(commandProbe.lastHistoryMatchesBase),
                    static_cast<unsigned long long>(commandProbe.changedHistorySamples));
                const std::size_t len = std::strlen(buf);
                if (HGLOBAL hMem = GlobalAlloc(GMEM_MOVEABLE, len + 1))
                {
                    if (void* pMem = GlobalLock(hMem))
                    {
                        std::memcpy(pMem, buf, len + 1);
                        GlobalUnlock(hMem);
                    }
                    if (OpenClipboard(nullptr))
                    {
                        EmptyClipboard();
                        SetClipboardData(CF_TEXT, hMem);
                        CloseClipboard();
                        hMem = nullptr;
                    }
                    if (hMem)
                        GlobalFree(hMem);
                }
            }

            LabelFmt("Command probe: %s", probeState);
            LabelFmt("Image %08X / %08X", commandProbe.imageTimestamp, commandProbe.imageSize);
            LabelFmt("Input RTTI: %s / vtables %u / entries %u / RVA %08X",
                commandProbe.inputRttiFound ? "found" : "not found", commandProbe.inputVtableCount,
                commandProbe.largestInputVtable, commandProbe.firstInputVtableRva);
            LabelFmt("Target: %s / RVA %08X", commandProbe.commandTargetValidated ? "validated read-only" : "unavailable",
                commandProbe.commandTargetRva);
            LabelFmt("CRC target: %s / RVA %08X",
                commandProbe.moveCrcTargetValidated ? "validated read-only" : "unavailable", commandProbe.moveCrcTargetRva);
            LabelFmt("Samples: %llu / advances %llu / CRC %llu",
                static_cast<unsigned long long>(commandProbe.passThroughs),
                static_cast<unsigned long long>(commandProbe.advancingSequences),
                static_cast<unsigned long long>(commandProbe.moveCrcSamples));
            LabelFmt("Unavailable: %llu / operation %u",
                static_cast<unsigned long long>(commandProbe.unavailableSamples), commandProbe.lastOperation);
            LabelFmt("Before: %llu / CRC %llu / same %llu / advanced %llu",
                static_cast<unsigned long long>(commandProbe.beforeSamples),
                static_cast<unsigned long long>(commandProbe.beforeMoveCrcSamples),
                static_cast<unsigned long long>(commandProbe.matchingAcrossOriginal),
                static_cast<unsigned long long>(commandProbe.advancingAcrossOriginal));
            LabelFmt("CRC boundary: %s / samples %llu / transitions %llu",
                commandProbe.moveCrcBoundaryStable ? "pre-to-post stable" : "observing",
                static_cast<unsigned long long>(commandProbe.moveCrcBoundarySamples),
                static_cast<unsigned long long>(commandProbe.moveCrcTransitions));
            LabelFmt("CRC pre: %llu / set %llu / post %llu / set %llu / unavailable %llu (%u)",
                static_cast<unsigned long long>(commandProbe.moveCrcBeforeSamples),
                static_cast<unsigned long long>(commandProbe.moveCrcBeforePresentSamples),
                static_cast<unsigned long long>(commandProbe.moveCrcAfterSamples),
                static_cast<unsigned long long>(commandProbe.moveCrcAfterPresentSamples),
                static_cast<unsigned long long>(commandProbe.moveCrcUnavailableSamples),
                commandProbe.lastMoveCrcOperation);
            LabelFmt("Pre-CRC commit: pass %llu / failed %llu / move %llu / buttons %llu",
                static_cast<unsigned long long>(commandProbe.preCrcCommits),
                static_cast<unsigned long long>(commandProbe.preCrcCommitFailures),
                static_cast<unsigned long long>(commandProbe.movementCommits),
                static_cast<unsigned long long>(commandProbe.buttonCommits));
            LabelFmt("Movement snapshot: %s / samples %llu / unavailable %llu / type %d",
                commandProbe.movementSnapshotStable ? "stable" : "observing",
                static_cast<unsigned long long>(commandProbe.movementSnapshotSamples),
                static_cast<unsigned long long>(commandProbe.movementSnapshotUnavailable),
                commandProbe.lastRawMoveType);
            LabelFmt("Jump transitions: %s / native match %llu/%llu (diag) / jump %llu/%llu",
                commandProbe.jumpTransitionStable ? "stable" : "observing",
                static_cast<unsigned long long>(commandProbe.matchingButtonStateSamples),
                static_cast<unsigned long long>(commandProbe.buttonStateSamples),
                static_cast<unsigned long long>(commandProbe.jumpPressedSamples),
                static_cast<unsigned long long>(commandProbe.jumpTransitionSamples));
            LabelFmt("View history: %s / samples %llu / entries %llu / view %llu",
                commandProbe.viewHistoryReadStable ? "read stable" : "observing",
                static_cast<unsigned long long>(commandProbe.viewHistorySamples),
                static_cast<unsigned long long>(commandProbe.viewHistoryEntries),
                static_cast<unsigned long long>(commandProbe.historyEntriesWithView));
            LabelFmt("History matches base: first %llu / last %llu / changed %llu",
                static_cast<unsigned long long>(commandProbe.firstHistoryMatchesBase),
                static_cast<unsigned long long>(commandProbe.lastHistoryMatchesBase),
                static_cast<unsigned long long>(commandProbe.changedHistorySamples));
        }
        ksd::EndChild();

        // Sits below Appearance rather than sharing row 0 with it -- both at 0.0
        // drew the two panels on top of each other.
        if (ksd::BeginChild("Diagnostics Notes##Debug", { kColRight, kThirdMid, kColSpan, kRowFull - kThirdMid }))
        {
            ksd::LabelWrapped("Aim executes once the CRC boundary is proven stable.");
            ksd::LabelWrapped("Recoil control additionally requires proven recoil observations.");
        }
        ksd::EndChild();
        break;
    }

    default:
        currentTab = 0;
        break;
    }

    ksd::EndMain();
}

void Menu::toggleMenu()
{
    showMenu = !showMenu;
}

void Menu::shutdown()
{
    if (ImGui::GetCurrentContext() == nullptr)
        return;

    ImGui_ImplDX11_Shutdown();
    ImGui_ImplWin32_Shutdown();
    ImGui::DestroyContext();

    g_MenuWindow = nullptr;
}
