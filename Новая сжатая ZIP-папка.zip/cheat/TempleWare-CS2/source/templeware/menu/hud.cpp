#include "hud.h"
#include "../../../external/imgui/imgui.h"
#include "../config/config.h"
#include "../hooks/hooks.h"
#include "../features/visuals/visuals.h"
#include "gui/fonts.h"
#include "gui/styling.h"
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <ctime>
#include <string>
#include <sstream>
#include <vector>
#include <DirectXMath.h>

Hud::Hud() {

}

float CalculateFovRadius(float fovDegrees, float screenWidth, float screenHeight, float gameVerticalFOV) {
    float aspectRatio = screenWidth / screenHeight;
    float fovRadians = fovDegrees * (DirectX::XM_PI / 180.0f);

    float screenRadius = std::tan(fovRadians / 2.0f) * (screenHeight / 2.0f) / std::tan(gameVerticalFOV * (DirectX::XM_PI / 180.0f) / 2.0f);

    static float flScalingMultiplier = 2.5f;

    return screenRadius * flScalingMultiplier;
}

namespace
{
    // The watermark lives on the background draw list, so none of the menu's
    // fade alpha reaches it: every colour below is stated outright rather than
    // going through style::rgba/glass, which fold in style::menuAlpha and would
    // make the watermark vanish whenever the menu is closed.
    constexpr float kMarkMargin  = 12.0f;
    constexpr float kMarkPadX    = 11.0f;
    constexpr float kMarkPadY    = 7.0f;
    constexpr float kMarkGap     = 8.0f;
    constexpr float kMarkRound   = 6.0f;
    constexpr float kMarkBarW    = 2.5f;
    constexpr float kMarkBarGap  = 8.0f;

    constexpr const char* kMarkBrand   = "dork.cat";
    constexpr const char* kMarkVersion = "1.2";

    ImU32 MarkAccent(float alpha)
    {
        if (Config::watermark.followAccent)
            return style::accentOpaque(alpha);
        const ImVec4& picked = Config::watermark.color;
        const auto channel = [](float value) {
            return static_cast<int>(std::clamp(value, 0.0f, 1.0f) * 255.0f);
        };
        return IM_COL32(channel(picked.x), channel(picked.y), channel(picked.z),
            channel(picked.w * std::clamp(alpha, 0.0f, 1.0f)));
    }

    void DrawWatermark(ImDrawList* drawList, const char* fpsText, const char* clockText)
    {
        if (!Config::watermark.enabled)
            return;

        std::vector<const char*> segments;
        if (Config::watermark.showFps)
            segments.push_back(fpsText);
        if (Config::watermark.showTime)
            segments.push_back(clockText);
        if (Config::watermark.showVersion)
            segments.push_back(kMarkVersion);

        ImFont* brandFont = fonts::Brand();
        ImFont* bodyFont  = fonts::Verdana();
        const float brandSize = fonts::kBrandSize;
        const float bodySize  = fonts::kUiSize;

        const ImVec2 brandDim = brandFont->CalcTextSizeA(brandSize, FLT_MAX, 0.0f, kMarkBrand);
        const float  bodyH    = bodyFont->CalcTextSizeA(bodySize, FLT_MAX, 0.0f, "0").y;

        // Widths are measured once here and reused when drawing, so the card can
        // never end up narrower than the text it holds.
        std::vector<float> segmentWidths;
        segmentWidths.reserve(segments.size());
        float contentWidth = brandDim.x;
        for (const char* segment : segments)
        {
            const float width = bodyFont->CalcTextSizeA(bodySize, FLT_MAX, 0.0f, segment).x;
            segmentWidths.push_back(width);
            contentWidth += kMarkGap * 2.0f + 1.0f + width;
        }

        const float cardW = kMarkPadX * 2.0f + kMarkBarW + kMarkBarGap + contentWidth;
        const float cardH = (std::max)(brandDim.y, bodyH) + kMarkPadY * 2.0f;

        const ImVec2 display = ImGui::GetIO().DisplaySize;
        const int position = std::clamp(Config::watermark.position, 0, 3);
        const float x = std::round((position == 1 || position == 3)
            ? display.x - kMarkMargin - cardW : kMarkMargin);
        const float y = std::round(position >= 2
            ? display.y - kMarkMargin - cardH : kMarkMargin);

        const ImVec2 cardMin{ x, y };
        const ImVec2 cardMax{ x + cardW, y + cardH };

        drawList->AddRectFilled({ cardMin.x + 1.0f, cardMin.y + 2.0f },
            { cardMax.x + 1.0f, cardMax.y + 2.0f }, IM_COL32(0, 0, 0, 70), kMarkRound);
        drawList->AddRectFilled(cardMin, cardMax, IM_COL32(13, 13, 17, 214), kMarkRound);
        drawList->AddRect(cardMin, cardMax, MarkAccent(0.38f), kMarkRound, 0, 1.0f);

        const float barX = cardMin.x + kMarkPadX;
        drawList->AddRectFilled({ barX, cardMin.y + kMarkPadY },
            { barX + kMarkBarW, cardMax.y - kMarkPadY }, MarkAccent(1.0f), kMarkBarW * 0.5f);

        float cursorX = barX + kMarkBarW + kMarkBarGap;
        drawList->AddText(brandFont, brandSize,
            { std::round(cursorX), std::round(cardMin.y + (cardH - brandDim.y) * 0.5f) },
            MarkAccent(1.0f), kMarkBrand);
        cursorX += brandDim.x;

        const float textY = std::round(cardMin.y + (cardH - bodyH) * 0.5f);
        for (std::size_t i = 0; i < segments.size(); ++i)
        {
            cursorX += kMarkGap;
            const float dividerX = std::round(cursorX);
            drawList->AddLine({ dividerX, cardMin.y + kMarkPadY + 1.0f },
                { dividerX, cardMax.y - kMarkPadY - 1.0f }, IM_COL32(255, 255, 255, 30), 1.0f);
            cursorX += 1.0f + kMarkGap;

            drawList->AddText(bodyFont, bodySize, { std::round(cursorX), textY },
                IM_COL32(198, 198, 204, 255), segments[i]);
            cursorX += segmentWidths[i];
        }
    }
}

void RenderFovCircle(ImDrawList* drawList, float fov, ImVec2 screenCenter, float screenWidth, float screenHeight, float thickness) {
    float radius = CalculateFovRadius(fov, screenWidth, screenHeight, H::g_flActiveFov);
    uint32_t color = ImGui::ColorConvertFloat4ToU32(Config::legit_aim.fovCircleColor);
    drawList->AddCircle(screenCenter, radius, color, 100, thickness);
}

void Hud::render() {

    // Time
    std::time_t now = std::time(nullptr);
    std::tm localTime;
    localtime_s(&localTime, &now);
    char timeBuffer[9];
    std::strftime(timeBuffer, sizeof(timeBuffer), "%H:%M:%S", &localTime);

    // FPS
    float fps = ImGui::GetIO().Framerate;
    std::ostringstream fpsStream;
    fpsStream << static_cast<int>(fps) << " FPS";

    const std::string fpsText = fpsStream.str();

    ImDrawList* drawList = ImGui::GetBackgroundDrawList();
    DrawWatermark(drawList, fpsText.c_str(), timeBuffer);

	if (Config::legit_aim.fov_circle) {
        ImVec2 Center = ImVec2(ImGui::GetIO().DisplaySize.x / 2.f, ImGui::GetIO().DisplaySize.y / 2.f);

		RenderFovCircle(drawList, Config::legit_aim.aimbot_fov, Center, ImGui::GetIO().DisplaySize.x, ImGui::GetIO().DisplaySize.y, 1.f);
	}

	const ImVec2 center{ ImGui::GetIO().DisplaySize.x * 0.5f, ImGui::GetIO().DisplaySize.y * 0.5f };
	if (Config::visual_world.crosshair)
	{
		constexpr float gap = 3.0f;
		constexpr float length = 7.0f;
		const ImU32 outline = IM_COL32(0, 0, 0, 220);
		const ImU32 foreground = IM_COL32(235, 235, 235, 255);
		drawList->AddLine({ center.x - gap - length, center.y }, { center.x - gap, center.y }, outline, 3.0f);
		drawList->AddLine({ center.x + gap, center.y }, { center.x + gap + length, center.y }, outline, 3.0f);
		drawList->AddLine({ center.x, center.y - gap - length }, { center.x, center.y - gap }, outline, 3.0f);
		drawList->AddLine({ center.x, center.y + gap }, { center.x, center.y + gap + length }, outline, 3.0f);
		drawList->AddLine({ center.x - gap - length, center.y }, { center.x - gap, center.y }, foreground, 1.0f);
		drawList->AddLine({ center.x + gap, center.y }, { center.x + gap + length, center.y }, foreground, 1.0f);
		drawList->AddLine({ center.x, center.y - gap - length }, { center.x, center.y - gap }, foreground, 1.0f);
		drawList->AddLine({ center.x, center.y + gap }, { center.x, center.y + gap + length }, foreground, 1.0f);
	}

	if (Config::visual_world.velocityCounter)
	{
		const auto snapshot = Esp::snapshotForAim();
		if (snapshot.localValid)
		{
			char speedText[16]{};
			const int speed = static_cast<int>(std::lround(std::hypot(snapshot.localVelocity.x, snapshot.localVelocity.y)));
			std::snprintf(speedText, sizeof(speedText), "%d", speed);
			const ImVec2 size = ImGui::CalcTextSize(speedText);
			const ImVec2 speedPos{ center.x - size.x * 0.5f, ImGui::GetIO().DisplaySize.y - 145.0f };
			drawList->AddText({ speedPos.x + 1.0f, speedPos.y + 1.0f }, IM_COL32(0, 0, 0, 220), speedText);
			drawList->AddText(speedPos, IM_COL32(235, 235, 235, 255), speedText);
		}
	}
}
