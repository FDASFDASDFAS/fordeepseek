#pragma once

#include "../../globals/globals.h"

class SpectatorList {
public:
	void Capture();
	void Clear();
	void OnRender();
};

inline const auto g_spectatorlist = std::make_unique<SpectatorList>();
