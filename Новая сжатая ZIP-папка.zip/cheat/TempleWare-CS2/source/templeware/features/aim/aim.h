#pragma once

void Aimbot();
