#pragma once

#include "../../entities/entity_state.h"

#include <cstdint>

namespace tw::tracing
{
    // Standard CS2 shot trace contents mask.
    inline constexpr std::uint64_t kMaskShot = 0x1C3003;

    struct Result final
    {
        std::uintptr_t hitEntity{};
        // CHitBox the ray landed on, when it hit one. This is the game's own
        // answer to "which body part", so it needs no model walking -- see
        // tw::hitboxes::groupOf.
        std::uintptr_t hitboxData{};
        entities::Vec3 endPosition{};
        float fraction{};
        bool valid{};
    };

    // Resolves TraceShape, the filter initialiser and the trace manager.
    // Returns false if any of them could not be found, in which case every
    // call below degrades to "no opinion" rather than faulting.
    bool init();

    bool available() noexcept;

    // Single ray from start to end, ignoring skipEntity.
    Result trace(const entities::Vec3& start, const entities::Vec3& end,
        std::uintptr_t skipEntity, std::uint64_t mask = kMaskShot);

    // True when targetEntity can be reached from start, allowing up to three
    // penetrations through other players (matching how the game lets bullets
    // pass through bodies). Returns true when tracing is unavailable so that
    // callers keep their previous behaviour instead of silently doing nothing.
    bool isVisible(const entities::Vec3& start, const entities::Vec3& end,
        std::uintptr_t targetEntity, std::uintptr_t skipEntity,
        std::uint64_t mask = kMaskShot);

    // ---- resolved engine plumbing -------------------------------------------
    //
    // Exposed so the ported velocity systems::tracing can reuse this project's
    // resolution instead of its own signatures, which are dead on build 14172
    // (trace_ray, trace_ray_entity and trace_filter_init all score 0 matches
    // against the live client.dll, while these three resolve every run).
    //
    // The functions are the same ones velocity called, with identical argument
    // order:
    //   TraceShape(manager, ray, start, end, filter, out)   == trace_ray
    //   InitFilter(filter, skipEntity, mask, layer, type)   == trace_filter_init
    //
    // All three return null/0 when init() failed; callers must degrade rather
    // than call through a null pointer.

    using TraceShapeFn = bool(__fastcall*)(void*, void*, const void*, const void*, void*, void*);
    using InitFilterFn = void(__fastcall*)(void*, std::uintptr_t, std::uint64_t, std::uint8_t, int);

    [[nodiscard]] TraceShapeFn traceShapeFn() noexcept;
    [[nodiscard]] InitFilterFn initFilterFn() noexcept;

    // The trace manager instance itself, already dereferenced.
    [[nodiscard]] void* manager() noexcept;
}
