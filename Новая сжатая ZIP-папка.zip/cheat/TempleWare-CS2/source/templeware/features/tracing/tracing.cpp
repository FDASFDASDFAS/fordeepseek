#include "tracing.h"

#include "../../utils/memory/patternscan/patternscan.h"

#include <Windows.h>

#include <cmath>
#include <cstddef>
#include <cstring>
#include <iostream>
#include <unordered_map>

namespace tw::tracing
{
    namespace
    {
        // ------------------------------------------------------------------
        // client.dll trace plumbing. Everything here was read off the binary:
        //
        //   TraceShape(manager, ray, start, end, filter, out)
        //     found from a real call site (client.dll+0x888A38):
        //       mov rcx,[rip+d]      ; manager
        //       lea rax,[out]  / mov [rsp+0x28],rax
        //       lea r9,[end] / lea r8,[start]
        //       lea rax,[filter] / mov [rsp+0x20],rax
        //       lea rdx,[ray]
        //       call TraceShape
        //
        //   InitFilter(filter, skipEntity, mask, layer, type)
        //     writes the CTraceFilter vtable and defaults; confirmed by
        //     mov [rcx+8],r8 (mask) and mov [rcx+0x38],r9b (layer).
        //     Calling it means we never depend on the filter's field layout.
        //
        //   Result offsets confirmed by histogramming field accesses across
        //   all 57 TraceShape call sites:
        //     +0x08 hit entity (read as a pointer, 3 sites)
        //     +0x84 end position
        //     +0xAC fraction   (read via movss/comiss, 15 sites)
        // ------------------------------------------------------------------
        constexpr std::size_t kHitEntityOffset = 0x08;
        // The hit CHitBox. Not derived from call sites like the three around it
        // -- it comes from the CGameTrace layout in velocity-main -- but the
        // fields on either side of it there (hit_entity 0x08, end_pos 0x84,
        // fraction 0xAC) are exactly the three this project resolved
        // independently, which is what makes the layout credible.
        constexpr std::size_t kHitboxOffset    = 0x10;
        constexpr std::size_t kEndPosOffset    = 0x84;
        constexpr std::size_t kFractionOffset  = 0xAC;

        // Opaque blobs: we only ever hand these to the engine. Sized well past
        // what the game writes so a layout change cannot corrupt our stack.
        struct alignas(16) Ray      { std::byte storage[0x40]{}; };
        struct alignas(16) Filter   { std::byte storage[0x60]{}; };
        struct alignas(16) TraceOut { std::byte storage[0x140]{}; };

        using TraceShape_t = bool(__fastcall*)(void*, void*, const void*, const void*, void*, void*);
        using InitFilter_t = void(__fastcall*)(void*, std::uintptr_t, std::uint64_t, std::uint8_t, int);

        TraceShape_t g_traceShape = nullptr;
        InitFilter_t g_initFilter = nullptr;
        void**       g_manager = nullptr;

        // The manager is a global in .data. Rather than hardcode the offset,
        // vote across every direct call to TraceShape for the `mov rcx,[rip+d]`
        // that precedes it. On build 14172 that is 31 agreeing sites out of 57
        // calls with no runner-up.
        void** resolveManager(std::uint8_t* base, std::size_t size, std::uint8_t* traceShape)
        {
            std::unordered_map<std::uintptr_t, int> votes;

            for (std::size_t i = 0; i + 5 < size; ++i)
            {
                if (base[i] != 0xE8)
                    continue;

                const auto rel = *reinterpret_cast<const std::int32_t*>(base + i + 1);
                if (base + i + 5 + rel != traceShape)
                    continue;

                // walk back for mov rcx, [rip + disp32]
                const std::size_t lo = (i > 80) ? i - 80 : 0;
                for (std::size_t j = i; j-- > lo;)
                {
                    if (base[j] == 0x48 && base[j + 1] == 0x8B && base[j + 2] == 0x0D)
                    {
                        const auto disp = *reinterpret_cast<const std::int32_t*>(base + j + 3);
                        ++votes[reinterpret_cast<std::uintptr_t>(base + j + 7 + disp)];
                        break;
                    }
                }
            }

            std::uintptr_t best = 0;
            int bestVotes = 0;
            for (const auto& [address, count] : votes)
            {
                if (count > bestVotes)
                {
                    best = address;
                    bestVotes = count;
                }
            }

            if (!best || bestVotes < 4)
            {
                std::cout << "  tracing: [!] manager vote inconclusive (best=" << bestVotes << ")" << std::endl;
                return nullptr;
            }

            return reinterpret_cast<void**>(best);
        }

        float readFloat(const void* trace, std::size_t offset) noexcept
        {
            return *reinterpret_cast<const float*>(
                reinterpret_cast<const std::uint8_t*>(trace) + offset);
        }
    }

    bool available() noexcept
    {
        return g_traceShape && g_initFilter && g_manager;
    }

    TraceShapeFn traceShapeFn() noexcept
    {
        return reinterpret_cast<TraceShapeFn>(g_traceShape);
    }

    InitFilterFn initFilterFn() noexcept
    {
        return reinterpret_cast<InitFilterFn>(g_initFilter);
    }

    void* manager() noexcept
    {
        return g_manager ? *g_manager : nullptr;
    }

    bool init()
    {
        g_traceShape = reinterpret_cast<TraceShape_t>(M::patternScan("client",
            "48 89 54 24 10 48 89 4C 24 08 55 53 56 57 41 56 41 57 48 8D AC 24 ? ? ? ? "
            "B8 ? ? ? ? E8 ? ? ? ? 48 2B E0"));

        g_initFilter = reinterpret_cast<InitFilter_t>(M::patternScan("client",
            "48 89 5C 24 08 48 89 74 24 10 57 48 83 EC 20 0F B6 41 39 33 FF 24 C9 C7 41 34"));

        if (const auto base = reinterpret_cast<std::uint8_t*>(GetModuleHandleA("client.dll")))
        {
            const auto dos = reinterpret_cast<PIMAGE_DOS_HEADER>(base);
            if (dos->e_magic == IMAGE_DOS_SIGNATURE)
            {
                const auto nt = reinterpret_cast<PIMAGE_NT_HEADERS>(base + dos->e_lfanew);
                if (nt->Signature == IMAGE_NT_SIGNATURE && g_traceShape)
                {
                    g_manager = resolveManager(base, nt->OptionalHeader.SizeOfImage,
                        reinterpret_cast<std::uint8_t*>(g_traceShape));
                }
            }
        }

        std::cout << "  tracing: TraceShape=" << reinterpret_cast<void*>(g_traceShape)
                  << " InitFilter=" << reinterpret_cast<void*>(g_initFilter)
                  << " manager=" << reinterpret_cast<void*>(g_manager) << std::endl;

        if (!available())
            std::cout << "  tracing: [!] unavailable - visibility checks will pass through" << std::endl;

        return available();
    }

    Result trace(const entities::Vec3& start, const entities::Vec3& end,
        std::uintptr_t skipEntity, std::uint64_t mask)
    {
        Result result{};

        if (!available())
            return result;

        void* manager = *g_manager;
        if (!manager)
            return result;

        Ray ray{};
        Filter filter{};
        TraceOut out{};

        // layer 4, type 7 — the combination the game uses for shot traces
        g_initFilter(&filter, skipEntity, mask, 4, 7);

        const float from[3]{ start.x, start.y, start.z };
        const float to[3]{ end.x, end.y, end.z };

        g_traceShape(manager, &ray, from, to, &filter, &out);

        const auto raw = reinterpret_cast<const std::uint8_t*>(&out);
        result.hitEntity = *reinterpret_cast<const std::uintptr_t*>(raw + kHitEntityOffset);
        result.hitboxData = *reinterpret_cast<const std::uintptr_t*>(raw + kHitboxOffset);
        result.fraction = readFloat(raw, kFractionOffset);
        result.endPosition = {
            readFloat(raw, kEndPosOffset + 0),
            readFloat(raw, kEndPosOffset + 4),
            readFloat(raw, kEndPosOffset + 8),
        };
        result.valid = std::isfinite(result.fraction);

        return result;
    }

    bool isVisible(const entities::Vec3& start, const entities::Vec3& end,
        std::uintptr_t targetEntity, std::uintptr_t skipEntity, std::uint64_t mask)
    {
		if (!available())
			return false;

		const Result result = trace(start, end, skipEntity, mask);
		if (!result.valid)
			return false;

		// Visibility is a first-hit question. Penetration belongs to the separate
		// damage service and must never be inferred by skipping arbitrary entities.
		return result.hitEntity == targetEntity || result.fraction > 0.999f;
	}
}
