#include <algorithm>
#include <array>
#include <iostream>
#include <mutex>
#include "../../hooks/hooks.h"
#include "../../players/players.h"
#include "../../config/configmanager.h"
#include "../../../../external/imgui/imgui.h"
#include "../../interfaces/interfaces.h"
#include <unordered_map>
#include "../../../cs2/entity/C_EnvSky/C_EnvSky.h"

namespace
{
	std::mutex worldStateMutex;
	std::unordered_map<uintptr_t, std::array<float, 3>> originalLightColors;
	std::unordered_map<uintptr_t, C_ByteColor> originalAggregateColors;

	bool IsWritableAddress(uintptr_t address, size_t size)
	{
		MEMORY_BASIC_INFORMATION memory{};
		if (VirtualQuery(reinterpret_cast<void*>(address), &memory, sizeof(memory)) != sizeof(memory)
			|| memory.State != MEM_COMMIT || (memory.Protect & (PAGE_GUARD | PAGE_NOACCESS)) != 0)
		{
			return false;
		}

		const uintptr_t regionEnd = reinterpret_cast<uintptr_t>(memory.BaseAddress) + memory.RegionSize;
		return address <= regionEnd && size <= regionEnd - address;
	}
}

void* __fastcall H::hkUpdateAggregateSceneObject(void* a1, void* a2, c_aggregate_object_array* a3)
{
	Runtime::CallbackGuard callback;
	auto original = H::UpdateAggregateSceneObject.GetOriginal();
	if (Runtime::IsShuttingDown())
		return original(a1, a2, a3);

	void* result = original(a1, a2, a3);
	const auto settings = internal_config::ConfigManager::Snapshot();

	if (settings->world.night)
	{
		c_color floatColor = { settings->world.nightColor.r, settings->world.nightColor.g, settings->world.nightColor.b };

		C_ByteColor Color = (floatColor * 255).to_byte();

		for (int i = 0; i < a3->data->count; i++)
		{
			int index = (a3->data->index + i) << 5;
			const uintptr_t address = reinterpret_cast<uintptr_t>(I::SceneSystem->light_data_queue->light_data) + index;
			std::scoped_lock lock(worldStateMutex);
			originalAggregateColors.try_emplace(address, *reinterpret_cast<C_ByteColor*>(address));
			*reinterpret_cast<C_ByteColor*>(address) = Color;
		}
	}

	return result;
}

void __fastcall H::hkUpdateLightObject(__int64 a1, __int64 a2, __int64 a3)
{
	Runtime::CallbackGuard callback;
	auto original = UpdateLightObject.GetOriginal();
	if (Runtime::IsShuttingDown())
		return original(a1, a2, a3);

	const auto settings = internal_config::ConfigManager::Snapshot();
	if (settings->world.night)
	{
		float* r = (float*)(a2 + 228);
		float* g = (float*)(a2 + 232);
		float* b = (float*)(a2 + 236);

		std::scoped_lock lock(worldStateMutex);
		const auto [found, inserted] = originalLightColors.try_emplace(a2, std::array<float, 3>{ *r, *g, *b });
		*r = found->second[0] * settings->world.nightColor.r;
		*g = found->second[1] * settings->world.nightColor.g;
		*b = found->second[2] * settings->world.nightColor.b;
	}
	else
	{
		std::scoped_lock lock(worldStateMutex);
		auto it = originalLightColors.find(a2);
		if (it != originalLightColors.end())
		{
			float* r = (float*)(a2 + 228);
			float* g = (float*)(a2 + 232);
			float* b = (float*)(a2 + 236);
			*r = it->second[0];
			*g = it->second[1];
			*b = it->second[2];
			originalLightColors.erase(it);
		}
	}

	return original(a1, a2, a3);
}

void H::RestoreWorldState()
{
	std::scoped_lock lock(worldStateMutex);

	for (const auto& [address, color] : originalLightColors)
	{
		if (!IsWritableAddress(address + 228, sizeof(float) * 3))
			continue;

		*reinterpret_cast<float*>(address + 228) = color[0];
		*reinterpret_cast<float*>(address + 232) = color[1];
		*reinterpret_cast<float*>(address + 236) = color[2];
	}

	for (const auto& [address, color] : originalAggregateColors)
	{
		if (IsWritableAddress(address, sizeof(C_ByteColor)))
			*reinterpret_cast<C_ByteColor*>(address) = color;
	}

	originalLightColors.clear();
	originalAggregateColors.clear();
}

void H::ClearWorldState()
{
	std::scoped_lock lock(worldStateMutex);
	originalLightColors.clear();
	originalAggregateColors.clear();
}
