#pragma once
#include "../../utils/math/viewmatrix/viewmatrix.h"
#include "..\..\..\cs2\entity\C_CSPlayerPawn\C_CSPlayerPawn.h"
#include "..\..\..\cs2\entity\C_BaseEntity\C_BaseEntity.h"
#include "../../entities/entity_state.h"
#include "../../renderer/render_commands.h"
#include "../core/feature_policies.h"
#include <array>
#include <string>

class LocalPlayerCached {
public:
	int handle;
	int health;
	int team;
	bool alive;
	Vector_t poisition;
	Vector_t eyePosition;
	Vector_t velocity;
	void reset() {
		poisition = Vector_t();
		eyePosition = Vector_t();
		velocity = Vector_t();
		team = 0;
		health = 0;
		handle = 0;
		alive = false;
	}
};

enum PlayerType_t : int
{
	none = -1,
	enemy = 0,
	team = 1,
};

struct PlayerCache
{
	PlayerCache(tw::entities::EntityKey entityKey, PlayerType_t typ, int hp, const char* nm,
		const char* wep_name, Vector_t pos, Vector_t viewOff, bool isScoped, float isFlashed, int teamnm) :
		key(entityKey), type(typ), health(hp), name(nm ? nm : ""),
		weapon_name(wep_name ? wep_name : ""), position(pos), viewOffset(viewOff), IsScoped(isScoped), IsFlashed(isFlashed), team_num(teamnm) {
	}

	tw::entities::EntityKey key;
	PlayerType_t type;
	int health;
	std::string name;
	std::string weapon_name;
	Vector_t position;
	Vector_t viewOffset;
	bool IsScoped;
	float IsFlashed;
	int team_num;
	// Indexed by the raw BoneID value; only the cross-validated 0..23 range is ever populated.
	std::array<Vector_t, 24> bones{};
	bool bonesValid{};
};

struct WorldEntityCache
{
	tw::entities::EntityKey key;
	tw::features::WorldEntityCategory category;
	std::string label;
	Vector_t position;
};

namespace Esp {
	class Visuals {
	public:
		bool init();
		void buildFrame(float width, float height, std::uint64_t deviceGeneration);
		[[nodiscard]] std::shared_ptr<const tw::renderer::RenderFrame> frame() const noexcept;
	private:
		tw::renderer::FramePublication publication_{};
		std::uint64_t sequence_{};
	};
	void cache();
	void clear_cache();

	// Copied-under-lock view of the same per-frame cache the renderer consumes, safe to read from the command thread.
	struct AimSnapshot final
	{
		bool localValid{};
		Vector_t localEyePosition{};
		Vector_t localVelocity{};
		int localTeam{};
		std::uint64_t epoch{};
		std::vector<PlayerCache> players{};
	};
	[[nodiscard]] AimSnapshot snapshotForAim();
}

extern LocalPlayerCached cached_local;
extern std::vector<PlayerCache> cached_players;
extern std::vector<WorldEntityCache> cached_world_entities;
