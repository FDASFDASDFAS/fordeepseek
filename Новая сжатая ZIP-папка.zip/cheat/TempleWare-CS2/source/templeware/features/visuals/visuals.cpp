#include "visuals.h"
#include "../feedback/hit_feedback.h"
#include <algorithm>
#include <iostream>
#include <mutex>
#include "../../hooks/hooks.h"
#include "../../players/players.h"
#include "../../utils/memory/patternscan/patternscan.h"
#include "../../utils/memory/gaa/gaa.h"
#include "../../../../external/imgui/imgui.h"
#include "../../interfaces/interfaces.h"
#include "../../config/configmanager.h"
#include "../../menu/menu.h"
#include "../../menu/gui/fonts.h"
#include "../../../cs2/entity/C_EntitySystem/entity.h"
#include "../../../cs2/entity/C_PlantedC4/C_PlantedC4.h"
#include <cctype>
#include <cmath>
#include <cstdio>
#include <unordered_set>
using namespace Esp;

LocalPlayerCached cached_local;
std::vector<PlayerCache> cached_players;
std::vector<WorldEntityCache> cached_world_entities;
std::mutex cacheMutex;
viewmatrix_t* sourceViewMatrix{};
viewmatrix_t cachedViewMatrix{};
bool cachedViewMatrixValid{};
std::uint64_t cachedEpoch{};

namespace
{
    bool project(const viewmatrix_t& matrix, const Vector_t& position, const float width, const float height, tw::renderer::Point& output)
    {
        const float w = matrix.matrix[3][0] * position.x + matrix.matrix[3][1] * position.y +
            matrix.matrix[3][2] * position.z + matrix.matrix[3][3];
        if (!std::isfinite(w) || w <= 0.001f || width <= 0.0f || height <= 0.0f)
            return false;
        const float inverse = 1.0f / w;
        const float centerX = width * 0.5f;
        const float centerY = height * 0.5f;
        output.x = centerX + ((matrix.matrix[0][0] * position.x + matrix.matrix[0][1] * position.y +
            matrix.matrix[0][2] * position.z + matrix.matrix[0][3]) * inverse * centerX);
        output.y = centerY - ((matrix.matrix[1][0] * position.x + matrix.matrix[1][1] * position.y +
            matrix.matrix[1][2] * position.z + matrix.matrix[1][3]) * inverse * centerY);
        return std::isfinite(output.x) && std::isfinite(output.y);
    }

    tw::renderer::Color color(const tw::config::Color4& value, const float alpha = -1.0f)
    {
        return { value.r, value.g, value.b, alpha >= 0.0f ? alpha : value.a };
    }

    std::string weaponLabel(std::string value)
    {
        constexpr char prefix[] = "weapon_";
        if (value.compare(0, sizeof(prefix) - 1, prefix) == 0)
            value.erase(0, sizeof(prefix) - 1);
        if (value.empty() || value == "none")
            return {};
        std::transform(value.begin(), value.end(), value.begin(), [](const unsigned char character)
        {
            return character == '_' ? ' ' : static_cast<char>(std::toupper(character));
        });
        return value;
    }
}

bool Visuals::init() {
    const uintptr_t address = M::patternScan("client", "48 8D 0D ? ? ? ? 48 C1 E0 06");
    if (address == 0)
        return false;

    sourceViewMatrix = reinterpret_cast<viewmatrix_t*>(M::getAbsoluteAddress(address, 3, 0));
    return sourceViewMatrix != nullptr;
}

void Esp::cache()
{
    if (!I::EngineClient->valid())
    {
        return;
    }

    std::scoped_lock lock(cacheMutex);
    cached_players.clear();
    cached_world_entities.clear();
	 cached_local.reset();
	 cachedViewMatrixValid = sourceViewMatrix != nullptr;
	 cachedEpoch = g_entitySystem->session_epoch();
	 if (cachedViewMatrixValid)
		 cachedViewMatrix = *sourceViewMatrix;

	 C_CSPlayerPawn* localPlayer = g_ctx->local_pawn;
	 if (localPlayer && localPlayer->m_iHealth() > 0)
	 {
		 cached_local.alive = true;
		 cached_local.poisition = localPlayer->m_vOldOrigin();
		 cached_local.eyePosition = cached_local.poisition + localPlayer->m_vecViewOffset();
		 cached_local.velocity = localPlayer->m_vecAbsVelocity();
		 cached_local.health = localPlayer->m_iHealth();
		 cached_local.handle = localPlayer->handle().index();
		 cached_local.team = localPlayer->m_iTeamNum();
	 }

    auto entities = g_entitySystem->get("CCSPlayerController");

    PlayerType_t type = none;
    std::unordered_set<CEntityInstance*> heldWeapons;
    static std::unordered_map<std::uint32_t, int> previousHealths;

    for (auto entity : entities)
    {
        if (!entity)
            continue;

        auto Controller = reinterpret_cast<CCSPlayerController*>(entity);
        if (!Controller || Controller == g_ctx->local_controller)
            continue;

        type = none; int health = 0;
        Vector_t position; Vector_t viewOffset;
        const char* name = "none"; const char* weapon_name = "";
        bool isScoped; float isFlashed;

        if (!Controller->m_hPawn().valid())
        {
            continue;
        }

        {
            auto Player = I::GameEntity->Instance->Get<C_CSPlayerPawn>(Controller->m_hPawn());
            if (!Player)
                continue;
			auto entityKey = g_entitySystem->key_for(Player);
			if (!entityKey)
				continue;

            if (Player->m_iHealth() <= 0)
            {
                previousHealths.erase(Controller->m_hPawn().index());
                continue;
            }

            health = Player->m_iHealth();
            const std::uint32_t pawnIdx = Controller->m_hPawn().index();
            const auto hpIt = previousHealths.find(pawnIdx);
            if (hpIt != previousHealths.end())
            {
                const int oldHp = hpIt->second;
                // Hit feedback is driven by the player_hurt game event (see
                // tw::events). A health drop observed here cannot tell who dealt
                // the damage, so it also fired for teammate damage, fall damage
                // and kills made by other players entirely.
            }
            previousHealths[pawnIdx] = health;
            name = Controller->m_sSanitizedPlayerName();
            position = Player->m_vOldOrigin(); viewOffset = Player->m_vecViewOffset();
            isScoped = Player->m_bIsScoped(); isFlashed = Player->m_flFlashDuration();

            CCSWeaponBaseVData* pWeaponData = nullptr;
            if (auto pWeaponServices = Player->m_pWeaponServices()) {
                CBaseHandle hWeapon = pWeaponServices->m_hActiveWeapon();
                if (hWeapon.valid()) {
                    if (auto pWeapon = I::GameEntity->Instance->Get<C_CSWeaponBase>(hWeapon)) {
                        pWeaponData = pWeapon->m_pWeaponData();
                        heldWeapons.insert(reinterpret_cast<CEntityInstance*>(pWeapon));
                    }
                }
            }

            if (pWeaponData) {
                weapon_name = pWeaponData->m_szName();
            }
            cached_players.emplace_back(*entityKey, type, health, name,
                weapon_name, position, viewOffset, isScoped, isFlashed, Player->m_iTeamNum());

            auto& cachedPlayer = cached_players.back();
            cachedPlayer.bonesValid = true;
            for (const auto& connection : Bones::connections)
            {
                cachedPlayer.bones[static_cast<int>(connection.bone1)] = GetBonePos(Player, connection.bone1);
                cachedPlayer.bones[static_cast<int>(connection.bone2)] = GetBonePos(Player, connection.bone2);
            }
        }
    }

    auto worldEntities = g_entitySystem->get_matching([](const char* className)
    {
        return tw::features::classifyWorldEntity(className) != tw::features::WorldEntityCategory::Unknown;
    });

    for (auto* worldEntity : worldEntities)
    {
        if (!worldEntity)
            continue;
        const char* className = worldEntity->get_entity_class_name();
        if (!className)
            continue;
        const auto category = tw::features::classifyWorldEntity(className);
        if (category == tw::features::WorldEntityCategory::Unknown)
            continue;

        auto* baseEntity = reinterpret_cast<C_BaseEntity*>(worldEntity);
        // Not currently network-relevant (e.g. PVS-culled): skip regardless of category.
        if (auto* scene = baseEntity->m_pGameSceneNode(); !scene || scene->IsDormant())
            continue;

        std::string label;
        if (category == tw::features::WorldEntityCategory::Item)
        {
            if (heldWeapons.contains(worldEntity))
                continue;
            // Carried or otherwise attached to an owner rather than lying on the ground.
            if (baseEntity->m_hOwnerEntity().valid())
                continue;

            auto* weaponData = baseEntity->m_pWeaponData();
            label = weaponData ? weaponLabel(weaponData->m_szName()) : std::string{};
            if (label.empty())
                continue;
        }
        else if (category == tw::features::WorldEntityCategory::Bomb)
        {
            auto* bomb = reinterpret_cast<C_PlantedC4*>(worldEntity);
            if (bomb->m_bBombDefused())
                continue;

            const std::string site = bomb->m_nBombSite() == 0 ? "A" : "B";
            if (bomb->m_bHasExploded())
            {
                label = "Bomb [" + site + "] exploded";
            }
            else if (I::GlobalVars)
            {
                const float remaining = bomb->m_flC4Blow() - I::GlobalVars->m_current_time;
                if (remaining <= 0.0f)
                {
                    label = "Bomb [" + site + "] exploding";
                }
                else
                {
                    char timeBuffer[16]{};
                    std::snprintf(timeBuffer, sizeof(timeBuffer), "%.1f", remaining);
                    label = "Bomb [" + site + "] " + (bomb->m_bBeingDefused() ? "defusing " : "") + timeBuffer + "s";
                }
            }
            else
            {
                label = "Planted C4";
            }
        }
        else
        {
            label = tw::features::worldEntityLabel(className);
        }

        auto entityKey = g_entitySystem->key_for(worldEntity);
        if (!entityKey)
            continue;

        cached_world_entities.push_back({ *entityKey, category, std::move(label), baseEntity->origin() });
    }
}

void Esp::clear_cache()
{
    std::scoped_lock lock(cacheMutex);
    cached_players.clear();
    cached_world_entities.clear();
    cached_local.reset();
	cachedViewMatrixValid = false;
	cachedEpoch = 0;
}

Esp::AimSnapshot Esp::snapshotForAim()
{
    std::scoped_lock lock(cacheMutex);
    AimSnapshot snapshot{};
    snapshot.localValid = cached_local.alive;
	snapshot.localEyePosition = cached_local.eyePosition;
	snapshot.localVelocity = cached_local.velocity;
    snapshot.localTeam = cached_local.team;
    snapshot.epoch = cachedEpoch;
    snapshot.players = cached_players;
    return snapshot;
}

void Visuals::buildFrame(const float width, const float height, const std::uint64_t deviceGeneration) {
    tw::renderer::RenderFrame frame{};
    frame.deviceGeneration = deviceGeneration;
    frame.sequence = ++sequence_;
    const auto settings = internal_config::ConfigManager::Snapshot();
    const auto& config = settings->esp;
    std::vector<PlayerCache> players;
    std::vector<WorldEntityCache> worldEntities;
    LocalPlayerCached local;
	viewmatrix_t matrix{};
    {
        std::scoped_lock lock(cacheMutex);
		frame.sessionEpoch = cachedEpoch;
		const bool anyPlayerEsp = config.box || config.health || config.fill || config.names ||
			config.flashed || config.scoped || config.weapon || config.skeleton;
		const bool anyWorldEsp = config.items || config.grenades || config.bomb;
		if (!cachedViewMatrixValid)
		{
			publication_.publish(std::move(frame));
            return;
		}
        players = cached_players;
        worldEntities = cached_world_entities;
        local = cached_local;
		matrix = cachedViewMatrix;
    }

    for (const auto& player : players)
    {
        if (player.key.epoch != frame.sessionEpoch || player.health <= 0)
            continue;
        if (config.teamCheck && player.team_num == local.team)
            continue;

        tw::renderer::Point feetScreen{};
        tw::renderer::Point headScreen{};
        if (!project(matrix, player.position, width, height, feetScreen) ||
            !project(matrix, player.position + player.viewOffset, width, height, headScreen))
            continue;

        const float boxHeight = (feetScreen.y - headScreen.y) * 1.3f;
        if (!std::isfinite(boxHeight) || boxHeight <= 1.0f)
            continue;
        const float boxWidth = boxHeight * 0.5f;
        const float centerX = (feetScreen.x + headScreen.x) * 0.5f;
        const float boxX = centerX - boxWidth * 0.5f;
        const float boxY = headScreen.y - (boxHeight - (feetScreen.y - headScreen.y)) * 0.5f;
        const tw::renderer::Point minimum{ boxX, boxY };
        const tw::renderer::Point maximum{ boxX + boxWidth, boxY + boxHeight };

        if (config.skeleton && player.bonesValid)
        {
            for (const auto& connection : Bones::connections)
            {
                tw::renderer::Point from{};
                tw::renderer::Point to{};
                if (!project(matrix, player.bones[static_cast<int>(connection.bone1)], width, height, from) ||
                    !project(matrix, player.bones[static_cast<int>(connection.bone2)], width, height, to))
                    continue;
                frame.commands.emplace_back(tw::renderer::Line{ from, to, color(config.skeletonColor), config.skeletonThickness });
            }
        }

        if (config.fill)
            frame.commands.emplace_back(tw::renderer::Rectangle{ minimum, maximum, color(config.color, config.fillOpacity), 1.0f, true });
        if (config.box)
            frame.commands.emplace_back(tw::renderer::Rectangle{ minimum, maximum, color(config.color), config.thickness, false });

        const tw::renderer::Color white{ 1.0f, 1.0f, 1.0f, 1.0f };
        const tw::renderer::Color black{ 0.0f, 0.0f, 0.0f, 1.0f };
        // Every player-attached label draws at the small ESP size, and the row
        // spacing follows from it rather than from the old hardcoded 14px, which
        // was sized for the 13px default font.
        constexpr float espText = fonts::kEspSize;
        constexpr float espRow = espText + 2.0f;

        float bottomOffset = 2.0f;
        float statusY = boxY + boxHeight * 0.5f - espRow * 0.5f;
        if (config.scoped && player.IsScoped)
        {
            frame.commands.emplace_back(tw::renderer::Text{ { boxX + boxWidth + 6.0f, statusY }, white, "SCOPE", false, espText });
            statusY += espRow;
        }
        if (config.flashed && player.IsFlashed != 0.0f)
            frame.commands.emplace_back(tw::renderer::Text{ { boxX + boxWidth + 6.0f, statusY }, white, "BLIND", false, espText });

        // Health is the bar alone. The "[100HP]" label under the player was
        // duplicating what the bar already shows.
        if (config.health)
        {
            const int health = std::clamp(player.health, 0, 100);
            const float healthHeight = boxHeight * (static_cast<float>(health) / 100.0f);
            const float barX = boxX - 6.0f;
            frame.commands.emplace_back(tw::renderer::Rectangle{ { barX, boxY }, { barX + 4.0f, boxY + boxHeight },
                { 0.27f, 0.27f, 0.27f, 1.0f }, 1.0f, true });
            frame.commands.emplace_back(tw::renderer::Rectangle{ { barX, boxY + boxHeight - healthHeight }, { barX + 4.0f, boxY + boxHeight },
                { (100.0f - health) / 100.0f, health / 100.0f, 0.0f, 1.0f }, 1.0f, true });
        }

        if (config.weapon)
        {
            const std::string label = weaponLabel(player.weapon_name);
            if (!label.empty())
            {
                const tw::renderer::Point labelPosition{ centerX, boxY + boxHeight + bottomOffset };
                frame.commands.emplace_back(tw::renderer::Text{ { labelPosition.x + 1.0f, labelPosition.y + 1.0f }, black, label, true, espText });
                frame.commands.emplace_back(tw::renderer::Text{ labelPosition, white, label, true, espText });
            }
        }

        if (config.names)
        {
            const tw::renderer::Point namePosition{ centerX, boxY - (espRow + 2.0f) };
            frame.commands.emplace_back(tw::renderer::Text{ { namePosition.x + 1.0f, namePosition.y + 1.0f }, black, player.name, true, espText });
            frame.commands.emplace_back(tw::renderer::Text{ namePosition, white, player.name, true, espText });
        }
    }

    const tw::renderer::Color black{ 0.0f, 0.0f, 0.0f, 1.0f };
    for (const auto& worldEntity : worldEntities)
    {
        if (worldEntity.key.epoch != frame.sessionEpoch)
            continue;
        const bool enabled = (worldEntity.category == tw::features::WorldEntityCategory::Item && config.items) ||
            (worldEntity.category == tw::features::WorldEntityCategory::Grenade && config.grenades) ||
            (worldEntity.category == tw::features::WorldEntityCategory::Bomb && config.bomb);
        if (!enabled)
            continue;

        tw::renderer::Point screen{};
        if (!project(matrix, worldEntity.position, width, height, screen))
            continue;

        // Verified world-units-to-meters display scale (velocity-main reference), not the raw 1
        // in = 0.0254 m conversion -- CS2 ESP distance display doesn't use the literal inch scale.
        const float distance = (worldEntity.position - local.poisition).Length() * 0.01905f;
        const std::string text = worldEntity.label + " [" + std::to_string(static_cast<int>(distance)) + "m]";
        const tw::renderer::Color labelColor = worldEntity.category == tw::features::WorldEntityCategory::Bomb
            ? tw::renderer::Color{ 1.0f, 0.25f, 0.25f, 1.0f }
            : worldEntity.category == tw::features::WorldEntityCategory::Grenade
                ? tw::renderer::Color{ 1.0f, 0.55f, 0.0f, 1.0f }
                : tw::renderer::Color{ 1.0f, 1.0f, 1.0f, 1.0f };
        frame.commands.emplace_back(tw::renderer::Text{ { screen.x + 1.0f, screen.y + 1.0f }, black, text, true });
        frame.commands.emplace_back(tw::renderer::Text{ screen, labelColor, text, true });
    }

    const double nowSeconds = I::GlobalVars ? static_cast<double>(I::GlobalVars->m_current_time) : 0.0;
    tw::features::g_hitFeedback.renderOverlay(frame.commands, matrix, width, height, nowSeconds);

    publication_.publish(std::move(frame));
}

std::shared_ptr<const tw::renderer::RenderFrame> Visuals::frame() const noexcept {
    return publication_.consume();
}
