#include "../../../hooks/hooks.h"
#include "../../../config/configmanager.h"

// Not currently hooked -- see hooks.h. Anti-flash actually runs as a schema write in
// hkFrameStageNotify (hooks.cpp), not through this function.
void __fastcall H::hkRenderFlashbangOverlay(void* a1, void* a2, void* a3, void* a4, void* a5) {
	Runtime::CallbackGuard callback;
	if (Runtime::IsShuttingDown())
		return RenderFlashBangOverlay.GetOriginal()(a1, a2, a3, a4, a5);

	if (internal_config::ConfigManager::Snapshot()->world.antiFlash) return;
	return RenderFlashBangOverlay.GetOriginal()(a1, a2, a3, a4, a5);
}
