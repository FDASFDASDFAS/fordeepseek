#include "../../../hooks/hooks.h"
#include "../../../config/configmanager.h"

float H::hkGetRenderFov(void* rcx) {
	Runtime::CallbackGuard callback;
	if (Runtime::IsShuttingDown())
		return GetRenderFov.GetOriginal()(rcx);

	const auto settings = internal_config::ConfigManager::Snapshot();
	if (settings->world.customFov) {
		float flTargetFov = settings->world.fov;
		g_flActiveFov = flTargetFov;
	}else
		g_flActiveFov = H::GetRenderFov.GetOriginal()(rcx);

	return g_flActiveFov;
}
