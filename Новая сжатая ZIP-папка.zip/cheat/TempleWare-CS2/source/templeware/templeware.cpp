#include "templeware.h"

#include "utils/module/module.h"
#include "../cs2/entity/C_EntitySystem/entity.h"
#include "features/feedback/hit_feedback.h"
#include "features/events/game_events.h"
#include "features/tracing/tracing.h"
#include "features/hitboxes/hitboxes.h"
#include "features/smokes/smokes.h"
#include "features/model_preview/model_preview.h"
#include "../velocity/bootstrap/bootstrap.h"

#include <iostream>

bool TempleWare::init(HWND& window, ID3D11Device* pDevice, ID3D11DeviceContext* pContext, ID3D11RenderTargetView* mainRenderTargetView) {
    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);

    auto printWithPrefix = [&](const char* message) {
        std::cout << "[";
        SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | FOREGROUND_INTENSITY);
        std::cout << "+";
        SetConsoleTextAttribute(hConsole, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
        std::cout << "] " << message << std::endl;
        };

    printWithPrefix("Initializing modules...");
    modules.init();

    printWithPrefix("Initializing menu...");
    if (!renderer.menu.init(window, pDevice, pContext, mainRenderTargetView))
        return false;
	const auto rollback = [this]()
	{
		tw::events::shutdown();
		tw::model_preview::shutdown();
		hooks.shutdown();
		g_entitySystem->level_shutdown();
		Esp::clear_cache();
		renderer.specList.Clear();
		renderer.menu.shutdown();
	};

    printWithPrefix("Initializing schema...");
    if (!schema.init("client.dll", 0))
	{
		rollback();
        return false;
	}

	// Model geometry (CHitBox / CHitBoxSet / PermModelData_t) is declared in
	// animationsystem.dll's scope, not client.dll's. Optional: hitbox queries
	// fall back to static offsets if it is unavailable, and nothing else uses it.
	if (!schema.init("animationsystem.dll", 0))
		std::cout << "[!] animationsystem schema unavailable - hitboxes use fallback offsets" << std::endl;
	if (!SchemaFinder::Validate({
		hash_32_fnv1a_const("CEntityIdentity->m_flags"),
		hash_32_fnv1a_const("CEntityInstance->m_pEntity"),
		hash_32_fnv1a_const("CBasePlayerController->m_hPawn"),
		hash_32_fnv1a_const("CCSPlayerController->m_hObserverPawn"),
		hash_32_fnv1a_const("CCSPlayerController->m_sSanitizedPlayerName"),
		hash_32_fnv1a_const("CCSPlayerController->m_bPawnIsAlive"),
		hash_32_fnv1a_const("C_BaseEntity->m_iHealth"),
		hash_32_fnv1a_const("C_BaseEntity->m_iTeamNum"),
		hash_32_fnv1a_const("C_BaseEntity->m_fFlags"),
		hash_32_fnv1a_const("C_BaseEntity->m_MoveType"),
		hash_32_fnv1a_const("C_BaseEntity->m_vecAbsVelocity"),
		hash_32_fnv1a_const("C_BasePlayerPawn->m_hController"),
		hash_32_fnv1a_const("C_BasePlayerPawn->m_vOldOrigin"),
		hash_32_fnv1a_const("C_BaseModelEntity->m_vecViewOffset"),
		hash_32_fnv1a_const("C_CSPlayerPawn->m_bIsScoped"),
		hash_32_fnv1a_const("C_CSPlayerPawnBase->m_flFlashDuration"),
		hash_32_fnv1a_const("C_BasePlayerPawn->m_pWeaponServices"),
		hash_32_fnv1a_const("C_BasePlayerPawn->m_pObserverServices"),
		hash_32_fnv1a_const("CPlayer_ObserverServices->m_hObserverTarget"),
		hash_32_fnv1a_const("CPlayer_WeaponServices->m_hActiveWeapon"),
		hash_32_fnv1a_const("CCSPlayer_WeaponServices->m_flNextAttack"),
		hash_32_fnv1a_const("C_BasePlayerWeapon->m_iClip1"),
		hash_32_fnv1a_const("C_CSWeaponBase->m_bInReload"),
		hash_32_fnv1a_const("C_BasePlayerWeapon->m_nNextPrimaryAttackTick") }))
	{
		rollback();
		return false;
	}

    printWithPrefix("Initializing Interfaces...");
    if (!interfaces.init())
	{
		rollback();
        return false;
	}

    g_entitySystem->initialize();

    printWithPrefix("Initializing visuals...");
    if (!renderer.visuals.init())
	{
		rollback();
        return false;
	}

	printWithPrefix("Initializing chams materials...");
    if (!materials.init())
        std::cout << "[!] Chams materials failed to create" << std::endl;
    else
        std::cout << "  Chams: flat, illuminate, glow materials created" << std::endl;

    printWithPrefix("Initializing hit sounds...");
    tw::features::HitFeedback::initHitSounds();

    printWithPrefix("Initializing game events...");
    tw::events::init();

    printWithPrefix("Initializing tracing...");
    tw::tracing::init();

    printWithPrefix("Initializing hitboxes...");
    tw::hitboxes::init();

    // After the client.dll schema dump: C_SmokeGrenadeProjectile lives in that
    // scope. Optional -- an unresolved field leaves smoke checks passing
    // through rather than blocking startup.
    printWithPrefix("Initializing smoke volumes...");
    tw::smokes::init();

    // After the schema dump (SCHEMA() reads through SchemaFinder) and after
    // tracing, which systems::tracing now forwards to. Read-only: resolves
    // addresses and hooks nothing, so an unresolved signature reports rather
    // than breaks startup.
    printWithPrefix("Initializing velocity addresses...");
    velocity::initializeAddresses();

    printWithPrefix("Initializing hooks...");
	if (!hooks.init())
	{
		rollback();
        return false;
	}

	// Last because these optional hooks live outside Hooks and must never be
	// removed by the early-init rollback while callbacks can already be active.
	printWithPrefix("Initializing model preview...");
	tw::model_preview::init();

    printWithPrefix("Success...");
    return true;
}
