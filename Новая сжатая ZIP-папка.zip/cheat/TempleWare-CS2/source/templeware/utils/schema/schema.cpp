#include "schema.h"
#include <vector>
#include <algorithm>
#include <Shlobj.h>
#include <shlobj_core.h>


#include "../fnv1a/fnv1a.h"

#include "../math/utlstring/utlstring.h"
#include "../memory/Interface/Interface.h"

struct SchemaDumpedData_t
{
    uint32_t hashedName = 0x0ULL;
    std::uint32_t uOffset = 0x0U;
};

static std::vector<SchemaDumpedData_t> dumped_data;

bool Schema::init(const char* ModuleName, int module_type)
{
    schema_system = I::Get<ISchemaSystem>("schemasystem.dll", "SchemaSystem_00");
    if (!schema_system)
        return false;

    CSchemaSystemTypeScope* pTypeScope = schema_system->FindTypeScopeForModule(ModuleName);
    if (!pTypeScope)
    {
        printf("[Schema] no type scope for %s\n", ModuleName);
        return false;
    }

    uint8_t* pScope = reinterpret_cast<uint8_t*>(pTypeScope);

    // CORRECT: Use uint16_t for the count
    uint16_t nClasses = *reinterpret_cast<uint16_t*>(pScope + 0x470);
    void* pArray = *reinterpret_cast<void**>(pScope + 0x478);

    if (nClasses == 0 || !pArray)
    {
        printf("[Schema] %s: empty scope\n", ModuleName);
        return false;
    }

    // Appended, not assigned: hitbox/model geometry lives in animationsystem.dll's
    // scope while entity fields live in client.dll's, and both are needed. Get()
    // returns the first match, so whichever module is dumped first wins a name
    // collision -- dump client.dll first to keep entity lookups stable.
    const std::size_t before = dumped_data.size();
    uint8_t* pEntries = reinterpret_cast<uint8_t*>(pArray);

    for (int i = 0; i < nClasses; i++)
    {
        uint8_t* entry = pEntries + (i * 0x18);
        void* pDecl = *reinterpret_cast<void**>(entry + 0x10);
        if (!pDecl) continue;

        const char* szClassName = *reinterpret_cast<const char**>(reinterpret_cast<uint8_t*>(pDecl) + 0x08);
        SchemaClassInfoData_t* pClassInfo = *reinterpret_cast<SchemaClassInfoData_t**>(reinterpret_cast<uint8_t*>(pDecl) + 0x20);

        if (!szClassName || !pClassInfo || pClassInfo->nFieldSize == 0)
            continue;

        for (int j = 0; j < pClassInfo->nFieldSize; j++)
        {
            SchemaClassFieldData_t* pFields = pClassInfo->pFields;
            if (!pFields || !pFields[j].szName) continue;

            std::string szFieldClassBuffer = std::string(szClassName) + "->" + std::string(pFields[j].szName);
            dumped_data.emplace_back(hash_32_fnv1a_const(szFieldClassBuffer.c_str()), pFields[j].nSingleInheritanceOffset);
        }
    }

    printf("[Schema] %s: %u classes, %zu fields\n",
        ModuleName, nClasses, dumped_data.size() - before);
    return true;
}

std::uint32_t SchemaFinder::Get(const uint32_t hashedName)
{
    for (size_t i = 0; i < dumped_data.size(); i++) {
        if (dumped_data[i].hashedName == hashedName) {
            return dumped_data[i].uOffset;
        }
    }

    return 0U;
}

std::uint32_t SchemaFinder::GetOr(const uint32_t hashedName, const std::uint32_t fallback)
{
    for (size_t i = 0; i < dumped_data.size(); i++) {
        if (dumped_data[i].hashedName == hashedName) {
            return dumped_data[i].uOffset;
        }
    }

    return fallback;
}

bool SchemaFinder::Has(const std::uint32_t hashedName)
{
    return std::any_of(dumped_data.begin(), dumped_data.end(), [hashedName](const SchemaDumpedData_t& data)
    {
        return data.hashedName == hashedName;
    });
}

bool SchemaFinder::Validate(const std::initializer_list<std::uint32_t> required)
{
    return std::all_of(required.begin(), required.end(), [](const std::uint32_t hash)
    {
        return Has(hash);
    });
}
