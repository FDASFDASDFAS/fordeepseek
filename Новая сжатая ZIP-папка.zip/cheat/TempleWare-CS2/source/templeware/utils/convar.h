#pragma once

#include <Windows.h>

#include <cstddef>
#include <cstdint>
#include <cstring>

namespace tw::convars
{
    inline void* findRegistered(const char* moduleName, const char* name)
    {
        const auto base = reinterpret_cast<std::uint8_t*>(GetModuleHandleA(moduleName));
        if (!base)
            return nullptr;

        const auto dos = reinterpret_cast<PIMAGE_DOS_HEADER>(base);
        if (dos->e_magic != IMAGE_DOS_SIGNATURE)
            return nullptr;
        const auto nt = reinterpret_cast<PIMAGE_NT_HEADERS>(base + dos->e_lfanew);
        if (nt->Signature != IMAGE_NT_SIGNATURE)
            return nullptr;

        const std::size_t size = nt->OptionalHeader.SizeOfImage;
        const std::size_t nameLen = std::strlen(name);
        if (nameLen + 2 >= size)
            return nullptr;

        const std::uint8_t* nameAddress = nullptr;
        for (std::size_t i = 1; i + nameLen + 1 < size; ++i)
        {
            if (base[i - 1] != 0 || base[i] != static_cast<std::uint8_t>(name[0]))
                continue;
            if (std::memcmp(base + i, name, nameLen) == 0 && base[i + nameLen] == 0)
            {
                nameAddress = base + i;
                break;
            }
        }
        if (!nameAddress)
            return nullptr;

        for (std::size_t i = 0; i + 14 < size; ++i)
        {
            if (base[i] != 0x48 || base[i + 1] != 0x8D || base[i + 2] != 0x15)
                continue;

            const auto nameDisplacement = *reinterpret_cast<const std::int32_t*>(base + i + 3);
            if (base + i + 7 + nameDisplacement != nameAddress)
                continue;

            for (std::size_t j = i + 7; j + 7 <= i + 31 && j + 7 < size; ++j)
            {
                const std::uint8_t* objectLea = base + j;
                if (objectLea[0] != 0x48 || objectLea[1] != 0x8D || objectLea[2] != 0x0D)
                    continue;

                const auto objectDisplacement = *reinterpret_cast<const std::int32_t*>(objectLea + 3);
                return const_cast<std::uint8_t*>(objectLea + 7 + objectDisplacement);
            }
        }

        return nullptr;
    }

    inline void* findRegisteredData(const char* moduleName, const char* name)
    {
        const auto object = findRegistered(moduleName, name);
        if (!object)
            return nullptr;

        void* data{};
        SIZE_T bytesRead{};
        if (!ReadProcessMemory(GetCurrentProcess(), static_cast<const std::uint8_t*>(object) + 0x08,
            &data, sizeof(data), &bytesRead) || bytesRead != sizeof(data) || !data)
        {
            return nullptr;
        }

        std::uint64_t valueProbe{};
        if (!ReadProcessMemory(GetCurrentProcess(), static_cast<const std::uint8_t*>(data) + 0x58,
            &valueProbe, sizeof(valueProbe), &bytesRead) || bytesRead != sizeof(valueProbe))
        {
            return nullptr;
        }

        return data;
    }

    inline void* findRegisteredData(const char* name)
    {
        constexpr const char* modules[]
        {
            "server.dll",
            "client.dll",
            "engine2.dll",
            "soundsystem.dll"
        };

        for (const auto* module : modules)
        {
            if (auto* data = findRegisteredData(module, name))
                return data;
        }

        return nullptr;
    }
}
