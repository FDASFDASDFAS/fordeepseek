#pragma once

// Stand-in for velocity's utilities/threadpool, providing only parallel_for --
// the one entry point the combat code uses (rage::scan_players).
//
// DEFAULTS TO SERIAL, deliberately.
//
// Upstream fans the per-target scan across a pool. The output side is race-free
// (each candidate writes its own slot), but the scan reaches into
// lagcomp::record::apply()/restore(), which MUTATES live game state -- bone
// caches on the entity being scanned. Two threads applying records to the same
// entity is a data race on the game's own memory, and none of this is runtime-
// testable yet because no hooks are wired.
//
// So: same call shape and same iteration semantics, executed in order. Flip
// k_parallel once the combat path actually runs and the apply/restore
// interaction has been checked; the split logic below is already correct.

#include <algorithm>
#include <cstddef>
#include <thread>
#include <vector>

namespace threadpool {

	inline constexpr bool k_parallel{ false };

	// Invokes fn(begin, end) over sub-ranges covering [first, last).
	//
	// min_chunk_size matches upstream's parameter: no sub-range smaller than
	// this, so tiny workloads are not split across threads. Upstream also took a
	// job_priority; there is no pool here for it to mean anything, so it is
	// omitted rather than accepted and ignored.
	template <typename fn_t>
	void parallel_for( int first, int last, fn_t&& fn, int min_chunk_size = 1 )
	{
		if ( last <= first )
		{
			return;
		}

		if constexpr ( !k_parallel )
		{
			fn( first, last );
			return;
		}
		else
		{
			const auto total = last - first;
			const auto hw = static_cast< int >( std::thread::hardware_concurrency( ) );
			const auto by_chunk = total / std::max( min_chunk_size, 1 );
			const auto workers = std::clamp( std::min( hw ? hw : 1, std::max( by_chunk, 1 ) ), 1, total );

			if ( workers == 1 )
			{
				fn( first, last );
				return;
			}

			const auto chunk = ( total + workers - 1 ) / workers;

			std::vector<std::thread> threads{};
			threads.reserve( static_cast< std::size_t >( workers ) );

			for ( auto i = 0; i < workers; ++i )
			{
				const auto b = first + i * chunk;
				const auto e = std::min( b + chunk, last );

				if ( b >= e )
				{
					break;
				}

				threads.emplace_back( [ &fn, b, e ] { fn( b, e ); } );
			}

			for ( auto& t : threads )
			{
				t.join( );
			}
		}
	}

} // namespace threadpool
