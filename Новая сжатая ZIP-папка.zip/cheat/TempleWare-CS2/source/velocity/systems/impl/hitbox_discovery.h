#pragma once

#include <cstdint>

namespace systems::hitbox_discovery {

	// Off by default. The chain this probe discovered is now baked into
	// systems::hitboxes::query, so it has no job in normal operation -- and it
	// walks hundreds of guarded reads per distinct model, which does not belong
	// in the trace path.
	//
	// Set true to re-run it after a game update: the "chain check" line reports
	// MATCH/MISMATCH against the live layout, which is the cheapest way to find
	// out whether the offsets still hold.
	inline bool g_enabled{ false };

	// One-shot diagnostic: given a CHitBox pointer the game itself produced
	// (tw::tracing returns it at CGameTrace+0x10) plus the owning entity's
	// game scene node, recover and log the path from the model to the
	// CHitBoxSetList.
	//
	// Deduplicates per array base, so wiring it into a hot trace path is safe --
	// it logs once per distinct player model and then goes quiet.
	//
	// Call site: anywhere a trace comes back with a non-null hitboxData against
	// a player. tw::tracing::Result already carries both halves.
	void report( std::uintptr_t struck_hitbox, std::uintptr_t game_scene_node );

} // namespace systems::hitbox_discovery
