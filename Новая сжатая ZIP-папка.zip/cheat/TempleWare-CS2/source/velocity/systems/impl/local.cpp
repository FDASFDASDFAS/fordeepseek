#include "../systems.hpp"

namespace systems {

	void local::update( )
	{
		const auto local_player_controller = memory::read_or<std::uintptr_t>( addresses::globals::local_player_controller );
		if ( !local_player_controller )
		{
			this->reset( );
			return;
		}

		const auto pawn_handle = memory::read_or<std::uint32_t>( local_player_controller + SCHEMA( "CCSPlayerController", "m_hPlayerPawn" ) );
		if ( !pawn_handle )
		{
			this->reset( );
			return;
		}

		const auto pawn = g_entities.lookup( pawn_handle );
		if ( !pawn )
		{
			this->reset( );
			return;
		}

		snapshot s{};
		s.controller = local_player_controller;
		s.pawn = pawn;
		s.team = memory::read_or<int>( pawn + SCHEMA( "C_BaseEntity", "m_iTeamNum" ) );

		const auto health = memory::read_or<int>( pawn + SCHEMA( "C_BaseEntity", "m_iHealth" ) );
		const auto life_state = memory::read_or<std::uint8_t>( pawn + SCHEMA( "C_BaseEntity", "m_lifeState" ) );
		s.is_alive = health > 0 && life_state == 0;

		if ( s.is_alive )
		{
			s.view_team = s.team;
		}
		else
		{
			const auto observer_pawn_handle = memory::read_or<std::uint32_t>( local_player_controller + SCHEMA( "CCSPlayerController", "m_hObserverPawn" ) );
			if ( observer_pawn_handle )
			{
				const auto observer_pawn = g_entities.lookup( observer_pawn_handle );
				if ( observer_pawn )
				{
					const auto observer_services = memory::read_or<std::uintptr_t>( observer_pawn + SCHEMA( "C_BasePlayerPawn", "m_pObserverServices" ) );
					if ( observer_services )
					{
						const auto observer_target_handle = memory::read_or<std::uint32_t>( observer_services + SCHEMA( "CPlayer_ObserverServices", "m_hObserverTarget" ) );
						if ( observer_target_handle )
						{
							const auto observer_target = g_entities.lookup( observer_target_handle );
							if ( observer_target )
							{
								s.observer_pawn = observer_target;
								s.view_team = memory::read_or<int>( observer_target + SCHEMA( "C_BaseEntity", "m_iTeamNum" ) );

								const auto observer_target_controller_handle = memory::read_or<std::uint32_t>( observer_target + SCHEMA( "C_BasePlayerPawn", "m_hController" ) );
								if ( observer_target_controller_handle )
								{
									const auto observer_target_controller = g_entities.lookup( observer_target_controller_handle );
									if ( observer_target_controller )
									{
										s.observer_controller = observer_target_controller;
									}
								}
							}
						}
					}
				}
			}

			if ( !s.observer_pawn )
			{
				s.view_team = s.team;
			}
		}

		{
			// CONVAR yields nullptr when the cvar interface is unavailable or the
			// name is not registered yet -- which is the norm during map load,
			// exactly when this first runs. Upstream dereferenced it directly.
			const auto* const type_cv = CONVAR( "game_type" );
			const auto* const mode_cv = CONVAR( "game_mode" );

			const auto game_type = type_cv ? type_cv->m_value.i32 : 0;
			const auto game_mode = mode_cv ? mode_cv->m_value.i32 : 0;
			const auto is_ffa = ( game_type == 1 && game_mode == 2 ) || ( game_type == 2 && game_mode == 0 );

			s.is_team_mode = !is_ffa;

			this->m_is_deathmatch.store( game_type == 1 && game_mode == 2 );
		}

		{
			const auto game_rules = memory::read_or<std::uintptr_t>( addresses::globals::game_rules );
			const auto global_vars = memory::read_or<std::uintptr_t>( addresses::globals::global_vars );

			auto cinematic{ false };
			auto freezetime{ false };

			if ( game_rules && global_vars )
			{
				if ( memory::read_or<bool>( game_rules + SCHEMA( "C_CSGameRules", "m_bTeamIntroPeriod" ) ) )
				{
					cinematic = true;
				}
				else if ( memory::read_or<int>( game_rules + SCHEMA( "C_CSGameRules", "m_gamePhase" ) ) >= 4 )
				{
					cinematic = true;
				}

				if ( memory::read_or<bool>( game_rules + SCHEMA( "C_CSGameRules", "m_bFreezePeriod" ) ) )
				{
					freezetime = true;
				}
				else
				{
					const auto round_start_time = memory::read_or<float>( game_rules + SCHEMA( "C_CSGameRules", "m_fRoundStartTime" ) );
					const auto current_time = memory::read_or<float>( global_vars + 0x30 );

					if ( round_start_time > current_time )
					{
						freezetime = true;
					}
				}
			}

			this->m_is_in_cinematic.store( cinematic );
			this->m_is_in_time_freeze.store( freezetime );
		}

		{
			std::unique_lock lock( this->m_mtx );
			this->m_snapshot = s;
		}
	}

	void local::reset( )
	{
		{
			std::unique_lock lock( this->m_mtx );
			this->m_snapshot = {};
		}

		this->m_is_deathmatch.store( false );
		this->m_is_in_cinematic.store( false );
		this->m_is_in_time_freeze.store( false );
	}

} // namespace systems