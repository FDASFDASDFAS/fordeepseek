#include "../systems.hpp"

#include <algorithm>
#include <cctype>

namespace systems {

	namespace {

		// Resolved live on build 14172 by hitbox_discovery.cpp. The BFS found the
		// same path from two independent player entities:
		//
		//   scene_node + m_modelState (0x140)          -- EMBEDDED, do not deref
		//              + m_hModel     (0x0a0)  -> CStrongHandle
		//   *handle                            -> PermModelData_t
		//   PermModelData_t + 0x78             -> m_refMeshes elements (elements-first)
		//   [0]                                -> mesh
		//   mesh + 0x168                       -> hitbox set
		//   set  + 0x28  = count
		//   set  + 0x30  = CHitBox array, stride 0x70
		//
		// velocity had every one of these right except the mesh offset, where it
		// used 0x150. TempleWare's own older header said 0x168 and was correct.
		constexpr std::size_t k_mesh_hitbox_set{ 0x168 };
		constexpr std::size_t k_set_count{ 0x28 };
		constexpr std::size_t k_set_array{ 0x30 };
		constexpr std::size_t k_hitbox_stride{ 0x70 };

		// Field offsets within CHitBox, from animationsystem.dll's schema and
		// confirmed against live data.
		constexpr std::size_t k_mins{ 0x18 };
		constexpr std::size_t k_maxs{ 0x24 };
		constexpr std::size_t k_radius{ 0x30 };
		constexpr std::size_t k_bone_hash{ 0x34 };
		constexpr std::size_t k_group{ 0x38 };
		constexpr std::size_t k_shape{ 0x3C };
		constexpr std::size_t k_translation_only{ 0x3D };

		// Bone names come from the RENDER skeleton, which lives in the same object
		// as the hitboxes. Resolved live, not from the schema:
		//
		//   mesh + 0xE8            -> RenderSkeletonBone_t[]   (NOT 0xE0)
		//   RenderSkeletonBone_t   =  0x60 bytes, m_boneName (a char*) at 0x00
		//
		// The schema says CRenderMesh+0xE0 is m_skeleton and CRenderSkeleton+0x00
		// is m_bones, which would put the array at 0xE0. Live, 0xE0 holds the bone
		// COUNT in its low dword (48 and 65 on two models, matching a count read
		// at 0xF0) with a float above it. The array pointer is at 0xE8.
		//
		// Element 0 is "root_motion" and pelvis is element 1 -- established by
		// walking backward from a located name rather than assuming the first hit
		// was the base. Taking the scan's hit as the base would have shifted every
		// bone index by one and aimed each hitbox at its neighbouring bone.
		//
		// The mesh holds several skeletons (weapon/attachment/LOD variants were
		// found at +0x140, +0x368, +0x3c0, matching only 8-13 of 19 hitboxes).
		// +0xE8 is the player skeleton: it resolves all 19.
		constexpr std::size_t k_mesh_bone_array{ 0xE8 };
		constexpr std::size_t k_render_bone_stride{ 0x60 };
		constexpr std::size_t k_max_bones{ 256 };
		constexpr std::size_t k_bone_name{ 0x10 };

		template <typename T>
		[[nodiscard]] std::optional<T> read_at( std::uintptr_t address )
		{
			if ( !address )
			{
				return std::nullopt;
			}

			return memory::safe_read<T>( address );
		}

		[[nodiscard]] std::string safe_cstr( std::uintptr_t address, std::size_t max_len = 64 )
		{
			if ( !address )
			{
				return {};
			}

			std::string out{};

			for ( std::size_t i = 0; i < max_len; ++i )
			{
				const auto c = memory::safe_read<char>( address + i );
				if ( !c || *c == '\0' )
				{
					break;
				}

				if ( *c < 0x20 || *c > 0x7e )
				{
					return {};
				}

				out.push_back( *c );
			}

			return out;
		}

		// Bone names differ in case between the two sources: CHitBox spells it
		// "leg_upper_l", the render skeleton "leg_upper_L". An exact compare
		// resolves nothing at all.
		[[nodiscard]] bool iequals( const std::string& a, const std::string& b )
		{
			if ( a.size( ) != b.size( ) || a.empty( ) )
			{
				return false;
			}

			return std::equal( a.begin( ), a.end( ), b.begin( ),
				[]( char x, char y )
				{
					return std::tolower( static_cast< unsigned char >( x ) )
						== std::tolower( static_cast< unsigned char >( y ) );
				} );
		}

		// Render-skeleton bone names, cached per mesh. Resolving these costs a
		// string read per bone; redoing it for every hitbox on every scan would be
		// needless work in the aimbot's hot path.
		//
		// The array is walked until a name stops reading rather than bounded by a
		// count field -- the count that would have come from the schema's declared
		// layout is exactly what turned out to be wrong here.
		[[nodiscard]] const std::vector<std::string>& bone_names_for( std::uintptr_t mesh )
		{
			static std::unordered_map<std::uintptr_t, std::vector<std::string>> cache{};
			static std::mutex mtx{};

			std::scoped_lock lock( mtx );

			if ( const auto it = cache.find( mesh ); it != cache.end( ) )
			{
				return it->second;
			}

			std::vector<std::string> names{};

			if ( const auto array = read_at<std::uintptr_t>( mesh + k_mesh_bone_array ); array && *array )
			{
				for ( std::size_t i = 0; i < k_max_bones; ++i )
				{
					const auto sp = read_at<std::uintptr_t>( *array + i * k_render_bone_stride );
					if ( !sp || !*sp )
					{
						break;
					}

					auto name = safe_cstr( *sp );
					if ( name.empty( ) )
					{
						break;
					}

					names.emplace_back( std::move( name ) );
				}
			}

			return cache.emplace( mesh, std::move( names ) ).first->second;
		}

	} // namespace

	hitboxes::set hitboxes::query( std::uintptr_t game_scene_node, bool seh )
	{
		( void )seh; // every read here is guarded regardless

		set result{};

		if ( !game_scene_node )
		{
			return result;
		}

		// m_modelState is embedded in CSkeletonInstance -- add, never dereference.
		const auto model_state = game_scene_node + SCHEMA( "CSkeletonInstance", "m_modelState" );

		const auto handle = read_at<std::uintptr_t>( model_state + SCHEMA( "CModelState", "m_hModel" ) );
		if ( !handle || !*handle )
		{
			return result;
		}

		const auto perm_model = read_at<std::uintptr_t>( *handle );
		if ( !perm_model || !*perm_model )
		{
			return result;
		}

		const auto meshes = read_at<std::uintptr_t>( *perm_model + 0x78 );
		if ( !meshes || !*meshes )
		{
			return result;
		}

		const auto mesh = read_at<std::uintptr_t>( *meshes );
		if ( !mesh || !*mesh )
		{
			return result;
		}

		const auto hitbox_set = read_at<std::uintptr_t>( *mesh + k_mesh_hitbox_set );
		if ( !hitbox_set || !*hitbox_set )
		{
			return result;
		}

		const auto count = read_at<int>( *hitbox_set + k_set_count );
		const auto array = read_at<std::uintptr_t>( *hitbox_set + k_set_array );

		if ( !count || !array || !*array )
		{
			return result;
		}

		if ( *count <= 0 || *count > static_cast< int >( result.entries.size( ) ) )
		{
			return result;
		}

		const auto& bone_names = bone_names_for( *mesh );

		for ( auto i = 0; i < *count; ++i )
		{
			const auto base = *array + static_cast< std::size_t >( i ) * k_hitbox_stride;

			const auto radius = read_at<float>( base + k_radius );
			const auto group = read_at<int>( base + k_group );
			const auto mins = read_at<math::vector3>( base + k_mins );
			const auto maxs = read_at<math::vector3>( base + k_maxs );

			if ( !radius || !group || !mins || !maxs )
			{
				continue;
			}

			// Same plausibility gate the discovery probe used, so a future layout
			// change yields a short/empty set rather than nonsense aim points.
			if ( *radius < 0.0f || *radius > 100.0f || *group < 0 || *group > 10 )
			{
				continue;
			}

			auto& hb = result.entries[ result.count++ ];
			hb.index = i;
			hb.mins = *mins;
			hb.maxs = *maxs;
			hb.radius = *radius;
			hb.group = *group;
			hb.bone_hash = read_at<std::uint32_t>( base + k_bone_hash ).value_or( 0 );
			hb.shape_type = read_at<std::uint8_t>( base + k_shape ).value_or( 0 );
			hb.translation_only = read_at<std::uint8_t>( base + k_translation_only ).value_or( 0 ) != 0;

			// Bone index by case-insensitive name match against the render
			// skeleton. Stays -1 when the name is unreadable or absent, which
			// callers must treat as "no transform available" rather than bone 0.
			hb.bone = -1;

			if ( const auto namep = read_at<std::uintptr_t>( base + k_bone_name ) )
			{
				if ( const auto name = safe_cstr( *namep ); !name.empty( ) )
				{
					const auto it = std::find_if( bone_names.begin( ), bone_names.end( ),
						[ & ]( const std::string& candidate ) { return iequals( candidate, name ); } );

					if ( it != bone_names.end( ) )
					{
						hb.bone = static_cast< int >( std::distance( bone_names.begin( ), it ) );
					}
				}
			}
		}

		return result;
	}

	// Prefer entry::group -- it is read from the hitbox itself and is the game's
	// own answer. This table exists only for callers holding a bare index.
	//
	// velocity's version of this table is WRONG on this build: indices 0-6 agree,
	// but 7-18 have left and right swapped (it maps 7->7 where the live hitbox
	// reports group 6, and so on for every limb). The values below were read off
	// two live player models, which produced identical sequences.
	int hitboxes::hitgroup_from_hitbox( int hitbox )
	{
		switch ( hitbox )
		{
		case 0:  return 1; // head
		case 1:  return 8; // neck
		case 2:  return 3; // stomach
		case 3:  return 3;
		case 4:  return 2; // chest
		case 5:  return 2;
		case 6:  return 2;
		case 7:  return 6; // legs
		case 8:  return 7;
		case 9:  return 6;
		case 10: return 7;
		case 11: return 6;
		case 12: return 7;
		case 13: return 4; // arms
		case 14: return 5;
		case 15: return 4;
		case 16: return 4;
		case 17: return 5;
		case 18: return 5;
		default: return 0;
		}
	}

	const char* hitboxes::hitgroup_to_name( int hitgroup )
	{
		constexpr const char* k_names[]{ "body", "head", "chest", "stomach", "left arm", "right arm", "left leg", "right leg", "neck" };
		return hitgroup < 9 ? k_names[ hitgroup ] : "body";
	}

} // namespace systems
