#include "../systems.hpp"

#include <iostream>
#include <string>
#include <string_view>

namespace systems {

	void entities::on_add_entity( std::uintptr_t entity, std::uint32_t handle )
	{
		if ( !entity )
		{
			return;
		}

		const auto index = static_cast< std::int16_t >( handle & 0x7fff );
		if ( index < 0 || index > 0x3fff )
		{
			return;
		}

		const auto schema_name = this->get_schema_name( entity );
		if ( !schema_name || !schema_name[ 0 ] )
		{
			return;
		}

		const auto hashed = fnv1a::runtime_hash( schema_name );
		const auto entity_type = this->classify_entity( hashed );

		if ( entity_type == type::unknown )
		{
			return;
		}

		cached entry{};
		entry.ptr = entity;
		entry.index = index;
		entry.schema_hash = hashed;
		entry.type = entity_type;

		std::unique_lock lock( this->m_cache_mtx );

		for ( const auto& c : this->m_cached )
		{
			if ( c.index == index )
			{
				return;
			}
		}

		this->m_cached.emplace_back( entry );
	}

	void entities::on_remove_entity( std::uintptr_t entity, std::uint32_t handle )
	{
		if ( !entity )
		{
			return;
		}

		const auto index = static_cast< std::int16_t >( handle & 0x7fff );
		if ( index < 0 || index > 0x3fff )
		{
			return;
		}

		std::unique_lock lock( this->m_cache_mtx );

		for ( auto it = this->m_cached.begin( ); it != this->m_cached.end( ); ++it )
		{
			if ( it->index == index )
			{
				if ( it != this->m_cached.end( ) - 1 )
				{
					*it = this->m_cached.back( );
				}

				this->m_cached.pop_back( );
				return;
			}
		}
	}

	void entities::force_update( )
	{
		{
			std::unique_lock lock( this->m_cache_mtx );
			this->m_cached.clear( );
			this->m_cached.reserve( 128 );
		}

		// Drop the per-chunk pointer cache on every rebuild. It was only
		// invalidated when the entity-list pointer itself changed, but across a
		// level transition the list pointer can survive while the chunks behind
		// it are reallocated -- leaving dangling chunk pointers that get read.
		this->m_cached_list_entries.fill( 0 );
		this->m_cached_entity_list = 0;

		// One-time census. "candidates=0" has several possible causes and this
		// separates them: whether the entity list yields anything at all, whether
		// the schema-name walk works, and whether classification recognises what
		// it reads. The name offsets (entity+0x10 -> +0x8 -> +0x8 -> +0x8) are
		// velocity's and were never verified on this build.
		// Reports whenever the player count CHANGES, not just once. The first
		// census fired before the bots existed, so a single sample could not
		// distinguish "the walk never finds players" from "it had not spawned
		// them yet" -- and those need very different fixes.
		static auto last_players = -1;
		auto walked = 0;
		auto named = 0;
		auto controllers_seen = 0;
		std::string controller_names{};

		for ( auto i = 0; i < 2048; ++i )
		{
			const auto entity = this->get_by_index( i );
			if ( !entity )
			{
				continue;
			}

			++walked;

			if ( const auto name = this->get_schema_name( entity ) )
			{
				++named;

				// Count every controller-looking class the walk sees, whether or
				// not classify_entity accepts it. If the walk finds ten and the
				// cache keeps one, the bug is in classification, not traversal.
				if ( std::string_view( name ).find( "PlayerController" ) != std::string_view::npos )
				{
					++controllers_seen;

					if ( controllers_seen <= 3 )
					{
						controller_names += ( controller_names.empty( ) ? "" : ", " );
						controller_names += name;
					}
				}
			}

			this->on_add_entity( entity, static_cast< std::uint32_t >( i ) );
		}

		if ( walked > 0 )
		{
			std::shared_lock lock( this->m_cache_mtx );

			auto players = 0;
			for ( const auto& c : this->m_cached )
			{
				if ( c.type == type::player )
				{
					++players;
				}
			}

			if ( players != last_players )
			{
				last_players = players;

				std::cout << "[entities] walked=" << walked
					<< " named=" << named
					<< " cached=" << this->m_cached.size( )
					<< " players=" << players
					<< " controllersSeen=" << controllers_seen
					<< " [" << controller_names << "]" << std::endl;
			}
		}
	}

	bool entities::exists( std::uintptr_t entity_ptr ) const
	{
		std::shared_lock lock( this->m_cache_mtx );

		for ( const auto& c : this->m_cached )
		{
			if ( c.ptr == entity_ptr )
			{
				return true;
			}
		}

		return false;
	}

	// Every hop here is guarded, and the name is COPIED rather than returned as a
	// pointer into game memory.
	//
	// Upstream is driven by add_entity/remove_entity hooks, so it only ever sees
	// live entities. This port polls the entity list instead, which means it can
	// and does walk entities that are being torn down -- during a level
	// transition especially. Four raw dereferences plus an unbounded strlen over
	// freed memory is what crashed loading into a match.
	const char* entities::get_schema_name( std::uintptr_t entity ) const
	{
		// Returned to callers, so it must outlive this frame; per-thread because
		// the entity walk is not necessarily single-threaded.
		thread_local char buffer[ 128 ]{};

		if ( !entity )
		{
			return nullptr;
		}

		const auto identity = memory::safe_read<std::uintptr_t>( entity + 0x10 );
		if ( !identity || !*identity )
		{
			return nullptr;
		}

		const auto class_info = memory::safe_read<std::uintptr_t>( *identity + 0x8 );
		if ( !class_info || !*class_info )
		{
			return nullptr;
		}

		const auto name_container = memory::safe_read<std::uintptr_t>( *class_info + 0x8 );
		if ( !name_container || !*name_container )
		{
			return nullptr;
		}

		const auto name_ptr = memory::safe_read<std::uintptr_t>( *name_container + 0x8 );
		if ( !name_ptr || !*name_ptr )
		{
			return nullptr;
		}

		// Bounded, byte-guarded copy: the source may be freed mid-walk.
		std::size_t i{};
		for ( ; i < sizeof( buffer ) - 1; ++i )
		{
			const auto c = memory::safe_read<char>( *name_ptr + i );
			if ( !c || *c == '\0' )
			{
				break;
			}

			// Class names are ASCII identifiers; anything else means we are not
			// looking at a name any more.
			if ( *c < 0x20 || *c > 0x7e )
			{
				return nullptr;
			}

			buffer[ i ] = *c;
		}

		buffer[ i ] = '\0';
		return i ? buffer : nullptr;
	}

	std::uintptr_t entities::get_by_index( std::int32_t index )
	{
		if ( !addresses::globals::entity_list )
		{
			return 0;
		}

		const auto entity_list = memory::safe_read<std::uintptr_t>( addresses::globals::entity_list );
		if ( !entity_list || !*entity_list )
		{
			return 0;
		}

		if ( this->m_cached_entity_list != *entity_list )
		{
			this->m_cached_entity_list = *entity_list;
			this->m_cached_list_entries.fill( 0 );
		}

		const auto chunk_index = index >> 9;
		if ( chunk_index < 0 || chunk_index >= static_cast< int >( this->m_cached_list_entries.size( ) ) )
		{
			return 0;
		}

		if ( !this->m_cached_list_entries[ chunk_index ] )
		{
			const auto chunk = memory::safe_read<std::uintptr_t>(
				*entity_list + ( static_cast< std::uintptr_t >( chunk_index ) * 8 ) + 0x10 );

			this->m_cached_list_entries[ chunk_index ] = chunk ? *chunk : 0;
		}

		const auto list_entry = this->m_cached_list_entries[ chunk_index ];
		if ( !list_entry )
		{
			return 0;
		}

		const auto entity = memory::safe_read<std::uintptr_t>(
			list_entry + ( static_cast< std::uintptr_t >( index & 0x1ff ) * 112 ) );

		return entity ? *entity : 0;
	}

	std::uintptr_t entities::lookup( std::uint32_t handle ) const
	{
		if ( !handle || handle == 0xffffffff )
		{
			return 0;
		}

		if ( !addresses::globals::entity_list )
		{
			return 0;
		}

		// Guarded for the same reason as get_by_index: this runs every tick from
		// local::update, including while the entity list is being rebuilt.
		const auto entity_list = memory::safe_read<std::uintptr_t>( addresses::globals::entity_list );
		if ( !entity_list || !*entity_list )
		{
			return 0;
		}

		const auto list_entry = memory::safe_read<std::uintptr_t>(
			*entity_list + ( static_cast< std::uintptr_t >( ( handle & 0x7fff ) >> 9 ) * 8 ) + 0x10 );

		if ( !list_entry || !*list_entry || *list_entry == 0xffffffffffffffff )
		{
			return 0;
		}

		const auto entity = memory::safe_read<std::uintptr_t>(
			*list_entry + ( static_cast< std::uintptr_t >( handle & 0x1ff ) * 112 ) );

		if ( !entity || !*entity || *entity == 0xffffffffffffffff || *entity < 0x10000 )
		{
			return 0;
		}

		return *entity;
	}

	std::vector<entities::cached> entities::get_by_type( type type ) const
	{
		std::shared_lock lock( this->m_cache_mtx );

		std::vector<cached> result{};
		result.reserve( this->m_cached.size( ) );

		for ( const auto& c : this->m_cached )
		{
			if ( c.type == type )
			{
				result.emplace_back( c );
			}
		}

		return result;
	}

	bool entities::is_empty( ) const
	{
		std::shared_lock lock( this->m_cache_mtx );
		return this->m_cached.empty( );
	}

	entities::type entities::classify_entity( std::uint32_t schema_hash ) const
	{
		switch ( schema_hash )
		{
		case "CCSPlayerController"_hash:
			return type::player;

		case "C_AK47"_hash:
		case "C_WeaponM4A1"_hash:
		case "C_WeaponM4A1Silencer"_hash:
		case "C_WeaponAWP"_hash:
		case "C_WeaponAug"_hash:
		case "C_WeaponFamas"_hash:
		case "C_WeaponGalilAR"_hash:
		case "C_WeaponSG556"_hash:
		case "C_WeaponG3SG1"_hash:
		case "C_WeaponSCAR20"_hash:
		case "C_WeaponSSG08"_hash:
		case "C_WeaponMAC10"_hash:
		case "C_WeaponMP5SD"_hash:
		case "C_WeaponMP7"_hash:
		case "C_WeaponMP9"_hash:
		case "C_WeaponBizon"_hash:
		case "C_WeaponP90"_hash:
		case "C_WeaponUMP45"_hash:
		case "C_WeaponNOVA"_hash:
		case "C_WeaponSawedoff"_hash:
		case "C_WeaponXM1014"_hash:
		case "C_WeaponMag7"_hash:
		case "C_WeaponM249"_hash:
		case "C_WeaponNegev"_hash:
		case "C_DEagle"_hash:
		case "C_WeaponElite"_hash:
		case "C_WeaponFiveSeven"_hash:
		case "C_WeaponGlock"_hash:
		case "C_WeaponHKP2000"_hash:
		case "C_WeaponUSPSilencer"_hash:
		case "C_WeaponP250"_hash:
		case "C_WeaponCZ75a"_hash:
		case "C_WeaponTec9"_hash:
		case "C_WeaponRevolver"_hash:
		case "C_WeaponTaser"_hash:
		case "C_Knife"_hash:
		case "C_C4"_hash:
		case "C_Item_Healthshot"_hash:
		case "C_HEGrenade"_hash:
		case "C_Flashbang"_hash:
		case "C_SmokeGrenade"_hash:
		case "C_MolotovGrenade"_hash:
		case "C_IncendiaryGrenade"_hash:
		case "C_DecoyGrenade"_hash:
			return type::item;

		case "C_HEGrenadeProjectile"_hash:
		case "C_FlashbangProjectile"_hash:
		case "C_SmokeGrenadeProjectile"_hash:
		case "C_MolotovProjectile"_hash:
		case "C_Inferno"_hash:
		case "C_DecoyProjectile"_hash:
			return type::projectile;

		default:
			return type::unknown;
		}
	}

} // namespace systems