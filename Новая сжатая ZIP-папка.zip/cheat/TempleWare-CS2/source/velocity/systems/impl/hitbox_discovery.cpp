#include "../systems.hpp"
#include "hitbox_discovery.h"

#include <algorithm>
#include <cctype>
#include <format>
#include <iostream>
#include <unordered_set>

// Empirical discovery of the model -> CHitBoxSetList path.
//
// Layouts from animationsystem.dll's static schema descriptors:
//
//   CHitBox        size 0x70   m_name 0x00, m_sSurfaceProperty 0x08,
//                              m_sBoneName 0x10, m_vMinBounds 0x18,
//                              m_vMaxBounds 0x24, m_flShapeRadius 0x30,
//                              m_nBoneNameHash 0x34, m_nGroupId 0x38,
//                              m_nShapeType 0x3C, m_bTranslationOnly 0x3D,
//                              m_CRC 0x40, m_cRenderColor 0x44,
//                              m_nHitBoxIndex 0x48
//   CHitBoxSet     size 0x30   m_HitBoxes 0x10 (CUtlVector)
//   CHitBoxSetList size 0x18   m_HitBoxSets 0x00 (CUtlVector)
//   CUtlVector     size 0x18   elements 0x00, count 0x10   <- elements FIRST
//
//   CSkeletonInstance + 0x140 m_modelState
//   CModelState       + 0x0a0 m_hModel
//   CSkeletonInstance + 0x3fc m_nHitboxSet
//
// RUN 1 RESULT: the 0x70 stride is confirmed live. Six distinct struck-hitbox
// pointers across two player models were all exact multiples of 0x70 apart
// (deltas 0x230, 0x2a0, 0x460, 0x770 = 5, 6, 10, 17 strides). The array is
// contiguous and the CHitBox size is right.
//
// What did NOT hold was deriving the array base from m_nHitBoxIndex: a struck
// hitbox reporting index 16 gave `struck - 16*0x70`, which failed to read back
// as a hitbox. That field is evidently not the index within this array. So the
// base is now found the way the stride was proven -- by walking backward in
// 0x70 steps while entries still validate -- rather than by trusting a field
// whose meaning is unconfirmed.

namespace systems::hitbox_discovery {

	namespace {

		constexpr std::size_t k_hitbox_stride{ 0x70 };
		constexpr std::size_t k_hitbox_radius_off{ 0x30 };
		constexpr std::size_t k_hitbox_bonehash_off{ 0x34 };
		constexpr std::size_t k_hitbox_group_off{ 0x38 };
		constexpr std::size_t k_hitbox_shape_off{ 0x3C };
		constexpr std::size_t k_hitbox_index_off{ 0x48 };

		constexpr std::size_t k_set_hitboxes_off{ 0x10 };
		constexpr std::size_t k_utlvec_count_off{ 0x10 };

		// A player model has ~19-20 hitboxes; allow slack in both directions.
		constexpr int k_max_walk{ 32 };

		// CSkeletonInstance is 0x490 and PermModelData_t is 0x2f8, so these cover
		// both with slack. Run 2 found no reference in either, but it was
		// searching a bogus model pointer -- worth repeating now that the model
		// resolves properly.
		constexpr std::size_t k_skeleton_scan_bytes{ 0x800 };
		constexpr std::size_t k_model_scan_bytes{ 0x400 };
		constexpr std::size_t k_child_scan_bytes{ 0x400 };

		// std::cout, not Logger::Log: the latter routes to I::ConColorMsg -- the
		// game's own developer console -- while every other diagnostic in this
		// project prints to the allocated stdout console.
		void log( const std::string& s )
		{
			std::cout << s << std::endl;
		}

		struct hitbox_fields
		{
			float radius{};
			std::uint32_t bone_hash{};
			int group{};
			std::uint8_t shape{};
			int index{};
			bool readable{};
		};

		[[nodiscard]] hitbox_fields read_fields( std::uintptr_t hb )
		{
			hitbox_fields f{};

			const auto radius = memory::safe_read<float>( hb + k_hitbox_radius_off );
			const auto bone_hash = memory::safe_read<std::uint32_t>( hb + k_hitbox_bonehash_off );
			const auto group = memory::safe_read<int>( hb + k_hitbox_group_off );
			const auto shape = memory::safe_read<std::uint8_t>( hb + k_hitbox_shape_off );
			const auto index = memory::safe_read<int>( hb + k_hitbox_index_off );

			if ( !radius || !bone_hash || !group || !shape || !index )
			{
				return f;
			}

			f.radius = *radius;
			f.bone_hash = *bone_hash;
			f.group = *group;
			f.shape = *shape;
			f.index = *index;
			f.readable = true;
			return f;
		}

		// Deliberately loose. Run 1 rejected a base that the stride evidence says
		// was probably right, because the old test also demanded a plausible
		// m_nHitBoxIndex -- a field that turned out not to mean what was assumed.
		// This now tests only the two fields with independently confirmed
		// meanings: the radius (bounded world units) and the group (the same
		// small set player_hurt reports).
		[[nodiscard]] bool plausible( const hitbox_fields& f )
		{
			return f.readable
				&& f.radius >= 0.0f && f.radius <= 100.0f
				&& f.group >= 0 && f.group <= 10;
		}

		[[nodiscard]] std::string describe( std::uintptr_t hb, const hitbox_fields& f )
		{
			if ( !f.readable )
			{
				return std::format( "  {:#x}  <unreadable>", hb );
			}

			// The index field is packed: run 2 saw values like 0x61000002 and
			// 0x1000000D whose low 16 bits are the real index. Show both halves.
			return std::format( "  {:#x}  radius={:<8.3f} group={:<3} shape={:<3} bonehash={:#010x} idx16={:<3} raw={:#010x}",
				hb, f.radius, f.group, static_cast< int >( f.shape ), f.bone_hash,
				static_cast< std::uint16_t >( f.index ), static_cast< std::uint32_t >( f.index ) );
		}

		[[nodiscard]] bool is_owning_set( std::uintptr_t set, std::uintptr_t array_base, int& out_count )
		{
			const auto elems = memory::safe_read<std::uintptr_t>( set + k_set_hitboxes_off );
			const auto count = memory::safe_read<int>( set + k_set_hitboxes_off + k_utlvec_count_off );

			if ( !elems || !count || *elems != array_base )
			{
				return false;
			}

			if ( *count <= 0 || *count > 64 )
			{
				return false;
			}

			out_count = *count;
			return true;
		}

		void find_refs( std::uintptr_t base, std::size_t bytes, std::uintptr_t target,
			std::vector<std::size_t>& out )
		{
			for ( std::size_t off = 0; off + sizeof( std::uintptr_t ) <= bytes; off += sizeof( std::uintptr_t ) )
			{
				const auto v = memory::safe_read<std::uintptr_t>( base + off );
				if ( v && *v == target )
				{
					out.push_back( off );
				}
			}
		}

		// Reads a C string one guarded byte at a time. memory::read_string walks
		// raw memory, which is not safe on a pointer we are still validating.
		[[nodiscard]] std::string safe_cstr( std::uintptr_t address, std::size_t max_len = 64 )
		{
			if ( !address )
			{
				return {};
			}

			std::string out{};
			out.reserve( max_len );

			for ( std::size_t i = 0; i < max_len; ++i )
			{
				const auto c = memory::safe_read<char>( address + i );
				if ( !c || *c == '\0' )
				{
					break;
				}

				if ( *c < 0x20 || *c > 0x7e )
				{
					return {}; // not text -- treat as unreadable
				}

				out.push_back( *c );
			}

			return out;
		}

		// Bone names differ in case between the two sources: CHitBox spells it
		// "leg_upper_l", the render skeleton "leg_upper_L". An exact compare
		// silently resolves nothing.
		[[nodiscard]] bool iequals( const std::string& a, const std::string& b )
		{
			if ( a.size( ) != b.size( ) || a.empty( ) )
			{
				return false;
			}

			return std::equal( a.begin( ), a.end( ), b.begin( ),
				[]( char x, char y )
				{
					return std::tolower( static_cast< unsigned char >( x ) )
						== std::tolower( static_cast< unsigned char >( y ) );
				} );
		}

		// Heap object, not a module address and not a small integer that happens
		// to sit in a pointer slot.
		[[nodiscard]] bool plausible_heap_ptr( std::uintptr_t v )
		{
			return v > 0x10000ull
				&& v < 0x7ff000000000ull
				&& ( v & 0x7 ) == 0;
		}

		// Bounded BFS for whoever points at `target`, reporting the full path.
		//
		// The earlier investigation's BFS searched for a CHitBox array by
		// *content* and found nothing. This one has the exact address to match,
		// which makes a hit unambiguous -- and the expected chain is
		//   model -> CHitBoxSetList -> m_HitBoxSets[0] -> +0x10 -> array
		// i.e. 3-4 hops, deeper than the two levels searched so far.
		void bfs_for( std::uintptr_t root, const char* root_name, std::uintptr_t target,
			int max_depth, std::size_t obj_bytes, std::size_t max_objects )
		{
			struct node
			{
				std::uintptr_t addr;
				int depth;
				std::string path;
			};

			std::unordered_set<std::uintptr_t> visited{};
			std::vector<node> queue{ { root, 0, std::string( root_name ) } };
			visited.insert( root );

			std::size_t examined{};
			auto found{ false };

			for ( std::size_t head = 0; head < queue.size( ) && examined < max_objects; ++head )
			{
				const auto cur = queue[ head ];
				++examined;

				for ( std::size_t off = 0; off + 8 <= obj_bytes; off += 8 )
				{
					const auto v = memory::safe_read<std::uintptr_t>( cur.addr + off );
					if ( !v || !*v )
					{
						continue;
					}

					if ( *v == target )
					{
						log( std::format( "[hitbox-re] *** PATH: {}+{:#x}  (depth {})",
							cur.path, off, cur.depth ) );

						// The slot holding the array is m_HitBoxes.elements, so
						// the owning CHitBoxSet starts 0x10 earlier.
						int c{};
						if ( is_owning_set( cur.addr + off - k_set_hitboxes_off, target, c ) )
						{
							log( std::format( "[hitbox-re] *** CHitBoxSet at {}+{:#x}, count={}",
								cur.path, off - k_set_hitboxes_off, c ) );
						}

						found = true;
						continue;
					}

					if ( cur.depth < max_depth && plausible_heap_ptr( *v )
						&& visited.size( ) < max_objects && visited.insert( *v ).second )
					{
						queue.push_back( { *v, cur.depth + 1,
							std::format( "{}+{:#x}->", cur.path, off ) } );
					}
				}
			}

			log( std::format( "[hitbox-re] bfs({}) examined {} objects, {} distinct, {}",
				root_name, examined, visited.size( ), found ? "FOUND" : "no hit" ) );
		}

	} // namespace

	void report( std::uintptr_t struck_hitbox, std::uintptr_t game_scene_node )
	{
		// Dedupe on the STRUCK pointer, before any validation. Run 1 deduped on
		// the derived array base instead, which is computed after the rejection
		// path -- so the shared world-hitbox constant (hit every frame the
		// crosshair is on geometry) logged forever and buried the real result.
		static std::unordered_set<std::uintptr_t> seen_struck{};
		static std::unordered_set<std::uintptr_t> seen_base{};

		// Checked before anything else: this runs from the trace path, so the
		// disabled case must cost one branch.
		if ( !g_enabled || !struck_hitbox || !game_scene_node )
		{
			return;
		}

		if ( !seen_struck.insert( struck_hitbox ).second )
		{
			return;
		}

		const auto struck_fields = read_fields( struck_hitbox );

		if ( !plausible( struck_fields ) )
		{
			log( std::format( "[hitbox-re] reject {:#x} (world/non-hitbox)", struck_hitbox ) );
			log( describe( struck_hitbox, struck_fields ) );
			return;
		}

		log( "[hitbox-re] ---- struck hitbox ----" );
		log( describe( struck_hitbox, struck_fields ) );

		// Walk backward in confirmed 0x70 steps to the first entry that stops
		// validating; the one after it is the array base.
		auto base = struck_hitbox;
		auto steps_back = 0;

		for ( auto i = 1; i <= k_max_walk; ++i )
		{
			const auto candidate = struck_hitbox - static_cast< std::size_t >( i ) * k_hitbox_stride;
			if ( !plausible( read_fields( candidate ) ) )
			{
				break;
			}

			base = candidate;
			steps_back = i;
		}

		log( std::format( "[hitbox-re] walked back {} entries -> array_base={:#x}", steps_back, base ) );

		if ( !seen_base.insert( base ).second )
		{
			return;
		}

		// Walk forward from the base and dump the whole run. If this is the real
		// array the entries should read as a coherent hitbox set, and the
		// idx@0x48 column shows what m_nHitBoxIndex actually counts.
		auto count = 0;
		log( "[hitbox-re] ---- entries from base ----" );

		for ( auto i = 0; i < k_max_walk; ++i )
		{
			const auto entry = base + static_cast< std::size_t >( i ) * k_hitbox_stride;
			const auto f = read_fields( entry );

			if ( !plausible( f ) )
			{
				break;
			}

			log( std::format( "  [{:2}]{}", i, describe( entry, f ).substr( 2 ) ) );
			++count;
		}

		log( std::format( "[hitbox-re] contiguous run = {} entries", count ) );

		// The world hitbox sits in a short run of zeroed entries that passes the
		// loose two-field test. A real player set is 19; anything under 8 is not
		// worth searching for.
		if ( count < 8 )
		{
			log( "[hitbox-re] run too short to be a player hitbox set -- skipping search" );
			return;
		}

		// m_modelState is EMBEDDED in CSkeletonInstance, not a pointer to it:
		// CSkeletonInstance is 0x490 with m_modelState at 0x140, CModelState is
		// 0x2b0, and 0x140+0x2b0 = 0x3f0 -- exactly the next field's offset.
		// Run 2 dereferenced it and got the embedded struct's vtable (a constant
		// client.dll address, identical for every entity), then indexed 0xa0 into
		// client.dll. velocity's bones.cpp has the correct form: it adds.
		const auto model_state = game_scene_node + SCHEMA( "CSkeletonInstance", "m_modelState" );
		const auto model = memory::safe_read<std::uintptr_t>(
			model_state + SCHEMA( "CModelState", "m_hModel" ) );
		const auto active_set = memory::safe_read<int>(
			game_scene_node + SCHEMA( "CSkeletonInstance", "m_nHitboxSet" ) );

		log( std::format( "[hitbox-re] scene_node={:#x} model_state={:#x} model={:#x} m_nHitboxSet={}",
			game_scene_node,
			model_state,
			model ? *model : 0,
			active_set ? *active_set : -1 ) );

		// A heap model pointer, not a module address -- catches the class of
		// mistake above immediately instead of letting the search run on garbage.
		if ( model && *model && *model > 0x7ff000000000ull )
		{
			log( "[hitbox-re] WARNING: model resolves inside a module, not the heap -- offsets are wrong" );
		}

		if ( !model || !*model )
		{
			log( "[hitbox-re] no model -- cannot locate the set list" );
			return;
		}

		// m_hModel is a CStrongHandle, so the real PermModelData_t is one deref
		// further -- velocity does exactly this (`cmodel = read(model_handle)`).
		const auto real_model = memory::safe_read<std::uintptr_t>( *model );

		log( std::format( "[hitbox-re] handle={:#x} deref={:#x}",
			*model, real_model ? *real_model : 0 ) );

		if ( !real_model || !plausible_heap_ptr( *real_model ) )
		{
			log( "[hitbox-re] model handle does not deref to a heap object" );
			return;
		}

		// ---- bone mapping ----
		//
		// CHitBox carries m_sBoneName at +0x10, and ModelSkeletonData_t carries
		// m_boneName -- both strings. So the hitbox->bone index falls out of a
		// name match, with no hash function to guess and no remap table to
		// revive. (m_nBoneNameHash at +0x34 would also work, but only if the
		// exact hash variant were known; the string is unambiguous.)
		//
		// First: are the hitbox bone-name strings readable at all? The whole
		// name-matching approach depends on it, so establish that before hunting
		// for the skeleton.
		log( "[hitbox-re] ---- hitbox bone names ----" );

		auto readable_names = 0;
		for ( auto i = 0; i < count; ++i )
		{
			const auto hb = base + static_cast< std::size_t >( i ) * k_hitbox_stride;
			const auto namep = memory::safe_read<std::uintptr_t>( hb + 0x10 );
			const auto nm = namep ? safe_cstr( *namep ) : std::string{};

			if ( !nm.empty( ) )
			{
				++readable_names;
			}

			log( std::format( "  hitbox[{:2}] group={:<2} name={}",
				i, read_fields( hb ).group, nm.empty( ) ? "<unreadable>" : nm ) );
		}

		log( std::format( "[hitbox-re] {}/{} hitbox bone names readable", readable_names, count ) );

		// Bone names come from the RENDER skeleton on the mesh, not from
		// PermModelData_t::m_modelSkeleton (0x188), which read back as bbox floats
		// live despite the schema declaring it there.
		//
		//   CRenderMesh     + 0xE0 = m_skeleton (CRenderSkeleton)
		//   CRenderSkeleton + 0x00 = m_bones (CUtlVector<RenderSkeletonBone_t>)
		//   RenderSkeletonBone_t   = 0x60, m_boneName (CUtlString) at 0x00
		//
		// The hitbox set corroborates this: mesh+0x168 = CRenderSkeleton+0x88,
		// past that class's declared fields (which stop at 0x48).
		const auto meshes_v = memory::safe_read<std::uintptr_t>( *real_model + 0x78 );
		const auto mesh_p = meshes_v ? memory::safe_read<std::uintptr_t>( *meshes_v ) : std::nullopt;

		if ( !mesh_p || !plausible_heap_ptr( *mesh_p ) )
		{
			log( "[hitbox-re] no mesh -- cannot read render skeleton" );
			return;
		}

		// mesh+0xE0 is not an elements-first CUtlVector: its low dword equals the
		// count read at mesh+0xF0 (48 and 65 on two models), and the high dword
		// reads as a float. Either m_bones is count-first (CUtlLeanVector, which
		// CRenderMesh uses for its other fields) or m_skeleton is not at 0xE0
		// live. Third declared offset in this object to disagree with reality.
		//
		// So stop guessing and search for the names, which we now have exactly.
		// Pick two hitbox bone names and look for an array of structs whose first
		// field is a char* to each. Finding both, in order, yields the array base
		// AND the stride, and two independent names make a coincidence implausible.
		const auto name_of = [ & ]( int idx ) -> std::string
			{
				const auto hb = base + static_cast< std::size_t >( idx ) * k_hitbox_stride;
				const auto p = memory::safe_read<std::uintptr_t>( hb + 0x10 );
				return p ? safe_cstr( *p ) : std::string{};
			};

		const auto want_a = name_of( 2 ); // pelvis
		const auto want_b = name_of( 3 ); // spine_0

		log( std::format( "[hitbox-re] searching mesh {:#x} for bone array via \"{}\" / \"{}\"",
			*mesh_p, want_a, want_b ) );

		if ( want_a.empty( ) || want_b.empty( ) )
		{
			log( "[hitbox-re] hitbox bone names unreadable -- cannot search" );
			return;
		}

		// Where does `want` appear as a char* inside object `obj`?
		const auto find_name_slot = [ & ]( std::uintptr_t obj, const std::string& want,
			std::size_t bytes ) -> std::optional<std::size_t>
			{
				for ( std::size_t k = 0; k + 8 <= bytes; k += 8 )
				{
					const auto sp = memory::safe_read<std::uintptr_t>( obj + k );
					if ( sp && plausible_heap_ptr( *sp ) && safe_cstr( *sp ) == want )
					{
						return k;
					}
				}

				return std::nullopt;
			};

		auto found_any = false;

		// The bone array is reachable either directly from the mesh or one
		// pointer away, so try the mesh itself first, then each pointer in it.
		std::vector<std::pair<std::uintptr_t, std::string>> roots{ { *mesh_p, "mesh" } };

		for ( std::size_t off = 0; off + 8 <= 0x400; off += 8 )
		{
			const auto p = memory::safe_read<std::uintptr_t>( *mesh_p + off );
			if ( p && plausible_heap_ptr( *p ) )
			{
				roots.emplace_back( *p, std::format( "mesh+{:#x}->", off ) );
			}
		}

		for ( const auto& [ obj, label ] : roots )
		{
			const auto a = find_name_slot( obj, want_a, 0x1000 );
			if ( !a )
			{
				continue;
			}

			const auto b = find_name_slot( obj + *a + 8, want_b, 0x400 );

			log( std::format( "[hitbox-re] *** \"{}\" at {}+{:#x}{}",
				want_a, label, *a,
				b ? std::format( ", \"{}\" +{:#x} later -> stride {:#x}", want_b, *b + 8, *b + 8 )
				: std::string{ " (second name not found nearby)" } ) );

			found_any = true;

			if ( !b )
			{
				continue;
			}

			const auto stride = *b + 8;

			// Is `want_a` really element 0? If the array starts earlier, every
			// bone index is off by one and the aimbot would transform hitboxes
			// onto the wrong bone -- a subtle error worth eliminating now. Walk
			// backward in stride steps while entries still read as names, exactly
			// as the hitbox array base was established.
			auto arr = obj + *a;
			auto walked = 0;

			for ( auto k = 1; k <= 8; ++k )
			{
				const auto cand = obj + *a - static_cast< std::size_t >( k ) * stride;
				if ( cand < obj )
				{
					break;
				}

				const auto sp = memory::safe_read<std::uintptr_t>( cand );
				if ( !sp || !plausible_heap_ptr( *sp ) || safe_cstr( *sp ).empty( ) )
				{
					break;
				}

				arr = cand;
				walked = k;
			}

			log( std::format( "[hitbox-re] walked back {} entries -> bone array base {}+{:#x} (\"{}\" is index {})",
				walked, label, arr - obj, want_a, walked ) );

			log( "[hitbox-re] ---- bones from that array ----" );
			for ( auto i = 0; i < 24; ++i )
			{
				const auto sp = memory::safe_read<std::uintptr_t>(
					arr + static_cast< std::size_t >( i ) * stride );
				const auto nm = sp ? safe_cstr( *sp ) : std::string{};
				log( std::format( "  [{:2}] {}", i, nm.empty( ) ? "<null>" : nm ) );
			}

			// Resolve every hitbox against this array, case-insensitively:
			// hitboxes spell it "leg_upper_l", the skeleton "leg_upper_L".
			log( "[hitbox-re] ---- hitbox -> bone ----" );

			auto resolved = 0;
			for ( auto i = 0; i < count; ++i )
			{
				const auto nm = name_of( i );
				auto bone = -1;

				for ( auto j = 0; j < 256; ++j )
				{
					const auto sp = memory::safe_read<std::uintptr_t>(
						arr + static_cast< std::size_t >( j ) * stride );
					if ( !sp || !plausible_heap_ptr( *sp ) )
					{
						break;
					}

					if ( iequals( safe_cstr( *sp ), nm ) )
					{
						bone = j;
						break;
					}
				}

				if ( bone >= 0 )
				{
					++resolved;
				}

				log( std::format( "  hitbox[{:2}] {:<22} -> bone={}", i, nm, bone ) );
			}

			log( std::format( "[hitbox-re] {}/{} hitboxes resolved to a bone", resolved, count ) );
		}

		if ( !found_any )
		{
			log( "[hitbox-re] bone name array not found in mesh or one hop from it" );
		}

		// The model->array path is resolved and baked into hitboxes::query, so the
		// BFS no longer runs. Corroborate the known chain instead -- if this stops
		// matching after a game update, that is the signal to re-run bfs_for.
		const auto meshes = memory::safe_read<std::uintptr_t>( *real_model + 0x78 );
		const auto mesh = meshes ? memory::safe_read<std::uintptr_t>( *meshes ) : std::nullopt;
		const auto set = mesh ? memory::safe_read<std::uintptr_t>( *mesh + 0x168 ) : std::nullopt;
		const auto set_array = set ? memory::safe_read<std::uintptr_t>( *set + 0x30 ) : std::nullopt;
		const auto set_count = set ? memory::safe_read<int>( *set + 0x28 ) : std::nullopt;

		log( std::format( "[hitbox-re] chain check: set={:#x} count={} array={:#x} expected={:#x} -> {}",
			set ? *set : 0,
			set_count ? *set_count : -1,
			set_array ? *set_array : 0,
			base,
			( set_array && *set_array == base ) ? "MATCH" : "MISMATCH" ) );
	}

} // namespace systems::hitbox_discovery
