#include "../systems.hpp"

#include <iostream>

namespace systems {

	namespace detail {

		class state_guard
		{
		public:
			state_guard( ) = default;
			~state_guard( ) { restore( ); }

			state_guard( const state_guard& ) = delete;
			state_guard& operator=( const state_guard& ) = delete;

			// Both save paths skip a null address rather than reading through it.
			// Several of the globals these guard are resolved by pattern, and an
			// unresolved -- or ambiguous, which now also yields 0 -- one would
			// otherwise fault here on the read, and again in restore() on the
			// memcpy back. Skipping keeps the entry out of the list entirely, so
			// restore stays symmetric.
			template <typename T>
			void save( std::uintptr_t address )
			{
				if ( !address )
				{
					return;
				}

				auto value = memory::read<T>( address );
				this->m_entries.emplace_back( entry{ address, sizeof( T ), {} } );
				std::memcpy( this->m_entries.back( ).data.data( ), &value, sizeof( T ) );
			}

			void save_raw( std::uintptr_t address, std::size_t size )
			{
				if ( !address )
				{
					return;
				}

				this->m_entries.emplace_back( entry{ address, size, {} } );
				std::memcpy( this->m_entries.back( ).data.data( ), reinterpret_cast< void* >( address ), size );
			}

			void restore( )
			{
				for ( auto it = this->m_entries.rbegin( ); it != this->m_entries.rend( ); ++it )
				{
					std::memcpy( reinterpret_cast< void* >( it->address ), it->data.data( ), it->size );
				}

				this->m_entries.clear( );
			}

		private:
			struct entry
			{
				std::uintptr_t address{};
				std::size_t size{};
				std::array<std::uint8_t, 64> data{};
			};

			std::vector<entry> m_entries;
		};

	} // namespace detail

	void prediction::capture_prestate( std::uintptr_t local_pawn, std::uintptr_t movement_services )
	{
		this->m_prestate.flags = memory::read<std::uint32_t>( local_pawn + SCHEMA( "C_BaseEntity", "m_fFlags" ) );
		this->m_prestate.networked_velocity = memory::read<math::vector3>( local_pawn + SCHEMA( "C_BaseEntity", "m_vecVelocity" ) );
		this->m_prestate.velocity = memory::read<math::vector3>( local_pawn + SCHEMA( "C_BaseEntity", "m_vecAbsVelocity" ) );
		this->m_prestate.stamina = memory::read<float>( movement_services + SCHEMA( "CCSPlayer_MovementServices", "m_flStamina" ) );
		this->m_prestate.surface_friction = memory::read<float>( movement_services + SCHEMA( "CPlayer_MovementServices_Humanoid", "m_flSurfaceFriction" ) );

		this->m_prestate.last_movement_impulses.x = memory::read<float>( movement_services + SCHEMA( "CPlayer_MovementServices", "m_flCmdForwardMove" ) );
		this->m_prestate.last_movement_impulses.y = memory::read<float>( movement_services + SCHEMA( "CPlayer_MovementServices", "m_flCmdLeftMove" ) );
		this->m_prestate.last_movement_impulses.z = memory::read<float>( movement_services + SCHEMA( "CPlayer_MovementServices", "m_flCmdUpMove" ) );

		const auto game_scene_node = memory::read<std::uintptr_t>( local_pawn + SCHEMA( "C_BaseEntity", "m_pGameSceneNode" ) );
		if ( game_scene_node )
		{
			this->m_prestate.origin = memory::read<math::vector3>( game_scene_node + SCHEMA( "CGameSceneNode", "m_vecAbsOrigin" ) );
			this->m_prestate.networked_origin = memory::read<math::vector3>( game_scene_node + SCHEMA( "CGameSceneNode", "m_vecOrigin" ) );
		}
	}

	void prediction::simulate( input::usercmd* cmd, const systems::local::snapshot& local, const std::function<void( )>& fn )
	{
		// ALL-OR-NOTHING.
		//
		// This routine drives the game's own prediction system: it swaps globals,
		// pushes the engine into a prediction state, runs movement, then restores.
		// call_guarded stops an unresolved signature from faulting at the CALL,
		// but it does not stop the rest of the sequence from running -- and
		// running movement simulation after the state-setup calls were skipped
		// executes against an inconsistent engine state. That crashed the game:
		// prediction_set_state and prediction_set_pawn were skipped, execution
		// continued, and it died before returning.
		//
		// Skipping a required step is not a degraded mode, it is a broken one. So
		// if any piece is missing, do nothing at all.
		//
		// Consequence: stop-prediction / autostop is unavailable while these are
		// unresolved. The ragebot still scans, picks targets and aims.
		{
			static auto reported = false;

			const auto required_ok =
				PATTERN( patterns::prediction_set_state ) &&
				PATTERN( patterns::prediction_set_pawn ) &&
				PATTERN( patterns::prediction_setup_move ) &&
				PATTERN( patterns::prediction_process_movement ) &&
				PATTERN( patterns::prediction_finish_move ) &&
				PATTERN( patterns::prediction_reset_pawn ) &&
				addresses::globals::prediction_player &&
				addresses::globals::prediction_state &&
				addresses::globals::simulation_player;

			if ( !required_ok )
			{
				if ( !reported )
				{
					reported = true;
					std::cout << "[combat] prediction::simulate DISABLED -- required signatures/globals "
						"unresolved. Stop-prediction is off; aiming is unaffected." << std::endl;
				}

				return;
			}
		}

		const auto get_active_weapon = [ ]( std::uintptr_t pawn ) -> std::pair<std::uintptr_t, std::uintptr_t>
			{
				const auto weapon_services = memory::read<std::uintptr_t>( pawn + SCHEMA( "C_BasePlayerPawn", "m_pWeaponServices" ) );
				if ( !weapon_services )
				{
					return {};
				}

				const auto weapon_handle = memory::read<std::uint32_t>( weapon_services + SCHEMA( "CPlayer_WeaponServices", "m_hActiveWeapon" ) );
				if ( !weapon_handle )
				{
					return { weapon_services, 0 };
				}

				return { weapon_services, systems::g_entities.lookup( weapon_handle ) };
			};

		const auto game_scene_node = memory::read<std::uintptr_t>( local.pawn + SCHEMA( "C_BaseEntity", "m_pGameSceneNode" ) );
		const auto movement_services = memory::read<std::uintptr_t>( local.pawn + SCHEMA( "C_BasePlayerPawn", "m_pMovementServices" ) );
		const auto aim_punch_services = memory::read<std::uintptr_t>( local.pawn + SCHEMA( "C_CSPlayerPawn", "m_pAimPunchServices" ) );
		const auto [weapon_services, weapon] = get_active_weapon( local.pawn );

		if ( !game_scene_node || !movement_services || !aim_punch_services || !weapon )
		{
			return;
		}

		const auto global_vars = memory::read<std::uintptr_t>( addresses::globals::global_vars );
		const auto cmd_ptr = reinterpret_cast< std::uintptr_t >( cmd );
		const auto old_slot = memory::read<std::uintptr_t>( addresses::globals::source2client_prediction + 56 );
		const auto pred_state = memory::read<std::uintptr_t>( addresses::globals::prediction_state );

		detail::state_guard guard;

		guard.save<float>( global_vars + 48 );
		guard.save<float>( global_vars + 52 );
		guard.save<int>( global_vars + 68 );
		guard.save<float>( global_vars + 80 );
		guard.save<std::uint32_t>( global_vars + 88 );

		guard.save<std::uint32_t>( addresses::globals::prediction_seed );
		guard.save<std::uintptr_t>( addresses::globals::simulation_player );
		guard.save<std::uintptr_t>( addresses::globals::prediction_player );

		if ( old_slot )
		{
			guard.save<std::uint8_t>( old_slot + 140 );
		}

		guard.save<int>( local.controller + SCHEMA( "CBasePlayerController", "m_nTickBase" ) );

		guard.save<std::uint32_t>( local.pawn + SCHEMA( "C_BaseEntity", "m_fFlags" ) );
		guard.save<math::vector3>( local.pawn + SCHEMA( "C_BaseEntity", "m_vecAbsVelocity" ) );
		guard.save<math::vector3>( local.pawn + SCHEMA( "C_BaseEntity", "m_vecVelocity" ) );
		guard.save<math::vector3>( local.pawn + SCHEMA( "C_BaseEntity", "m_vecBaseVelocity" ) );
		guard.save<float>( local.pawn + SCHEMA( "C_BaseEntity", "m_flFriction" ) );
		guard.save<float>( local.pawn + SCHEMA( "C_BaseEntity", "m_flGravityScale" ) );
		guard.save<std::uint32_t>( local.pawn + SCHEMA( "C_BaseEntity", "m_hGroundEntity" ) );
		guard.save<float>( local.pawn + SCHEMA( "C_BaseEntity", "m_flSimulationTime" ) );
		guard.save<int>( local.pawn + SCHEMA( "C_BaseEntity", "m_nSimulationTick" ) );
		guard.save<float>( local.pawn + SCHEMA( "C_BaseEntity", "m_flWaterLevel" ) );

		guard.save<math::vector3>( game_scene_node + SCHEMA( "CGameSceneNode", "m_vecAbsOrigin" ) );
		guard.save<math::vector3>( game_scene_node + SCHEMA( "CGameSceneNode", "m_vecOrigin" ) );

		guard.save<float>( local.pawn + SCHEMA( "C_CSPlayerPawn", "m_flVelocityModifier" ) );
		guard.save<int>( local.pawn + SCHEMA( "C_CSPlayerPawn", "m_iShotsFired" ) );
		guard.save<bool>( local.pawn + SCHEMA( "C_CSPlayerPawn", "m_bIsWalking" ) );
		guard.save<math::vector3>( local.pawn + SCHEMA( "C_CSPlayerPawn", "m_angEyeAngles" ) );
		guard.save<float>( local.pawn + SCHEMA( "C_CSPlayerPawn", "m_flLastFiredWeaponTime" ) );
		guard.save<float>( local.pawn + SCHEMA( "C_CSPlayerPawn", "m_ignoreLadderJumpTime" ) );
		guard.save<float>( local.pawn + SCHEMA( "C_CSPlayerPawn", "m_grenadeParameterStashTime" ) );
		guard.save<bool>( local.pawn + SCHEMA( "C_CSPlayerPawn", "m_bGrenadeParametersStashed" ) );
		guard.save<math::vector3>( local.pawn + SCHEMA( "C_CSPlayerPawn", "m_angStashedShootAngles" ) );
		guard.save<math::vector3>( local.pawn + SCHEMA( "C_CSPlayerPawn", "m_vecStashedGrenadeThrowPosition" ) );
		guard.save<math::vector3>( local.pawn + SCHEMA( "C_CSPlayerPawn", "m_vecStashedVelocity" ) );
		guard.save_raw( local.pawn + SCHEMA( "C_CSPlayerPawn", "m_angShootAngleHistory" ), sizeof( math::vector3 ) * 2 );
		guard.save_raw( local.pawn + SCHEMA( "C_CSPlayerPawn", "m_vecThrowPositionHistory" ), sizeof( math::vector3 ) * 2 );
		guard.save_raw( local.pawn + SCHEMA( "C_CSPlayerPawn", "m_vecVelocityHistory" ), sizeof( math::vector3 ) * 2 );

		guard.save<math::vector3>( local.pawn + SCHEMA( "C_BaseModelEntity", "m_vecViewOffset" ) );

		guard.save<int>( aim_punch_services + SCHEMA( "CCSPlayer_AimPunchServices", "m_predictableBaseTick" ) );
		guard.save<float>( aim_punch_services + SCHEMA( "CCSPlayer_AimPunchServices", "m_predictableBaseTickInterpAmount" ) );
		guard.save<math::vector3>( aim_punch_services + SCHEMA( "CCSPlayer_AimPunchServices", "m_predictableBaseAngle" ) );
		guard.save<math::vector3>( aim_punch_services + SCHEMA( "CCSPlayer_AimPunchServices", "m_predictableBaseAngleVel" ) );
		guard.save<int>( aim_punch_services + SCHEMA( "CCSPlayer_AimPunchServices", "m_unpredictableBaseTick" ) );
		guard.save<math::vector3>( aim_punch_services + SCHEMA( "CCSPlayer_AimPunchServices", "m_unpredictableBaseAngle" ) );

		guard.save<float>( weapon_services + SCHEMA( "CCSPlayer_WeaponServices", "m_flNextAttack" ) );
		guard.save<std::uint32_t>( weapon_services + SCHEMA( "CCSPlayer_WeaponServices", "m_nOldTotalShootPositionHistoryCount" ) );
		guard.save<std::uint32_t>( weapon_services + SCHEMA( "CCSPlayer_WeaponServices", "m_nOldTotalInputHistoryCount" ) );

		guard.save<float>( weapon + SCHEMA( "C_CSWeaponBase", "m_flNextClientFireBulletTime" ) );
		guard.save<float>( weapon + SCHEMA( "C_CSWeaponBase", "m_flNextClientFireBulletTime_Repredict" ) );
		guard.save_raw( weapon + SCHEMA( "C_CSWeaponBase", "m_weaponMode" ), SCHEMA( "C_CSWeaponBase", "m_flRecoilIndex" ) + sizeof( float ) - SCHEMA( "C_CSWeaponBase", "m_weaponMode" ) );
		guard.save_raw( weapon + SCHEMA( "C_CSWeaponBase", "m_nPostponeFireReadyTicks" ), SCHEMA( "C_CSWeaponBase", "m_bIsHauledBack" ) + sizeof( bool ) - SCHEMA( "C_CSWeaponBase", "m_nPostponeFireReadyTicks" ) );
		guard.save<float>( weapon + SCHEMA( "C_CSWeaponBase", "m_fLastShotTime" ) );
		guard.save<float>( weapon + SCHEMA( "C_CSWeaponBase", "m_flNextAttackRenderTimeOffset" ) );
		guard.save<float>( weapon + SCHEMA( "C_CSWeaponBase", "m_flWatTickOffset" ) );
		guard.save<int>( weapon + SCHEMA( "C_BasePlayerWeapon", "m_nNextPrimaryAttackTick" ) );
		guard.save<float>( weapon + SCHEMA( "C_BasePlayerWeapon", "m_flNextPrimaryAttackTickRatio" ) );

		guard.save<int>( weapon + SCHEMA( "C_BasePlayerWeapon", "m_nNextSecondaryAttackTick" ) );
		guard.save<float>( weapon + SCHEMA( "C_BasePlayerWeapon", "m_flNextSecondaryAttackTickRatio" ) );
		guard.save<int>( weapon + SCHEMA( "C_BasePlayerWeapon", "m_iClip1" ) );
		guard.save<int>( weapon + SCHEMA( "C_BasePlayerWeapon", "m_iClip2" ) );
		guard.save_raw( weapon + SCHEMA( "C_BasePlayerWeapon", "m_pReserveAmmo" ), sizeof( int ) * 2 );
		guard.save<int>( weapon + SCHEMA( "C_CSWeaponBaseGun", "m_zoomLevel" ) );
		guard.save<int>( weapon + SCHEMA( "C_CSWeaponBaseGun", "m_iBurstShotsRemaining" ) );

		guard.save<float>( movement_services + SCHEMA( "CCSPlayer_MovementServices", "m_flStamina" ) );
		guard.save<bool>( movement_services + SCHEMA( "CCSPlayer_MovementServices", "m_bDucked" ) );
		guard.save<bool>( movement_services + SCHEMA( "CCSPlayer_MovementServices", "m_bDucking" ) );
		guard.save<bool>( movement_services + SCHEMA( "CCSPlayer_MovementServices", "m_bDesiresDuck" ) );
		guard.save<bool>( movement_services + SCHEMA( "CCSPlayer_MovementServices", "m_bDuckOverride" ) );
		guard.save<float>( movement_services + SCHEMA( "CCSPlayer_MovementServices", "m_flDuckAmount" ) );
		guard.save<float>( movement_services + SCHEMA( "CCSPlayer_MovementServices", "m_flDuckSpeed" ) );
		guard.save<float>( movement_services + SCHEMA( "CCSPlayer_MovementServices", "m_flDuckRootOffset" ) );
		guard.save<float>( movement_services + SCHEMA( "CCSPlayer_MovementServices", "m_flDuckViewOffset" ) );
		guard.save<float>( movement_services + SCHEMA( "CCSPlayer_MovementServices", "m_flLastDuckTime" ) );
		guard.save<float>( movement_services + SCHEMA( "CCSPlayer_MovementServices", "m_flBombPlantViewOffset" ) );
		guard.save<bool>( movement_services + SCHEMA( "CCSPlayer_MovementServices", "m_bSpeedCropped" ) );
		guard.save<int>( movement_services + SCHEMA( "CCSPlayer_MovementServices", "m_nLadderSurfacePropIndex" ) );
		guard.save<math::vector2>( movement_services + SCHEMA( "CCSPlayer_MovementServices", "m_vecLastPositionAtFullCrouchSpeed" ) );
		guard.save<bool>( movement_services + SCHEMA( "CCSPlayer_MovementServices", "m_duckUntilOnGround" ) );
		guard.save<bool>( movement_services + SCHEMA( "CCSPlayer_MovementServices", "m_bHasWalkMovedSinceLastJump" ) );
		guard.save<bool>( movement_services + SCHEMA( "CCSPlayer_MovementServices", "m_bInStuckTest" ) );
		guard.save<int>( movement_services + SCHEMA( "CCSPlayer_MovementServices", "m_nOldWaterLevel" ) );
		guard.save<float>( movement_services + SCHEMA( "CCSPlayer_MovementServices", "m_flWaterEntryTime" ) );
		guard.save<math::vector3>( movement_services + SCHEMA( "CCSPlayer_MovementServices", "m_vecForward" ) );
		guard.save<math::vector3>( movement_services + SCHEMA( "CCSPlayer_MovementServices", "m_vecLeft" ) );
		guard.save<math::vector3>( movement_services + SCHEMA( "CCSPlayer_MovementServices", "m_vecUp" ) );
		guard.save<int>( movement_services + SCHEMA( "CCSPlayer_MovementServices", "m_nGameCodeHasMovedPlayerAfterCommand" ) );
		guard.save<float>( movement_services + SCHEMA( "CCSPlayer_MovementServices", "m_fStashGrenadeParameterWhen" ) );
		guard.save<std::uintptr_t>( movement_services + SCHEMA( "CCSPlayer_MovementServices", "m_nButtonDownMaskPrev" ) );
		guard.save<float>( movement_services + SCHEMA( "CCSPlayer_MovementServices", "m_flHeightAtJumpStart" ) );
		guard.save<float>( movement_services + SCHEMA( "CCSPlayer_MovementServices", "m_flMaxJumpHeightThisJump" ) );
		guard.save<float>( movement_services + SCHEMA( "CCSPlayer_MovementServices", "m_flMaxJumpHeightLastJump" ) );
		guard.save<float>( movement_services + SCHEMA( "CCSPlayer_MovementServices", "m_flStaminaAtJumpStart" ) );
		guard.save<float>( movement_services + SCHEMA( "CCSPlayer_MovementServices", "m_flVelMulAtJumpStart" ) );
		guard.save<float>( movement_services + SCHEMA( "CCSPlayer_MovementServices", "m_flAccumulatedJumpError" ) );
		guard.save<math::vector2>( movement_services + SCHEMA( "CCSPlayer_MovementServices", "m_vecWalkWishVel" ) );
		guard.save<bool>( movement_services + SCHEMA( "CCSPlayer_MovementServices", "m_bHasEverProcessedCommand" ) );
		guard.save<float>( movement_services + SCHEMA( "CCSPlayer_MovementServices", "m_flTicksSinceLastSurfingDetected" ) );
		guard.save<bool>( movement_services + SCHEMA( "CCSPlayer_MovementServices", "m_bJumpApexPending" ) );
		guard.save<bool>( movement_services + SCHEMA( "CCSPlayer_MovementServices", "m_bWasSurfing" ) );
		guard.save<int>( movement_services + SCHEMA( "CCSPlayer_MovementServices", "m_nLastJumpTick" ) );
		guard.save<float>( movement_services + SCHEMA( "CCSPlayer_MovementServices", "m_flLastJumpFrac" ) );
		guard.save<float>( movement_services + SCHEMA( "CCSPlayer_MovementServices", "m_flLastJumpVelocityZ" ) );
		guard.save<float>( movement_services + SCHEMA( "CCSPlayer_MovementServices", "m_gtLastTimeOnStaticWorldGround" ) );
		guard.save<float>( movement_services + SCHEMA( "CCSPlayer_MovementServices", "m_gtLastTimeInAir" ) );
		guard.save_raw( movement_services + SCHEMA( "CCSPlayer_MovementServices", "m_LegacyJump" ), 24 );
		guard.save_raw( movement_services + SCHEMA( "CCSPlayer_MovementServices", "m_ModernJump" ), 56 );
		guard.save<bool>( movement_services + SCHEMA( "CCSPlayer_MovementServices", "m_bUseFrictionStashedSpeed" ) );
		guard.save<float>( movement_services + SCHEMA( "CCSPlayer_MovementServices", "m_flUseFrictionStashedSpeedUntilFrac" ) );
		guard.save<float>( movement_services + SCHEMA( "CCSPlayer_MovementServices", "m_flFrictionStashedSpeed" ) );

		guard.save<float>( movement_services + SCHEMA( "CPlayer_MovementServices_Humanoid", "m_flSurfaceFriction" ) );
		guard.save<float>( movement_services + SCHEMA( "CPlayer_MovementServices_Humanoid", "m_flFallVelocity" ) );
		guard.save<math::vector3>( movement_services + SCHEMA( "CPlayer_MovementServices_Humanoid", "m_groundNormal" ) );
		guard.save<float>( movement_services + SCHEMA( "CPlayer_MovementServices_Humanoid", "m_flStepSoundTime" ) );
		guard.save<int>( movement_services + SCHEMA( "CPlayer_MovementServices_Humanoid", "m_nStepside" ) );
		guard.save<std::uint32_t>( movement_services + SCHEMA( "CPlayer_MovementServices_Humanoid", "m_surfaceProps" ) );

		{
			if ( old_slot )
			{
				memory::write<std::uint8_t>( old_slot + 140, 0 );
			}

			const auto next_tick = memory::read<int>( local.controller + SCHEMA( "CBasePlayerController", "m_nTickBase" ) ) + 1;
			const auto next_time = static_cast< float >( next_tick ) * 0.015625f;

			memory::write<float>( global_vars + 48, next_time );
			memory::write<float>( global_vars + 52, 0.015625f );
			memory::write<int>( global_vars + 68, next_tick );
			memory::write<float>( global_vars + 80, 0.0f );
			memory::write<std::uint32_t>( global_vars + 88, GetCurrentThreadId( ) );

			memory::write( addresses::globals::simulation_player, local.pawn );
			memory::write( addresses::globals::prediction_player, local.pawn );
			memory::write<int>( local.controller + SCHEMA( "CBasePlayerController", "m_nTickBase" ), next_tick );

			memory::call_guarded<void>( PATTERN( patterns::prediction_set_state ), "patterns::prediction_set_state",  pred_state, std::uint8_t( 1 ) );

			std::uintptr_t pawn_guard[ 1 ]{};
			memory::call_guarded<void>( PATTERN( patterns::prediction_set_pawn ), "patterns::prediction_set_pawn",  pawn_guard, local.pawn );

			memory::call_vfunc<void>( movement_services, 43, cmd_ptr );  // SetupContext

			const auto move_data = memory::call_vfunc<std::uintptr_t>( movement_services, 35 );
			const bool fb_seedsync = memory::call_vfunc<bool>( movement_services, 45 );

			memory::call_guarded<void>( PATTERN( patterns::prediction_setup_move ), "patterns::prediction_setup_move",  move_data, cmd_ptr, next_tick, fb_seedsync ? 1 : 0 );
			memory::call_vfunc<void>( movement_services, 36, cmd_ptr, move_data );  // SetupMove
			memory::write<std::uintptr_t>( movement_services + 408, 0 );

			memory::call_guarded<void>( PATTERN( patterns::prediction_process_movement ), "patterns::prediction_process_movement",  movement_services, cmd_ptr, move_data, 1 );
			memory::call_vfunc<void>( movement_services, 40, cmd_ptr, move_data );  // PostThink_Weapon
			memory::call_guarded<void>( PATTERN( patterns::prediction_finish_move ), "patterns::prediction_finish_move",  movement_services, cmd_ptr, move_data, 1 );

			memory::write( addresses::globals::simulation_player, 0ull );

			memory::call_guarded<void>( PATTERN( patterns::prediction_reset_pawn ), "patterns::prediction_reset_pawn",  pawn_guard );
			memory::call_guarded<void>( PATTERN( patterns::prediction_set_state ), "patterns::prediction_set_state",  pred_state, std::uint8_t( 0 ) );

			fn( );
		}

		guard.restore( );
	}

} // namespace systems