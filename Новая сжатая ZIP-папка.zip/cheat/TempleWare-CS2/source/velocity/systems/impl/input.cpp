#include "../systems.hpp"

namespace systems {

	namespace {

		// See the note at its use site in input::apply.
		constexpr bool k_enable_subtick_movement_fix{ false };

		// See the note at its use site in input::calculate_crc.
		constexpr bool k_enable_move_crc{ false };

	} // namespace

	void input::update( )
	{
		const auto local_controller = memory::read<std::uintptr_t>( addresses::globals::local_player_controller );
		if ( !local_controller )
		{
			this->m_current_cmd = nullptr;
			return;
		}

		this->m_current_cmd = this->get_current_cmd( local_controller );
	}

	void input::apply( )
	{
		const auto local = systems::g_local.get ();

		if ( !this->m_current_cmd ) {
			return;
		}

		const auto base = this->m_current_cmd->csgo_user_cmd.mutable_base( );
		if ( !base ) {
			return;
		}

		auto has_move_subticks = [] (proto::base_usercmd_pb* base_cmd) {
			// just use protobufs atp
			for (int i = 0; i < base_cmd->subtick_moves_size (); i++) {
				proto::subtick_move_step* step = base_cmd->mutable_subtick_moves (i);

				// mutable_subtick_moves(i) goes through impl_ptr and can be null.
				if (!step)
					continue;

				if (step->m_has_bits.test (0x8) || step->m_has_bits.test (0x10))
					return true;

				if (step->m_has_bits.test (0x1))
					return true;
			}

			return false;
		};

		// Upstream's "fix movement for ag2" hack, off by default.
		//
		// It re-adds a synthetic subtick move after desubtick cleared the field.
		// But proto::clear() only sets m_current_size = 0 -- it does not release
		// anything -- so acquire_subtick_step then reuses m_rep->elements[0], or
		// allocates through the game's arena via subtick_move_alloc +
		// utl_vector_push. That is reaching into the engine's own allocator
		// behind its back, using a hand-rolled model of a protobuf repeated
		// field, and it is the remaining crash suspect in apply().
		//
		// It is a movement-feel workaround for one anticheat scenario, not
		// something the ragebot needs. Enable only once the repeated-field layout
		// has been verified against this build.
		if (k_enable_subtick_movement_fix && !has_move_subticks (base)) {
			if (const auto step = systems::g_input.acquire_subtick_step (base->mutable_subtick_moves ())) {

				const auto movement_services = local.pawn ? memory::read<std::uintptr_t> (local.pawn + SCHEMA ("C_BasePlayerPawn", "m_pMovementServices")) : 0;
				if (movement_services) {
					step->set_button (0);
					step->set_pressed (false);
					step->set_when (0.0f);
					step->set_analog_forward_delta (base->forwardmove () - memory::read<float> (movement_services + SCHEMA ("CPlayer_MovementServices", "m_flCmdForwardMove")));
					step->set_analog_left_delta (base->leftmove () - memory::read<float> (movement_services + SCHEMA ("CPlayer_MovementServices", "m_flCmdLeftMove")));
				}
			}
		}

		// mutable_buttons_pb() can return nullptr.
		//
		// Real protobuf allocates an absent sub-message on mutable_X(); velocity's
		// hand-rolled version only sets the has-bit and hands back the existing
		// pointer, which is null until the game itself populates it. Upstream
		// chained straight off it -- that is what crashed here.
		if ( auto* const buttons = base->mutable_buttons_pb( ) )
		{
			buttons->set_buttonstate1( this->m_current_cmd->buttons.value );
			buttons->set_buttonstate2( this->m_current_cmd->buttons.value_changed );
			buttons->set_buttonstate3( this->m_current_cmd->buttons.value_scroll );
		}

		this->calculate_crc( base );
	}

	input::usercmd* input::get_current_cmd( std::uintptr_t local_controller ) const
	{
		const auto usercmd_base = memory::call_guarded<std::uintptr_t>( PATTERN( patterns::get_usercmd_base ), "patterns::get_usercmd_base",  local_controller );
		if ( !usercmd_base )
		{
			return nullptr;
		}

		return memory::call_guarded<usercmd*>( PATTERN( patterns::replacements::get_usercmd ), "patterns::replacements::get_usercmd",  local_controller, memory::read<int>( usercmd_base + 0x5910 ) );
	}

	proto::subtick_move_step* input::acquire_subtick_step( proto::repeated_ptr_field<proto::subtick_move_step>* subtick_moves ) const
	{
		if ( !subtick_moves )
		{
			return nullptr;
		}

		if ( subtick_moves->m_rep )
		{
			if ( subtick_moves->m_current_size < subtick_moves->m_rep->allocated_size )
			{
				const auto element = subtick_moves->m_rep->elements[ subtick_moves->m_current_size ];
				if ( element )
				{
					subtick_moves->m_current_size++;
					return proto::impl_ptr<proto::subtick_move_step>( element );
				}
			}
		}

		const auto move_step = memory::call_guarded<void*>( PATTERN( patterns::subtick_move_alloc ), "patterns::subtick_move_alloc",  subtick_moves->m_arena );
		if ( move_step )
		{
			memory::call_guarded<std::uintptr_t>( PATTERN( patterns::utl_vector_push ), "patterns::utl_vector_push",  reinterpret_cast< std::uintptr_t >( subtick_moves ), reinterpret_cast< std::uintptr_t >( move_step ) );
			return proto::impl_ptr<proto::subtick_move_step>( move_step );
		}

		return nullptr;
	}

	math::vector3 input::get_view_angles( ) const
	{
		// The guard returns nullptr for an unresolved signature, so this must not
		// dereference blindly -- that would trade a null call for a null read.
		const auto angles = memory::call_guarded<math::vector3*>(
			PATTERN( patterns::get_view_angles ), "patterns::get_view_angles",
			addresses::globals::csgo_input, 0 );

		return angles ? *angles : math::vector3{};
	}

	proto::input_history_entry* input::push_input_history( usercmd* cmd, const input_history_params& params ) const
	{
		auto history_field = cmd->csgo_user_cmd.mutable_input_history( );
		if ( !history_field )
		{
			return nullptr;
		}

		proto::input_history_entry* entry{ nullptr };

		if ( history_field->m_rep )
		{
			if ( history_field->m_current_size < history_field->m_rep->allocated_size )
			{
				auto element = history_field->m_rep->elements[ history_field->m_current_size ];
				if ( element )
				{
					history_field->m_current_size++;
					entry = proto::impl_ptr<proto::input_history_entry>( element );
				}
			}
		}

		if ( !entry )
		{
			auto raw = memory::call_guarded<void*>( PATTERN( patterns::history_field_alloc ), "patterns::history_field_alloc",  history_field->m_arena );
			if ( !raw )
			{
				return nullptr;
			}

			memory::call_guarded<std::uintptr_t>( PATTERN( patterns::utl_vector_push ), "patterns::utl_vector_push",  reinterpret_cast< std::uintptr_t >( history_field ), reinterpret_cast< std::uintptr_t >( raw ) );

			entry = proto::impl_ptr<proto::input_history_entry>( raw );
		}

		if ( !entry )
		{
			return nullptr;
		}

		entry->set_render_tick_count( params.render_tick );
		entry->set_render_tick_fraction( params.render_frac );
		entry->set_player_tick_count( params.player_tick );
		entry->set_player_tick_fraction( params.player_frac );
		entry->set_frame_number( params.frame_number );
		entry->set_target_ent_index( params.target_ent_index );

		if ( auto va = entry->mutable_view_angles( ) )
		{
			va->set_x( params.view_angles.x );
			va->set_y( params.view_angles.y );
			va->set_z( params.view_angles.z );
		}

		if ( auto sp = entry->mutable_shoot_position( ) )
		{
			sp->set_x( params.shoot_position.x );
			sp->set_y( params.shoot_position.y );
			sp->set_z( params.shoot_position.z );
		}

		if ( auto ci = entry->mutable_cl_interp( ) )
		{
			ci->set_frac( params.cl_interp_frac );
		}

		if ( auto si0 = entry->mutable_sv_interp0( ) )
		{
			si0->set_src_tick( params.sv_interp0_src );
			si0->set_dst_tick( params.sv_interp0_dst );
			si0->set_frac( params.sv_interp0_frac );
		}

		if ( auto si1 = entry->mutable_sv_interp1( ) )
		{
			si1->set_src_tick( params.sv_interp1_src );
			si1->set_dst_tick( params.sv_interp1_dst );
			si1->set_frac( params.sv_interp1_frac );
		}

		if ( auto pi = entry->mutable_player_interp( ) )
		{
			pi->set_src_tick( params.player_interp_src );
			pi->set_dst_tick( params.player_interp_dst );
			pi->set_frac( params.player_interp_frac );
		}

		if ( params.fill_cheat_check_data )
		{
			if ( auto head = entry->mutable_target_head_pos_check( ) )
			{
				head->set_x( params.target_head_pos.x );
				head->set_y( params.target_head_pos.y );
				head->set_z( params.target_head_pos.z );
			}

			if ( auto abs_pos = entry->mutable_target_abs_pos_check( ) )
			{
				abs_pos->set_x( params.target_abs_pos.x );
				abs_pos->set_y( params.target_abs_pos.y );
				abs_pos->set_z( params.target_abs_pos.z );
			}

			if ( auto abs_ang = entry->mutable_target_abs_ang_check( ) )
			{
				abs_ang->set_x( params.target_abs_ang.x );
				abs_ang->set_y( params.target_abs_ang.y );
				abs_ang->set_z( params.target_abs_ang.z );
			}
		}

		return entry;
	}

	void input::set_view_angles( const math::vector3& angles ) const
	{
		memory::call_guarded<void>( PATTERN( patterns::replacements::set_view_angles ), "patterns::replacements::set_view_angles",  addresses::globals::csgo_input, 0, &angles );
	}

	void input::desubtick( usercmd* cmd ) const
	{
		// Same hazard: mutable_base() is an impl_ptr and may be null.
		if ( auto* const base = cmd->csgo_user_cmd.mutable_base( ) )
		{
			if ( auto* const moves = base->mutable_subtick_moves( ) )
			{
				moves->clear( );
			}
		}
	}

	void input::set_weapon_select( usercmd* cmd, std::uintptr_t csgo_input ) const
	{
		const auto frame_data = csgo_input + 552;
		const auto weapon_handle = memory::read<uint32_t>( frame_data + 1132 );

		if ( !weapon_handle )
		{
			return;
		}

		const auto weapon = systems::g_entities.lookup( weapon_handle );
		if ( !weapon )
		{
			return;
		}

		auto entity_index{ -1 };
		memory::call_guarded<int*>( PATTERN( patterns::weapon_get_entity_index ), "patterns::weapon_get_entity_index",  weapon, &entity_index );

		if ( entity_index == -1 )
		{
			return;
		}

		const auto base = cmd->csgo_user_cmd.mutable_base( );
		if ( base )
		{
			base->set_weaponselect( entity_index );
		}
	}

	input::usercmd* input::get_command_by_sequence( std::uintptr_t local_controller, int sequence ) const
	{
		const auto usercmd_base = memory::call_guarded<std::uintptr_t>( PATTERN( patterns::get_usercmd_base ), "patterns::get_usercmd_base",  local_controller );
		if ( !usercmd_base )
		{
			return nullptr;
		}

		const auto index = sequence % 150;
		return reinterpret_cast< usercmd* >( usercmd_base + sizeof( usercmd ) * index );
	}

	bool input::is_subtick_overwrite( usercmd* cmd ) const
	{
		return memory::read<int>( reinterpret_cast< std::uintptr_t >( cmd ) + 148 ) == 2;
	}

	bool input::calculate_crc( proto::base_usercmd_pb* base ) const
	{
		if ( !base )
		{
			return false;
		}

		const auto btns = base->buttons_pb( );
		const auto va = base->viewangles( );

		std::uint8_t buf[ 64 ]{};
		std::uint8_t btn_size{ 0 };

		auto p = buf;

		auto bs1 = btns ? btns->buttonstate1( ) : 0;
		auto bs2 = btns ? btns->buttonstate2( ) : 0;
		auto bs3 = btns ? btns->buttonstate3( ) : 0;

		if ( bs1 ) { btn_size += 9; }
		if ( bs2 ) { btn_size += 9; }
		if ( bs3 ) { btn_size += 9; }

		if ( btn_size > 0 )
		{
			*p++ = 0x1a;
			*p++ = btn_size;

			if ( bs1 ) { *p++ = 0x09; std::memcpy( p, &bs1, 8 ); p += 8; }
			if ( bs2 ) { *p++ = 0x11; std::memcpy( p, &bs2, 8 ); p += 8; }
			if ( bs3 ) { *p++ = 0x19; std::memcpy( p, &bs3, 8 ); p += 8; }
		}

		auto pitch = va ? va->x( ) : 0.0f;
		auto yaw = va ? va->y( ) : 0.0f;
		auto roll = va ? va->z( ) : 0.0f;

		std::uint8_t va_size{ 0 };
		if ( pitch != 0.0f ) { va_size += 5; }
		if ( yaw != 0.0f ) { va_size += 5; }
		if ( roll != 0.0f ) { va_size += 5; }

		if ( va_size > 0 )
		{
			*p++ = 0x22;
			*p++ = va_size;

			if ( pitch != 0.0f ) { *p++ = 0x0d; std::memcpy( p, &pitch, 4 ); p += 4; }
			if ( yaw != 0.0f ) { *p++ = 0x15; std::memcpy( p, &yaw, 4 ); p += 4; }
			if ( roll != 0.0f ) { *p++ = 0x1d; std::memcpy( p, &roll, 4 ); p += 4; }
		}

		auto total = static_cast< int >( p - buf );

		// Only claim a move CRC is present if one is actually computed. Gating
		// the calls below while still setting this bit told the game a CRC had
		// been written when it had not -- a worse state than not touching it.
		if constexpr ( !k_enable_move_crc )
		{
			return true;
		}

		base->m_has_bits.set( 0x1u );

		// The two engine calls below are the remaining crash suspect, and are
		// gated off by default.
		//
		// serialize_move_crc is one of the signatures re-pointed from
		// cs2-universal-offsets (SerializeUserCmd @ 0x91db20). It was verified
		// statically -- unique match at the expected RVA -- but never at runtime,
		// and a unique byte match proves the pattern is unambiguous, not that the
		// function takes these arguments. Calling it with the wrong signature
		// corrupts the stack.
		//
		// CONSEQUENCE OF LEAVING THIS OFF: the move CRC is not recomputed. That
		// is harmless while the ragebot is off (nothing modified the command),
		// but once view angles are written the CRC will not match what was sent,
		// which the server can notice. This must be resolved before the ragebot
		// is usable -- it is deferred, not solved.
		{
			auto raw_msg = reinterpret_cast< std::uintptr_t >( base ) - proto::message_impl_offset;
			auto arena_raw = memory::read_or<std::uintptr_t>( raw_msg + 0x08 );
			auto arena = arena_raw & ~0x3ull;

			if ( arena_raw & 1 )
			{
				arena = memory::read_or<std::uintptr_t>( arena );
			}

			std::uint8_t msg[ 0x18 ]{};
			memory::call_guarded<void>( PATTERN( patterns::string_copy ), "patterns::string_copy", reinterpret_cast< std::uintptr_t >( msg ), reinterpret_cast< std::uintptr_t >( buf ), total );
			memory::call_guarded<void>( PATTERN( patterns::replacements::serialize_move_crc ), "patterns::replacements::serialize_move_crc", &base->m_move_crc, reinterpret_cast< std::uintptr_t >( msg ), arena );

			return true;
		}
	}

} // namespace systems