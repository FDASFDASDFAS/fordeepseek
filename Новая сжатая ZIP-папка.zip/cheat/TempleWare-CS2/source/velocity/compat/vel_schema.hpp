#pragma once

// Bridges velocity's SCHEMA() onto TempleWare's existing schema dump.
//
// The two projects key their schema tables differently:
//
//   velocity    systems::schemas::lookup( "C_BaseEntity", "m_pGameSceneNode"_hash )
//               -- walks the live type scope on every distinct call site,
//                  hashing only the field name
//
//   TempleWare  SchemaFinder::Get( hash_32_fnv1a_const( "C_BaseEntity->m_pGameSceneNode" ) )
//               -- one up-front dump into a flat table, keyed on the joined
//                  "Class->field" string
//
// TempleWare's dump already covers both client.dll and animationsystem.dll (see
// Schema::init), so rather than standing up a second, parallel schema system
// the macro joins its two literal arguments and defers to SchemaFinder. Both
// projects hash with the same FNV-1a 32 constants, so the keys agree.
//
// This is why the ported call sites read SCHEMA( "Class", "field" ) and not
// SCHEMA( "Class", "field"_hash ): the field name has to survive as a literal
// so it can be concatenated. The rewrite is mechanical and total -- every
// SCHEMA call site in the ported sources was converted.

#include "../fnv1a.hpp"

#include "../../templeware/utils/schema/schema.h"

#include <cstdint>

// Resolved once per call site and cached, matching upstream's behaviour.
// Returns 0 for a field the dump never saw, exactly as SchemaFinder::Get does,
// so a missing field degrades to "offset 0" rather than faulting -- callers
// that care should check.
#define SCHEMA( class_name, field_name ) \
	( []( ) -> std::uint32_t { \
		static const auto val = SchemaFinder::Get( hash_32_fnv1a_const( class_name "->" field_name ) ); \
		return val; \
	}( ) )
