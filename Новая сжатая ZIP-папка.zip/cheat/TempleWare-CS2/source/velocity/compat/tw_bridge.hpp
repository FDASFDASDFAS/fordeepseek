#pragma once

// Conversions across the seam between the ported velocity code and TempleWare.
//
// All three vector types are three consecutive floats, so these are pure
// reinterpretations of the same data -- kept as explicit functions rather than
// casts so the seam is greppable and so a layout change breaks the build here
// instead of producing silently wrong coordinates.

#include "../math/math.hpp"

#include "../../templeware/utils/math/vector/vector.h"
#include "../../templeware/entities/entity_state.h"
#include "../../../external/imgui/imgui.h"

#include <type_traits>
#include <utility>

namespace vel::compat {

	static_assert( sizeof( math::vector3 ) == sizeof( float ) * 3 );
	static_assert( sizeof( Vector_t ) == sizeof( float ) * 3 );
	static_assert( sizeof( tw::entities::Vec3 ) == sizeof( float ) * 3 );

	static_assert( std::is_standard_layout_v<math::vector3> );
	static_assert( std::is_standard_layout_v<tw::entities::Vec3> );

	[[nodiscard]] inline math::vector3 to_vel( const Vector_t& v ) noexcept
	{
		return { v.x, v.y, v.z };
	}

	[[nodiscard]] inline math::vector3 to_vel( const tw::entities::Vec3& v ) noexcept
	{
		return { v.x, v.y, v.z };
	}

	[[nodiscard]] inline Vector_t to_tw( const math::vector3& v ) noexcept
	{
		return { v.x, v.y, v.z };
	}

	[[nodiscard]] inline tw::entities::Vec3 to_tw_vec3( const math::vector3& v ) noexcept
	{
		return { v.x, v.y, v.z };
	}

	// Stands in for velocity's xdraw::viewport_size(). TempleWare renders through
	// ImGui, so the backbuffer dimensions come from the IO block the DX11 backend
	// already maintains.
	//
	// Only meaningful once ImGui has been initialised and a frame's IO has been
	// populated -- before that it reads back {0, 0}. Callers here are all in the
	// world-to-screen path, which only runs during rendering, so that holds.
	//
	// Returns a pair to match upstream's shape (call sites use both .first/.second
	// and structured bindings), but float rather than xdraw's int: DisplaySize is
	// already float and every caller immediately multiplies by 0.5f, so this drops
	// a pointless truncation and stays correct under fractional DPI scaling.
	[[nodiscard]] inline std::pair<float, float> viewport_size( ) noexcept
	{
		const auto& display = ImGui::GetIO( ).DisplaySize;
		return { display.x, display.y };
	}

} // namespace vel::compat
