#pragma once

// Ported from velocity's utilities/memory. The DEV gate upstream existed to
// strip the resolver out of release builds (which baked offsets in at build
// time via the loader bridge). TempleWare resolves at runtime, so the resolver
// is always compiled in here and the gate is gone.

#include <Windows.h>

#include <cstdint>
#include <cstddef>
#include <optional>
#include <string>
#include <string_view>
#include <type_traits>

namespace memory {

	[[nodiscard]] std::uintptr_t get_module_base( std::string_view module_name );
	[[nodiscard]] std::uintptr_t get_module_export( std::string_view export_name );
	[[nodiscard]] std::uintptr_t get_module_export_with_base( std::uintptr_t module_base, std::string_view export_name );
	[[nodiscard]] std::uintptr_t get_module_interface( std::string_view interface_name );

	// Accepts "module.dll:AA BB ?? CC" with velocity's resolver suffixes:
	//   >  operand of a rel32 call/jmp at this byte -> follow it
	//   *  rip-relative displacement at this byte   -> follow it
	//   ^  absolute pointer at this byte            -> read it
	//   ~  dereference the final result
	//   +N / -N  add/subtract a hex offset at the end
	[[nodiscard]] std::uintptr_t resolve_pattern( std::string_view pattern );

	[[nodiscard]] std::uintptr_t get_module_export( std::uintptr_t module_base, std::uint16_t ordinal );
	[[nodiscard]] std::uintptr_t get_module_size( std::uintptr_t module_base );

	[[nodiscard]] std::uintptr_t find_vtable_by_rtti( std::uintptr_t module_base, std::string_view class_name );
	[[nodiscard]] std::uintptr_t find_instance_by_rtti( std::uintptr_t module_base, std::string_view class_name );
	[[nodiscard]] std::uintptr_t find_global_instance_by_vtable( std::uintptr_t module_base, std::uintptr_t vtable_address );

	template <typename T>
	[[nodiscard]] inline T read( std::uintptr_t address )
	{
		return *reinterpret_cast< T* >( address );
	}

	template <typename T>
	[[nodiscard]] inline std::optional<T> safe_read( std::uintptr_t address )
	{
		__try
		{
			return *reinterpret_cast< T* >( address );
		}
		__except ( EXCEPTION_EXECUTE_HANDLER )
		{
			return std::nullopt;
		}
	}

	// safe_read that yields T rather than optional<T>, so it drops straight into
	// arithmetic-heavy call sites (`read_or<uintptr_t>(x) + SCHEMA(...)`).
	//
	// Used where a read can legitimately fault: entity/pawn state polled every
	// tick, which may be mid-teardown across a level transition.
	template <typename T>
	[[nodiscard]] inline T read_or( std::uintptr_t address, T fallback = T{} )
	{
		if ( !address )
		{
			return fallback;
		}

		const auto value = safe_read<T>( address );
		return value ? *value : fallback;
	}

	template <typename T>
	inline void write( std::uintptr_t address, const T& value )
	{
		// An unresolved global is 0, and writing through it is a null store.
		// resolve_pattern also returns 0 for an AMBIGUOUS pattern now, which is
		// the case that matters here: prediction.cpp writes the local pawn
		// pointer to addresses::globals::prediction_player, and a wrong address
		// there corrupts whatever client.dll keeps at that spot.
		if ( !address ) [[unlikely]]
		{
			return;
		}

		*reinterpret_cast< T* >( address ) = value;
	}

	template <typename T, typename... args_t>
	inline T call( std::uintptr_t address, args_t... args )
	{
		return reinterpret_cast< T( __fastcall* )( args_t... ) >( address )( args... );
	}

	// Reports an unresolved call target once per site. Defined in memory.cpp so
	// the header stays free of <iostream>.
	void report_null_call( const char* what );

	// call(), but survives an unresolved signature.
	//
	// PATTERN() yields 0 when a pattern does not match, and plain call() casts
	// that straight to a function pointer and jumps to null -- so a stale
	// signature crashes the game rather than doing nothing. 31% of velocity's
	// patterns are dead on this build, so that is not a hypothetical.
	//
	// Returns a value-initialised T instead, which every caller here already
	// treats as "no result": a zeroed trace, a zero angle, a false.
	template <typename T, typename... args_t>
	inline T call_guarded( std::uintptr_t address, const char* what, args_t... args )
	{
		if ( !address ) [[unlikely]]
		{
			report_null_call( what );

			if constexpr ( !std::is_void_v<T> )
			{
				return T{};
			}
			else
			{
				return;
			}
		}

		return reinterpret_cast< T( __fastcall* )( args_t... ) >( address )( args... );
	}

	template <typename T, typename... args_t>
	inline T call_vfunc( std::uintptr_t instance, std::size_t index, args_t... args )
	{
		const auto vtable = *reinterpret_cast< std::uintptr_t* >( instance );
		const auto func = *reinterpret_cast< std::uintptr_t* >( vtable + index * sizeof( std::uintptr_t ) );

		return reinterpret_cast< T( __fastcall* )( std::uintptr_t, args_t... ) >( func )( instance, args... );
	}

	[[nodiscard]] std::uintptr_t get_vfunc( std::uintptr_t instance, std::size_t index );
	[[nodiscard]] std::string read_string( std::uintptr_t address, std::size_t max_length = 256 );

} // namespace memory
