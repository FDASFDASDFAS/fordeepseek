#pragma once

// Trimmed stand-in for velocity's <pch/pch.hpp>.
//
// The upstream PCH drags in phnt, zydis, lz4, xdraw, poly2d and bc7 -- all of
// which serve the rendering, resource and protection layers. The combat port
// needs none of them, so this keeps only the standard headers those
// translation units actually rely on, plus the compat math/memory utilities.
//
// Anything that used to come from <utilities/...> lives under source/velocity/
// here; the include paths below are what the ported .cpp files expect.

#define NOMINMAX
#define WIN32_LEAN_AND_MEAN

#include <Windows.h>

// types
#include <cstdint>
#include <cstddef>
#include <string>
#include <string_view>
#include <cmath>
#include <numbers>
#include <format>
#include <functional>
#include <chrono>
#include <variant>
#include <optional>
#include <random>

// containers
#include <array>
#include <span>
#include <vector>
#include <deque>
#include <unordered_set>
#include <unordered_map>

// memory
#include <memory>

// algorithms
#include <numeric>
#include <ranges>
#include <algorithm>

// concurrency
#include <atomic>
#include <mutex>
#include <shared_mutex>

// compat utilities
#include "fnv1a.hpp"
#include "cstypes.hpp"
#include "math/math.hpp"
#include "memory/memory.hpp"
#include "addresses/vel_addresses.hpp"
#include "compat/tw_bridge.hpp"
#include "compat/vel_schema.hpp"
