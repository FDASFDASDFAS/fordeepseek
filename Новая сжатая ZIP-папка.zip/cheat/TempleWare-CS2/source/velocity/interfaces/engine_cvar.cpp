#include "vel_interfaces.hpp"

#include "../fnv1a.hpp"
#include "../memory/memory.hpp"

namespace interfaces {

	c_convar* c_engine_cvar::find(std::uint32_t name_hash)
	{
		if (!m_container)
			return 0;

		// Every step is guarded and the walk is bounded.
		//
		// Upstream read m_container[current] directly, chased m_next_index with no
		// iteration cap, and ran strlen over m_cvar->m_name. If the container
		// pointer or a next_index is stale, that reads out of bounds and can loop
		// indefinitely -- and this runs from local::update every tick.
		constexpr std::uint16_t k_invalid = static_cast<std::uint16_t>(-1);
		constexpr int k_max_iterations = 8192;

		auto current = static_cast<std::uint16_t>(0);

		for (int i = 0; i < k_max_iterations && current != k_invalid; ++i)
		{
			const auto entry = memory::safe_read<cvar_container_t>(
				reinterpret_cast<std::uintptr_t>(m_container + current));

			if (!entry)
				return 0;

			if (entry->m_cvar)
			{
				const auto name = memory::safe_read<const char*>(
					reinterpret_cast<std::uintptr_t>(&entry->m_cvar->m_name));

				if (name && *name)
				{
					// Bounded, byte-guarded hash: m_name may be freed.
					auto hash = 2166136261u;
					auto ok = true;

					for (std::size_t k = 0; k < 128; ++k)
					{
						const auto c = memory::safe_read<char>(
							reinterpret_cast<std::uintptr_t>(*name) + k);

						if (!c)
						{
							ok = false;
							break;
						}

						if (*c == '\0')
							break;

						hash ^= static_cast<std::uint32_t>(*c);
						hash *= 16777619u;
					}

					if (ok && hash == name_hash)
						return entry->m_cvar;
				}
			}

			current = entry->m_next_index;
		}

		return 0;
	}

	bool c_engine_cvar::unlock_all()
	{
		constexpr std::int32_t FCVAR_HIDDEN = (1 << 4);
		constexpr std::int32_t FCVAR_DEVELOPMENTONLY = (1 << 1);

		for (std::uint16_t current = 0; current != static_cast<std::uint16_t>(-1); )
		{
			const auto entry = m_container[current];

			if (entry.m_cvar)
			{
				entry.m_cvar->m_flags &= ~FCVAR_HIDDEN;
				entry.m_cvar->m_flags &= ~FCVAR_DEVELOPMENTONLY;
			}

			current = entry.m_next_index;
		}

		return true;
	}

} // namespace interfaces