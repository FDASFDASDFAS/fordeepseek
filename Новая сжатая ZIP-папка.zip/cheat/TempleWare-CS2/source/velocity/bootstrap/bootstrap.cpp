#include "bootstrap.h"

#include "../systems/systems.hpp"

#include <format>
#include <iostream>
#include <unordered_set>

namespace velocity {

	bool initializeAddresses()
	{
		const auto modules_ok = addresses::modules::initialize();
		const auto globals_ok = addresses::globals::initialize();

		if (!modules_ok || !globals_ok)
		{
			std::cout << "  combat: [!] some addresses unresolved (see UNRESOLVED above)."
				<< " Dependent features degrade; they do not crash -- every call site is guarded."
				<< std::endl;
		}

		return modules_ok && globals_ok;
	}

	void selfTestHitboxes(unsigned long long entityHandleOrPawn)
	{
		static std::unordered_set<unsigned long long> seen{};

		const auto pawn = static_cast<std::uintptr_t>(entityHandleOrPawn);
		if (!pawn || !seen.insert(entityHandleOrPawn).second)
		{
			return;
		}

		const auto scene_node = memory::safe_read<std::uintptr_t>(
			pawn + SCHEMA("C_BaseEntity", "m_pGameSceneNode"));

		if (!scene_node || !*scene_node)
		{
			std::cout << std::format("[combat] selftest {:#x}: no game scene node", pawn) << std::endl;
			return;
		}

		const auto set = systems::g_hitboxes.query(*scene_node);

		std::cout << std::format("[combat] selftest pawn={:#x} scene_node={:#x} -> {} hitboxes",
			pawn, *scene_node, set.count) << std::endl;

		if (set.count == 0)
		{
			std::cout << "[combat] [!] hitbox chain returned nothing -- offsets moved, re-run"
				" systems::hitbox_discovery (g_enabled = true)" << std::endl;
			return;
		}

		auto without_bone = 0;
		for (const auto& hb : set)
		{
			if (hb.bone < 0)
			{
				++without_bone;
			}
		}

		// Print a couple of entries so the values can be eyeballed against the
		// known-good table (head is group 1 radius 4.3, neck group 8 radius 3.5).
		for (auto i = 0; i < set.count && i < 3; ++i)
		{
			const auto& hb = set.entries[i];
			std::cout << std::format("    [{}] group={} radius={:.2f} bone={} mins=({:.1f},{:.1f},{:.1f})",
				hb.index, hb.group, hb.radius, hb.bone, hb.mins.x, hb.mins.y, hb.mins.z) << std::endl;
		}

		if (without_bone)
		{
			std::cout << std::format("[combat] [!] {}/{} hitboxes have no bone index -- "
				"world-space transforms unavailable for those", without_bone, set.count) << std::endl;
		}
		else
		{
			std::cout << "[combat] hitbox chain OK: geometry, hitgroups and bones all resolved"
				<< std::endl;
		}
	}

} // namespace velocity
