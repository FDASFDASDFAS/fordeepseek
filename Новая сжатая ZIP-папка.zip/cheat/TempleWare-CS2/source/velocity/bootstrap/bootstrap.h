#pragma once

namespace velocity {

	// Resolves the module bases and global pointers the ported velocity systems
	// need, and reports what did and did not resolve.
	//
	// Read-only: it scans and stores addresses, hooks nothing and calls no game
	// functions. Safe to run before the hook layer exists, which is the point --
	// it answers "which of these actually resolve on this build" without risking
	// a crash.
	//
	// Returns false if anything is missing. That is expected right now: six
	// signatures are still dead (net_client, weapon_recoil_data,
	// prediction_set_pawn/state, get_net_channel, trace_bullet_free), so a false
	// return is informational, not fatal -- the caller should log and continue.
	bool initializeAddresses();

	// One-shot end-to-end check of the hitbox chain against a live player:
	// resolves the model, enumerates hitboxes, and reports geometry, hitgroups
	// and bone indices. This is the first time the task 7/8 work is exercised by
	// the shipping code path rather than by the RE probe.
	//
	// Safe to call repeatedly; reports once per distinct entity.
	void selfTestHitboxes(unsigned long long entityHandleOrPawn);

} // namespace velocity
