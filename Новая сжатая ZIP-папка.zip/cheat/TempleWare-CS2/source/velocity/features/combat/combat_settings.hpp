#pragma once

// Minimal stand-in for the slice of velocity's core/settings.hpp that the
// combat code reads.
//
// Upstream these are xui::setting / config::val<T> objects wired to their menu
// and config serialiser. TempleWare has its own config system, so rather than
// drag xui in, this reproduces only the shape the ported code touches. Task 6
// replaces the storage with reads from TempleWare's settings store; the call
// sites do not change.
//
// The namespace split mirrors velocity exactly: TYPES live in settings::combat
// (the ported code writes settings::combat::ragebot::weapon_group in function
// signatures) while the OBJECT is settings::g_combat.

#include "../../cstypes.hpp"

#include <array>
#include <cstddef>
#include <cstdint>

namespace settings {

	// Upstream this is xui::setting / config::val<T>, both of which convert
	// implicitly to their underlying type -- the ported code uses `.value` and
	// the bare object interchangeably, so the conversions are required, not a
	// convenience.
	template <typename T>
	struct val
	{
		T value{};

		constexpr operator const T& ( ) const noexcept { return this->value; }
		constexpr operator T& ( ) noexcept { return this->value; }
	};

	// velocity's config::bools<N>. The member is `values` (plural) -- the ported
	// code indexes it directly as config.hitboxes.values[i].
	template <std::size_t N>
	struct bools
	{
		std::array<bool, N> values{};
	};

} // namespace settings

namespace settings::combat {

	struct lagcomp
	{
		// Defaults throughout this file are velocity's.
		val<int> max_backtrack_ticks{ 12 };
		val<bool> extrapolation{ true };
		val<int> max_extrapolate_ticks{ 8 };
	};

	struct ragebot
	{
		static constexpr auto k_group_count{ 6u };

		val<bool> enabled{ true };

		struct weapon_group
		{
			val<bool> silent{ true };
			val<bool> no_spread{ false };
			val<bool> doubletap{ false };
			val<bool> body_aim{ false };
			val<bool> force_shot_air{ false };
			val<bool> force_shot{ false };

			val<float> max_fov{ 180.0f };

			val<int> hitchance{ 80 };
			val<int> min_damage{ 1 };

			val<int> min_damage_override_value{ 11 };
			val<bool> min_damage_override{ false };

			val<int> hitchance_override_value{ 75 };
			val<bool> hitchance_override{ false };

			val<float> pointscale{ 85.0f };
			val<bool> dynamic_pointscale{ true };
			val<bool> debug_multipoints{ false };

			bools<6> hitboxes{ { true, true, true, true, true, true } };
		};

		std::array<weapon_group, k_group_count> groups{};

		// Same clamping as upstream: a weapon outside the known range falls back
		// to group 2 rather than indexing out of bounds.
		[[nodiscard]] weapon_group& get_group( std::uint32_t weapon_type )
		{
			const auto idx = weapon_type - cstypes::weapon_type::pistol;
			return this->groups[ idx < k_group_count ? idx : 2 ];
		}

		[[nodiscard]] const weapon_group& get_group( std::uint32_t weapon_type ) const
		{
			const auto idx = weapon_type - cstypes::weapon_type::pistol;
			return this->groups[ idx < k_group_count ? idx : 2 ];
		}
	};

	struct knifebot
	{
		val<bool> enabled{ false };
		val<float> max_fov{ 180.0f };
	};

	struct zeusbot
	{
		val<bool> enabled{ false };
		val<bool> drop_after{ false };
		val<float> max_fov{ 180.0f };
	};

	struct antiaim
	{
		val<bool> hide_shots{ true };
	};

	struct duckpeek
	{
		val<bool> enabled{ false };
	};

	// Rendering-only. Kept so the ported code compiles; the draw functions
	// themselves are not ported (see the note in combat.hpp) and come with the
	// menu work in task 6.
	struct penetration_crosshair
	{
		val<bool> enabled{ false };
	};

} // namespace settings::combat

namespace settings {

	struct combat_settings
	{
		combat::lagcomp m_lagcomp{};
		combat::ragebot m_ragebot{};
		combat::knifebot m_knifebot{};
		combat::zeusbot m_zeusbot{};
		combat::antiaim m_antiaim{};
		combat::duckpeek m_duckpeek{};
		combat::penetration_crosshair m_penetration_crosshair{};
	};

	inline combat_settings g_combat{};

	// Only the sliver of velocity's misc settings the combat code reads.
	struct misc_settings
	{
		struct impacts_settings
		{
			val<bool> console_log{ false };
		} m_impacts{};
	};

	inline misc_settings g_misc{};

} // namespace settings
