#pragma once

// Signature table lifted from velocity's protection/patterns.cpp.
//
// Upstream wrapped every entry in ADDRESS_IMPL so a packer could swap the
// string for a pre-resolved encoded address at build time. TempleWare
// resolves at runtime, so the scaffolding is dropped and only the signature
// survives -- see vel_addresses.hpp for the PATTERN() resolver.
//
// Resolver suffixes: '>' rel32 call operand, '*' rip-relative displacement,
// '^' absolute pointer, '~' deref result, '+N'/'-N' trailing hex offset.
//
// WARNING: these matched the CS2 build velocity was last updated against.
// Every one of them needs re-verifying against the live client -- a stale
// signature resolves to 0 and the dependent feature silently no-ops.

// ---------------------------------------------------------------------------
// REPLACEMENTS for signatures that are dead on build 14172.
//
// 42 of the 137 patterns below score zero matches against the live client.dll.
// The ones combat needs are re-pointed here, taken from cs2-universal-offsets
// and each verified to match uniquely.
//
// Identification did NOT go by name -- velocity's own names are frequently
// wrong, which the address cross-map proved: its `get_tick_view_angles` is
// really SpreadSeedGen, `game_scene_node_set_mesh_group` is CalcWorldSpaceBones,
// and `trace_bullet_update` is TraceGetInfo. Its *usage* is right; the labels
// are not. So these were placed by address neighbourhood against a known-good
// anchor instead.
//
// The anchor: velocity's working `trace_bullet_update` resolves to 0x845110 =
// TraceGetInfo. The whole trace family sits around it --
//   0x83e870 TraceInitData
//   0x842a00 CreateTrace
//   0x845110 TraceGetInfo          <- anchor, velocity trace_bullet_update
//   0x8606f0 TraceHandleBulletPen
//   0x9cd5e0 TraceShape
//   0x9cdf30 GameTraceLine
//
// Independently corroborated: computing client.dll's base from this project's
// own init log (TraceShape 0x7FFACB1DD5E0 - RVA 0x9CD5E0) gives 0x7FFACA810000,
// and InitFilter 0x7FFACAB532E0 - RVA 0x3432E0 gives the same base. So the
// repo's TraceShape/TraceInitFilter are exactly the functions tw::tracing
// already resolves every run.
// ---------------------------------------------------------------------------

namespace patterns::replacements {

	// trace_data constructor -- trace_data*(trace_data*)
	inline constexpr const char* trace_data_ctor =
		"client.dll:48895C2408488974241057 4883EC20 488D7908 33";

	// CreateTrace(trace_data, start*, end*, filter*, penetration_count, trace_world)
	inline constexpr const char* create_trace =
		"client.dll:48895C240848896C2410488974241857 415641574883EC40F20F1002";

	// Whole-trace penetration/damage simulation over the generated contacts.
	inline constexpr const char* trace_bullet =
		"client.dll:40535741564883EC508B842490000000 4C8BF14881C1041D0000";

	// trace_ray_entity -- trace restricted to one entity
	inline constexpr const char* trace_ray_entity =
		"client.dll:4C8BDC49895B0849896B1049897318 5748 81EC80000000 33";

	// get_usercmd -- fetch a CUserCmd by sequence number
	inline constexpr const char* get_usercmd =
		"client.dll:4053 4883EC20 8BDA E8????????4C8BC0";

	// serialize_move_crc
	inline constexpr const char* serialize_move_crc =
		"client.dll:40555641574883EC608B4A2045 33FF44";

	// set_view_angles
	inline constexpr const char* set_view_angles =
		"client.dll:85D2753D486381500B0000F2410F1000";

} // namespace patterns::replacements

namespace patterns {

	inline constexpr const char* add_entity                       = "client.dll:90200000488D05*????????48890733D2+78~";
	inline constexpr const char* analyze_pe_module                = "client.dll:004C89BDA0000000>E8????????84C07445";
	inline constexpr const char* base_fire_guns_get_inaccuracy    = "client.dll:>E8????????84C00F84C6FEFFFF";
	inline constexpr const char* build_diagnostic_response        = "client.dll:8954241053565741544155415641574881ECE0090000488BD948898C24380100004533E44533C033D2488D8C24A0000000E8????????488D05????????";
	inline constexpr const char* cmd_interpreter                  = "rendersystemdx11.dll:>E8????????4183BDC000000000";
	inline constexpr const char* create_move                      = "client.dll:FFFFFFFF488D05*????????48890D????????+28~";
	inline constexpr const char* csgo_input                       = "client.dll:84C0740C488D0D*????????E8????????";
	inline constexpr const char* draw_flash_effect                = "client.dll:>E8????????440F2F2D????????";
	inline constexpr const char* draw_legs                        = "client.dll:48894C2420498BCD>E8????????488B55B0";
	inline constexpr const char* draw_overhead                    = "client.dll:>E8????????84C00F843C090000";
	inline constexpr const char* draw_scene_object                = "scenesystem.dll:488D05*????????488907488B7C2448+8~";
	inline constexpr const char* draw_scene_object_array          = "scenesystem.dll:488BC44889501048894808555356574154415541564157488DA838F9FFFF";
	inline constexpr const char* draw_skybox_array                = "scenesystem.dll:06000000488D05*????????48890133FF+60~";
	inline constexpr const char* engine_client_cmd                = "engine2.dll:488BC448895808488968104889701857415641574881EC700100000F2970D8410FB6E98D42FC4D8BF88BFA4C8BF183F801763EBAFFFFFFFF488D0D????????E8????????4885C0750B";
	inline constexpr const char* entity_list                      = "client.dll:488B0D*????????8BFBC1EB0E";
	inline constexpr const char* filesystem_close                 = "filesystem_stdio.dll:>E8????????FFD34C8BA42498000000";
	inline constexpr const char* find_hud_element                 = "client.dll:>E8????????4885C0488D751C";
	inline constexpr const char* frame_input_ring_base            = "engine2.dll:488D05*????????0F1004C8";
	inline constexpr const char* frame_input_ring_idx             = "engine2.dll:486315*????????83FA0A7D61";
	inline constexpr const char* frame_stage_notify               = "client.dll:48895C241848896C2420574883EC40488BF9";
	inline constexpr const char* game_entity_system               = "client.dll:488B0D*????????EB028BC6";
	inline constexpr const char* game_event_get_controller        = "client.dll:488D05*????????4D8BF8488901+80~";
	inline constexpr const char* game_event_get_float             = "client.dll:>E8????????0F28D8895C2420";
	inline constexpr const char* game_event_get_int               = "client.dll:>E8????????3D00800000";
	inline constexpr const char* game_event_get_pawn              = "client.dll:488D05*????????4D8BF8488901+88~";
	inline constexpr const char* game_event_get_string            = "client.dll:>E8????????85DB0F9FC3";
	inline constexpr const char* game_event_manager               = "client.dll:488B0D*????????498BF0498BD9~";
	inline constexpr const char* game_rules                       = "client.dll:488B0D*????????4C897010";
	inline constexpr const char* game_scene_node_set_mesh_group   = "client.dll:>E8????????8B852C850100";
	inline constexpr const char* game_scene_node_set_skeleton     = "client.dll:>E8????????4084ED7417";
	inline constexpr const char* game_trace_manager               = "client.dll:488B0D*????????488D3452~";
	inline constexpr const char* generate_primitives              = "scenesystem.dll:488D05*????????488907488B7C2448+20~";
	inline constexpr const char* get_aim_punch                    = "client.dll:140000488D542420>E8????????F30F1015????????";
	inline constexpr const char* get_bone_index                   = "client.dll:>E8????????85C00F888A000000";
	inline constexpr const char* get_glow_color                   = "client.dll:>E8????????F30F10BE300E0000";
	inline constexpr const char* get_inaccuracy                   = "client.dll:48895C24105556574881ECB0000000440F29842480000000498BF8488BEA488BD9E8????????488BF0450F57C0";
	inline constexpr const char* get_interp_amount                = "client.dll:>E8????????418B9668030000";
	inline constexpr const char* get_interpolated_shoot_position  = "client.dll:>E8????????8B86F8030000";
	inline constexpr const char* get_net_channel                  = "engine2.dll:4C8B05????????4D85C07410";
	inline constexpr const char* get_scene_param                  = "client.dll:>E8????????F30F1038";
	inline constexpr const char* get_tick_view_angles             = "client.dll:48895C2408574881ECF0000000F30F100A488D8C2410010000418BD8488BFAE8????????F30F104F04";
	inline constexpr const char* get_transforms_for_hitbox_list   = "client.dll:>E8????????84C0410F45EC";
	inline constexpr const char* get_usercmd                      = "client.dll:80000000498B4F10>E8????????4885C07419";
	inline constexpr const char* get_usercmd_base                 = "client.dll:4883EC28>E8????????8B8010590000";
	inline constexpr const char* get_view_angles                  = "client.dll:8B0D????????8BD3>E8????????F20F1000";
	inline constexpr const char* get_world_group_handle           = "client.dll:>E8????????418B5F10";
	inline constexpr const char* get_world_group_id               = "client.dll:>E8????????F3410F10B674FFFFFF";
	inline constexpr const char* global_vars                      = "client.dll:488B05*????????448B4044";
	inline constexpr const char* handle_view_angles               = "client.dll:FFFFFFFF488D05*????????48890D????????+40~";
	inline constexpr const char* history_field_alloc              = "client.dll:>E8????????488BD0488D4E28";
	inline constexpr const char* hud                              = "client.dll:488B05*????????4885C07471";
	inline constexpr const char* hud_death_notice_clear           = "client.dll:85C07509488D4EE0>E8????????4C8D9C24D0000000";
	inline constexpr const char* hud_weapon_selection_update      = "client.dll:498BE35FC3488BCB>E8????????488BCBE8????????";
	inline constexpr const char* init_particle_path_buffer        = "client.dll:>E8????????488D05????????C745808CF0DC51";
	inline constexpr const char* init_particle_path_buffer_alt    = "client.dll:48895C24??574883EC??8B41??488D79";
	inline constexpr const char* is_enemy_on_radar                = "client.dll:>E8????????4C8D6710";
	inline constexpr const char* is_glowing                       = "client.dll:0000488BEA488BF9>E8????????4533F684C0";
	inline constexpr const char* item_system                      = "client.dll:488B1D*????????458B2C06";
	inline constexpr const char* kv3_alloc                        = "tier0.dll:>E8????????4C8BF0EB03";
	inline constexpr const char* kv3_load                         = "tier0.dll:44242848897C2420>E8????????0FB6D88B4C2444";
	inline constexpr const char* level_initialization             = "client.dll:488D05*????????C6411000+B8~";
	inline constexpr const char* level_shutdown                   = "client.dll:4883EC??488B0D????????488D15????????4533C94533C0488B01FF50304885C074??488B0D????????488BD04C8B0141FF50404883C4??";
	inline constexpr const char* light_data_queue                 = "scenesystem.dll:488B05*????????48C1E104+8";
	inline constexpr const char* light_scene_object               = "scenesystem.dll:>E8????????440F285C2460";
	inline constexpr const char* local_player_controller          = "client.dll:48391D*????????7504B001";
	inline constexpr const char* log_internal                     = "tier0.dll:>E8????????448B55B3";
	inline constexpr const char* material_create                  = "materialsystem2.dll:488D05*????????48895C2428+E8~";
	inline constexpr const char* material_manager                 = "client.dll:488B0D*????????80A5E7000000EF";
	inline constexpr const char* net_client                       = "client.dll:488B0D*????????4C8D4520";
	inline constexpr const char* override_view                    = "client.dll:A8000000488D05*????????4C89742420+78~";
	inline constexpr const char* parse_report_hit                 = "client.dll:>E80945F5FF";
	inline constexpr const char* particle_create_effect           = "client.dll:>E8????????837C2440FF";
	inline constexpr const char* particle_destroy_effect          = "client.dll:488D05????????0F29B424B0000000488987D8000000E8????????8B97E000000041B101450FB6C1488BC8>E8????????E8????????";
	inline constexpr const char* particle_manager                 = "client.dll:488B1D*????????44896C2450";
	inline constexpr const char* particle_set_control_point       = "client.dll:>E8????????F2410F104668";
	inline constexpr const char* particle_set_entity_binding      = "client.dll:>E8????????8B742450";
	inline constexpr const char* particle_stop_effect             = "client.dll:C6410800488D05*????????4889014533F6+18~";
	inline constexpr const char* planted_c4                       = "client.dll:4C8B05*????????85D27E25";
	inline constexpr const char* post_network_data_received       = "client.dll:48895C241048894C24085556574154415541564157488DAC24B0FCFFFF4881EC500400004C8BE9488B0D????????488B01FF90B8000000488BC8488B10FF5238498BCD8945848BF0E8????????498BCDE8????????";
	inline constexpr const char* prediction_finish_move           = "client.dll:>E8????????488B8398010000";
	inline constexpr const char* prediction_player                = "client.dll:488BD748893D*????????488BCB";
	inline constexpr const char* prediction_process_movement      = "client.dll:8BC5498BD5488BCB>E8????????488B034C8BC5";
	inline constexpr const char* prediction_reset_pawn            = "client.dll:>E8????????C1EB09F6D3";
	inline constexpr const char* prediction_seed                  = "client.dll:8B3D*????????488B03488BCB";
	inline constexpr const char* prediction_set_pawn              = "client.dll:>E8????????660F6E8DD8000000";
	inline constexpr const char* prediction_set_state             = "client.dll:>E8????????4963DF4585FF";
	inline constexpr const char* prediction_setup_move            = "client.dll:D5488BCD458B4044>E8????????488B034C8BC5";
	inline constexpr const char* prediction_state                 = "client.dll:488B0D*????????33D28B5B38";
	inline constexpr const char* prepare_scene_material           = "materialsystem2.dll:48895C24084889742410574883EC30488B5920";
	inline constexpr const char* process_input_event              = "client.dll:CCCC48895C2408574883EC20C6410800488D05*????????488901488BD9+20~";
	inline constexpr const char* read_frame_input                 = "client.dll:>E8????????4D8BC58BD3";
	inline constexpr const char* remove_entity                    = "client.dll:90200000488D05*????????48890733D2+80~";
	inline constexpr const char* render_crosshair                 = "client.dll:488BC844887C2430>E8????????84C00F849B000000";
	inline constexpr const char* render_decals                    = "client.dll:B001488BD7498BCD>E8????????BAFFFFFFFF";
	inline constexpr const char* render_game_system               = "client.dll:488B0D*????????488B14FA~";
	inline constexpr const char* render_scope                     = "client.dll:488BC453574883EC68488BFA";
	inline constexpr const char* render_smoke                     = "client.dll:5C24284889442420>E8????????488B5C2460";
	inline constexpr const char* render_view                      = "client.dll:4C8BDC49895B1049896B18565741564881ECF0000000410F2973D8498D53084C8BF1410F297BC8488B0D????????450F2943B8488B01FF9008030000C644242801488D15????????4533C9488D8C248000000041B8310100008B0089442420E8????????33D2498BCEE8????????488D8C2480000000";
	inline constexpr const char* resource_system_load             = "resourcesystem.dll:48895C24??48896C24??48897424??574883EC??488B01";
	inline constexpr const char* resource_system_precache         = "resourcesystem.dll:405355574881EC80000000";
	inline constexpr const char* serialize_move_crc               = "client.dll:C7488D55D0488BCE>E8????????488B55E8";
	inline constexpr const char* service_read                     = "filesystem_stdio.dll:00488907488D05*????????488987E0000000~";
	inline constexpr const char* set_info                         = "engine2.dll:40554157488D6C24??4881EC????????4533FF";
	inline constexpr const char* set_player_model                 = "client.dll:488D15????????488BCB>E8????????488BD7488BCB";
	inline constexpr const char* set_shader_param                 = "client.dll:>E8????????0FB64325";
	inline constexpr const char* set_view_angles                  = "client.dll:>E8????????488B8E20120000";
	inline constexpr const char* set_voice_data                   = "client.dll:>E8????????4C39B5C8140000";
	inline constexpr const char* simulation_player                = "client.dll:4C3905*????????410F94C6";
	inline constexpr const char* sort_primitives                  = "scenesystem.dll:>E8????????F041FF86F40B0000";
	inline constexpr const char* play_sound                       = "soundsystem.dll:4C8BDC55415541564157";
	inline constexpr const char* string_copy                      = "client.dll:>E8????????0F104588";
	inline constexpr const char* subtick_move_alloc               = "client.dll:488B54CA088D4101894708EB16488B0F>E8????????488BD0488BCF";
	inline constexpr const char* swap_chain_storage               = "rendersystemdx11.dll:48892D*????????660F7F05????????";
	inline constexpr const char* trace_bullet                     = "client.dll:>E8????????4532ED410F28FD";
	inline constexpr const char* trace_bullet_data_init           = "client.dll:48895C240848896C2410488974241857415641574883EC50F20F1002";
	inline constexpr const char* trace_bullet_free                = "client.dll:>E8????????3BDE744E";
	inline constexpr const char* trace_bullet_update              = "client.dll:>E8????????F3440F106574";
	inline constexpr const char* trace_filter_init                = "client.dll:7D78F3440F58457C>E8????????F30F1005????????";
	inline constexpr const char* trace_filter_set_collision       = "client.dll:000041B800010000>E8????????4C397F38";
	inline constexpr const char* trace_hull                       = "client.dll:>E8????????0F2F754C";
	inline constexpr const char* trace_ray                        = "client.dll:20488D95E0000000>E8????????488B3D????????";
	inline constexpr const char* trace_ray_entity                 = "client.dll:44246848897C2420>E8????????488B3D????????";
	inline constexpr const char* update_fov_sensitivity           = "client.dll:48895C240848896C24104889742418574883EC20488BB918120000";
	inline constexpr const char* utl_vector_push                  = "client.dll:>E8????????4C8BD0458B4A10";
	inline constexpr const char* view_matrix                      = "client.dll:488D0D*????????48C1E006";
	inline constexpr const char* viewmodel_update_mesh            = "client.dll:>E8????????498D8D??????????????488D5424";
	inline constexpr const char* weapon_calculate_spread          = "client.dll:28F3440F11442420>E8????????488D85B0000000";
	inline constexpr const char* weapon_get_entity_index          = "client.dll:>E8????????448B4500";
	inline constexpr const char* weapon_get_model_path            = "client.dll:48895C2410564883EC20488B1D????????";
	inline constexpr const char* weapon_get_recoil_offset         = "client.dll:>E8????????488D44243C";
	inline constexpr const char* weapon_get_viewmodel             = "client.dll:40534883EC20488BD9E8????????4883BB8803000000";
	inline constexpr const char* weapon_recoil_data               = "client.dll:488D3D*????????498D4308";
	inline constexpr const char* weapon_set_mesh_group_mask       = "client.dll:>E8????????E9????????83B8A80A0000000F8FAF00000083B8C00A0000000F8FA20000000F57C048895DA7488D15????????660F7F45C7";
	inline constexpr const char* weapon_update_accuracy           = "client.dll:405741564883EC68488BF9E8????????4C8BF04885C0";
	inline constexpr const char* weapon_update_composite_material = "client.dll:00400FB6D7488BCB>E8????????488D4C2420";
	inline constexpr const char* weapon_update_mesh               = "client.dll:>E8????????498D8C2408060000";
	inline constexpr const char* weapon_update_skin               = "client.dll:48895C241048896C2418488974242057415641574883EC40488BEA488BF1488D542460E8????????488B4610";

} // namespace patterns
