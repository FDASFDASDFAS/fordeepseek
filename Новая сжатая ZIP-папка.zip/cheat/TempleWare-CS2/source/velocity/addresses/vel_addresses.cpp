#include "vel_addresses.hpp"

#include <format>
#include <iostream>
#include <string>
#include <utility>

namespace {

	// std::cout rather than Logger::Log -- Logger routes to the game's developer
	// console via I::ConColorMsg, while the rest of this project's diagnostics go
	// to the allocated stdout console.
	void log_addr( const char* label, std::uintptr_t value )
	{
		std::cout << std::format( "[addresses] {:<26} {:#x}{}", label, value,
			value ? "" : "   <-- UNRESOLVED" ) << std::endl;
	}

	// Reports every miss rather than bailing on the first one -- when a game
	// update moves things, the whole list of what broke is worth more than the
	// first name in it.
	bool report_missing( std::initializer_list<std::pair<const char*, std::uintptr_t>> entries )
	{
		auto ok = true;

		for ( const auto& [ name, value ] : entries )
		{
			log_addr( name, value );

			if ( !value )
			{
				ok = false;
			}
		}

		return ok;
	}

} // namespace

namespace addresses::modules {

	bool initialize( )
	{
		client             = MODULE_BASE( "client.dll" );
		engine2            = MODULE_BASE( "engine2.dll" );
		server             = MODULE_BASE( "server.dll" );
		scene_system       = MODULE_BASE( "scenesystem.dll" );
		material_system2   = MODULE_BASE( "materialsystem2.dll" );
		render_system_dx11 = MODULE_BASE( "rendersystemdx11.dll" );
		schema_system      = MODULE_BASE( "schemasystem.dll" );
		input_system       = MODULE_BASE( "inputsystem.dll" );
		sound_system       = MODULE_BASE( "soundsystem.dll" );
		tier0              = MODULE_BASE( "tier0.dll" );
		particles          = MODULE_BASE( "particles.dll" );
		resource_system    = MODULE_BASE( "resourcesystem.dll" );
		mesh_system        = MODULE_BASE( "meshsystem.dll" );
		vphysics2          = MODULE_BASE( "vphysics2.dll" );

		return report_missing( {
			{ "client",             client },
			{ "engine2",            engine2 },
			{ "server",             server },
			{ "scene_system",       scene_system },
			{ "material_system2",   material_system2 },
			{ "render_system_dx11", render_system_dx11 },
			{ "schema_system",      schema_system },
			{ "input_system",       input_system },
			{ "sound_system",       sound_system },
			{ "tier0",              tier0 },
			{ "particles",          particles },
			{ "resource_system",    resource_system },
			{ "mesh_system",        mesh_system },
			{ "vphysics2",          vphysics2 },
		} );
	}

} // namespace addresses::modules

namespace addresses::globals {

	bool initialize( )
	{
		source2client            = INTERFACE_( "Source2Client002" );
		source2engine_to_client  = INTERFACE_( "Source2EngineToClient001" );
		schema_system            = INTERFACE_( "SchemaSystem_001" );
		input_system             = INTERFACE_( "InputSystemVersion001" );
		source2client_prediction = INTERFACE_( "Source2ClientPrediction001" );
		network_client_service   = INTERFACE_( "NetworkClientService_001" );
		cvar                     = reinterpret_cast< interfaces::c_engine_cvar* >( INTERFACE_( "VEngineCvar007" ) );

		csgo_input              = PATTERN( patterns::csgo_input );
		entity_list             = PATTERN( patterns::entity_list );
		local_player_controller = PATTERN( patterns::local_player_controller );
		global_vars             = PATTERN( patterns::global_vars );
		view_matrix             = PATTERN( patterns::view_matrix );
		game_rules              = PATTERN( patterns::game_rules );
		game_trace_manager      = PATTERN( patterns::game_trace_manager );
		game_entity_system      = PATTERN( patterns::game_entity_system );
		weapon_recoil_data      = PATTERN( patterns::weapon_recoil_data );
		prediction_seed         = PATTERN( patterns::prediction_seed );
		simulation_player       = PATTERN( patterns::simulation_player );
		prediction_player       = PATTERN( patterns::prediction_player );
		prediction_state        = PATTERN( patterns::prediction_state );
		item_system             = PATTERN( patterns::item_system );
		net_client              = PATTERN( patterns::net_client );
		frame_input_ring_idx    = PATTERN( patterns::frame_input_ring_idx );
		frame_input_ring_base   = PATTERN( patterns::frame_input_ring_base );

		if ( const auto ptr = MODULE_EXPORT( "tier0.dll:g_pMemAlloc" ) )
		{
			mem_alloc = *reinterpret_cast< std::uintptr_t* >( ptr );
		}

		return report_missing( {
			{ "source2client",            source2client },
			{ "source2engine_to_client",  source2engine_to_client },
			{ "schema_system",            schema_system },
			{ "input_system",             input_system },
			{ "source2client_prediction", source2client_prediction },
			{ "network_client_service",   network_client_service },
			{ "cvar",                     reinterpret_cast< std::uintptr_t >( cvar ) },
			{ "csgo_input",               csgo_input },
			{ "entity_list",              entity_list },
			{ "local_player_controller",  local_player_controller },
			{ "global_vars",              global_vars },
			{ "view_matrix",              view_matrix },
			{ "game_rules",               game_rules },
			{ "game_trace_manager",       game_trace_manager },
			{ "game_entity_system",       game_entity_system },
			{ "weapon_recoil_data",       weapon_recoil_data },
			{ "prediction_seed",          prediction_seed },
			{ "simulation_player",        simulation_player },
			{ "prediction_player",        prediction_player },
			{ "prediction_state",         prediction_state },
			{ "item_system",              item_system },
			{ "net_client",               net_client },
			{ "frame_input_ring_idx",     frame_input_ring_idx },
			{ "frame_input_ring_base",    frame_input_ring_base },
			{ "mem_alloc",                mem_alloc },
		} );
	}

} // namespace addresses::globals
