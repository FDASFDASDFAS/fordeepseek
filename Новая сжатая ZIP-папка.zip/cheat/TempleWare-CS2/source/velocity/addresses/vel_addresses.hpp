#pragma once

// Stand-in for velocity's protection/game_addresses.hpp.
//
// Upstream had two modes: a DEV mode that resolved signatures at runtime, and a
// release mode that read pre-resolved, XOR-encoded addresses out of an "_addr"
// section their packer filled in. Only the DEV path is reproducible outside
// their build pipeline, so that is the only path here -- the macros below are
// the DEV definitions with the packer indirection removed.
//
// Each macro caches its result in a function-local static, so a resolve happens
// once per call site no matter how hot the caller is.

#include "../memory/memory.hpp"
#include "../fnv1a.hpp"
#include "../interfaces/vel_interfaces.hpp"
#include "../../templeware/utils/convar.h"
#include "patterns.hpp"

#include <cstdint>

#define PATTERN( pattern_str ) \
	( []( ) -> std::uintptr_t { \
		static const auto val = ::memory::resolve_pattern( pattern_str ); \
		return val; \
	}( ) )

#define INTERFACE_( name_str ) \
	( []( ) -> std::uintptr_t { \
		static const auto val = ::memory::get_module_interface( name_str ); \
		return val; \
	}( ) )

#define MODULE_BASE( name_str ) \
	( []( ) -> std::uintptr_t { \
		static const auto val = ::memory::get_module_base( name_str ); \
		return val; \
	}( ) )

#define MODULE_EXPORT( name_str ) \
	( []( ) -> std::uintptr_t { \
		static const auto val = ::memory::get_module_export( name_str ); \
		return val; \
	}( ) )

// Caches the c_convar* per call site. Yields nullptr if the cvar interface
// never resolved or the name is unknown -- callers must null-check, since a
// missing convar is a live possibility once signatures go stale.
#define CONVAR( name_str ) \
	( []( ) -> c_convar* { \
		static c_convar* const interface_val = ::addresses::globals::cvar \
			? ::addresses::globals::cvar->find( fnv1a::hash( name_str, sizeof( name_str ) - 1 ) ) \
			: nullptr; \
		if ( interface_val ) \
			return interface_val; \
		static c_convar* const registered_val = reinterpret_cast<c_convar*>( \
			::tw::convars::findRegisteredData( name_str ) ); \
		return registered_val; \
	}( ) )

namespace addresses {

	namespace modules {

		bool initialize( );

		inline std::uintptr_t client{};
		inline std::uintptr_t engine2{};
		inline std::uintptr_t server{};
		inline std::uintptr_t scene_system{};
		inline std::uintptr_t material_system2{};
		inline std::uintptr_t render_system_dx11{};
		inline std::uintptr_t schema_system{};
		inline std::uintptr_t input_system{};
		inline std::uintptr_t sound_system{};
		inline std::uintptr_t tier0{};
		inline std::uintptr_t particles{};
		inline std::uintptr_t resource_system{};
		inline std::uintptr_t mesh_system{};
		inline std::uintptr_t vphysics2{};

	} // namespace modules

	namespace globals {

		// Resolves only what the combat port reads. The upstream initialize()
		// also filled in rendering, particle, material and HUD globals; those
		// come back with their respective feature areas.
		bool initialize( );

		// interfaces
		inline std::uintptr_t source2client{};
		inline std::uintptr_t source2engine_to_client{};
		inline std::uintptr_t schema_system{};
		inline std::uintptr_t input_system{};
		inline std::uintptr_t source2client_prediction{};
		inline std::uintptr_t network_client_service{};
		inline interfaces::c_engine_cvar* cvar{};

		// globals
		inline std::uintptr_t csgo_input{};
		inline std::uintptr_t entity_list{};
		inline std::uintptr_t local_player_controller{};
		inline std::uintptr_t global_vars{};
		inline std::uintptr_t view_matrix{};
		inline std::uintptr_t game_rules{};
		inline std::uintptr_t game_trace_manager{};
		inline std::uintptr_t game_entity_system{};
		inline std::uintptr_t weapon_recoil_data{};
		inline std::uintptr_t prediction_seed{};
		inline std::uintptr_t simulation_player{};
		inline std::uintptr_t prediction_player{};
		inline std::uintptr_t prediction_state{};
		inline std::uintptr_t item_system{};
		inline std::uintptr_t net_client{};
		inline std::uintptr_t frame_input_ring_idx{};
		inline std::uintptr_t frame_input_ring_base{};
		inline std::uintptr_t mem_alloc{};

	} // namespace globals

} // namespace addresses
