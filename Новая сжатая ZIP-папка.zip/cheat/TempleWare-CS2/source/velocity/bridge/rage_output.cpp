#include "rage_output.h"

#include <iostream>
#include <mutex>
#include <string>
#include <unordered_set>

namespace velocity {

	namespace {

		// CreateMove and the move-CRC boundary are both engine callbacks and are
		// not guaranteed to be the same thread, so the handoff is locked rather
		// than assumed single-threaded.
		std::mutex g_mutex{};
		RageDecision g_pending{};

	} // namespace

	void publishRageDecision( const RageDecision& decision ) noexcept
	{
		std::scoped_lock lock( g_mutex );
		g_pending = decision;
	}

	RageDecision consumeRageDecision() noexcept
	{
		std::scoped_lock lock( g_mutex );

		const auto decision = g_pending;
		g_pending = {};

		return decision;
	}

	void rageDiag( const char* what, int value ) noexcept
	{
		if ( !g_rageDiagnostics )
		{
			return;
		}

		// One line per distinct (label, value) pair. The scan runs every tick, so
		// printing unconditionally would drown the console -- but a value that
		// changes is exactly what we want to see.
		static std::mutex mtx{};
		static std::unordered_set<std::string> seen{};

		std::scoped_lock lock( mtx );

		auto key = std::string( what ) + "=" + std::to_string( value );
		if ( seen.emplace( key ).second )
		{
			std::cout << "[rage] " << key << std::endl;
		}
	}

	void rageDiagCandidates( const CandidateReject& r ) noexcept
	{
		if ( !g_rageDiagnostics )
		{
			return;
		}

		static std::mutex mtx{};
		static std::unordered_set<std::string> seen{};

		std::scoped_lock lock( mtx );

		auto key = "players=" + std::to_string( r.players )
			+ " self=" + std::to_string( r.self )
			+ " notAlive=" + std::to_string( r.notAlive )
			+ " noPawn=" + std::to_string( r.noPawn )
			+ " wrongTeam=" + std::to_string( r.wrongTeam )
			+ " noHealth=" + std::to_string( r.deadOrNoHealth )
			+ " immune=" + std::to_string( r.immune )
			+ " noRecords=" + std::to_string( r.noRecords )
			+ " accepted=" + std::to_string( r.accepted );

		if ( seen.emplace( key ).second )
		{
			std::cout << "[rage] filter " << key << std::endl;
		}
	}

	void rageDiagScan( const ScanReject& r ) noexcept
	{
		if ( !g_rageDiagnostics )
		{
			return;
		}

		static std::mutex mtx{};
		static std::unordered_set<std::string> seen{};
		static std::size_t printed{};

		std::scoped_lock lock( mtx );

		auto key = "hitboxes=" + std::to_string( r.hitboxes )
			+ " configured=" + std::to_string( r.configured )
			+ " usable=" + std::to_string( r.usableHitboxes )
			+ " points=" + std::to_string( r.points )
			+ " fov=" + std::to_string( r.fov )
			+ " roughHC=" + std::to_string( r.roughHitchance )
			+ " penetration=" + std::to_string( r.penetration )
			+ " noContacts=" + std::to_string( r.noContacts )
			+ " noTarget=" + std::to_string( r.noTargetContact )
			+ " badWeapon=" + std::to_string( r.invalidWeapon )
			+ " minDamage=" + std::to_string( r.minDamage )
			+ " headGroup=" + std::to_string( r.headGroup )
			+ " hits=" + std::to_string( r.hits );

		if ( seen.emplace( key ).second && printed < 8 )
		{
			++printed;
			std::cout << "[rage] scan " << key << std::endl;
		}
	}

	void rageDiagTarget( float damage, int health, float hitchance ) noexcept
	{
		if ( !g_rageDiagnostics )
		{
			return;
		}

		// Bucketed so small frame-to-frame jitter does not produce a new line
		// every tick, while a real change still shows.
		static std::mutex mtx{};
		static std::unordered_set<std::string> seen{};

		std::scoped_lock lock( mtx );

		auto key = "dmg=" + std::to_string( static_cast< int >( damage ) )
			+ " hp=" + std::to_string( health )
			+ " hc=" + std::to_string( static_cast< int >( hitchance * 100.0f ) ) + "%";

		if ( seen.emplace( key ).second )
		{
			std::cout << "[rage] target " << key << std::endl;
		}
	}

} // namespace velocity
