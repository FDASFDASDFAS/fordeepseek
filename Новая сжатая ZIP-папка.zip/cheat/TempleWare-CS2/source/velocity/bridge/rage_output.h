#pragma once

#include <cstdint>

namespace velocity {

	// The ragebot's decision for a tick, captured instead of written.
	//
	// velocity's fire_gun writes its aim angle and attack button straight into
	// the usercmd through its own hand-rolled protobuf model, then recomputes the
	// move CRC by calling into the engine. That path crashes CS2 on build 14172
	// and six bisection cycles did not isolate a single cause -- see
	// bridge/combat_bridge.h.
	//
	// TempleWare already has a validated live write boundary: hkMoveCrcBoundary
	// binds a BoundCommandRuntime and resolves CommandIntents there, gated on a
	// probe that proves the boundary is stable. Writes land BEFORE the game
	// computes the move CRC, so no manual CRC is needed at all -- which removes
	// the single most dangerous call in the velocity path.
	//
	// So the ragebot publishes here, and the boundary hook turns it into an
	// intent. The aiming logic is unchanged; only the delivery differs.
	struct RageDecision final
	{
		bool valid{};

		float pitch{};
		float yaw{};
		float roll{};

		bool wantsAttack{};
		bool wantsSecondary{};

		// Command sequence the decision was made for. The boundary hook drops
		// anything stale rather than aiming with a previous tick's answer.
		std::uint64_t sequence{};
	};

	// Set by rage::fire_gun while g_publishDecisions is on.
	void publishRageDecision( const RageDecision& decision ) noexcept;

	// Returns the pending decision and clears it, so one decision is applied at
	// most once.
	[[nodiscard]] RageDecision consumeRageDecision() noexcept;

	// When true, fire_gun records its decision and SKIPS its own usercmd writes.
	// When false it behaves exactly as upstream -- kept so the original path can
	// be compared once it is safe to run.
	inline bool g_publishDecisions{ true };

	// Throttled diagnostics for the decision path.
	//
	// "Ran without crashing but published nothing" has several very different
	// causes -- no candidates, no scan hits, every hit rejected, or a target
	// found but below the damage/hit-chance thresholds. These distinguish them
	// without flooding a per-tick log.
	void rageDiag( const char* what, int value ) noexcept;
	void rageDiagTarget( float damage, int health, float hitchance ) noexcept;

	// Why gather_candidates rejected each cached player. 13 controllers are
	// cached and none survive the filters; this says which filter.
	struct CandidateReject final
	{
		int players{};
		int self{};
		int notAlive{};
		int noPawn{};
		int wrongTeam{};
		int deadOrNoHealth{};
		int immune{};
		int noRecords{};
		int accepted{};
	};

	void rageDiagCandidates( const CandidateReject& r ) noexcept;

	struct ScanReject final
	{
		int hitboxes{};
		int configured{};
		int usableHitboxes{};
		int points{};
		int fov{};
		int roughHitchance{};
		int penetration{};
		int noContacts{};
		int noTargetContact{};
		int invalidWeapon{};
		int minDamage{};
		int headGroup{};
		int hits{};
	};

	void rageDiagScan( const ScanReject& r ) noexcept;

	inline bool g_rageDiagnostics{ true };

} // namespace velocity
