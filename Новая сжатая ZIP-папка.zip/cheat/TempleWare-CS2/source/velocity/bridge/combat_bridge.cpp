#include "combat_bridge.h"

#include "../features/combat/combat.hpp"
#include "rage_output.h"
#include "../../templeware/config/configmanager.h"

#include <cmath>
#include <format>
#include <iostream>
#include <string>
#include <unordered_set>

namespace velocity {

	namespace {

		// Reports a stage reaching steady state once, so the log shows how far
		// the pipeline got without printing per tick.
		void note_once( const char* what )
		{
			static std::unordered_set<std::string> seen{};

			if ( seen.emplace( what ).second )
			{
				std::cout << "[combat] " << what << std::endl;
			}
		}

		// Refreshing the whole entity cache every tick is wasteful; velocity keeps
		// it current through add/remove hooks instead. Those are not wired yet, so
		// this rebuilds periodically -- correct, just not cheap. Replace with the
		// add_entity/remove_entity hooks when they land.
		void refresh_entities_periodically( )
		{
			static int counter{};

			if ( ( counter++ % 64 ) == 0 || systems::g_entities.is_empty( ) )
			{
				systems::g_entities.force_update( );
			}
		}

		void sync_combat_settings( const tw::config::RageSettings& source )
		{
			auto& target = ::settings::g_combat;
			target.m_ragebot.enabled.value = source.enabled;
			target.m_lagcomp.max_backtrack_ticks.value = source.maxBacktrackTicks;
			target.m_lagcomp.extrapolation.value = source.extrapolation;
			target.m_lagcomp.max_extrapolate_ticks.value = source.maxExtrapolateTicks;

			for ( std::size_t i = 0; i < source.weaponGroups.size( ); ++i )
			{
				const auto& from = source.weaponGroups[ i ];
				auto& to = target.m_ragebot.groups[ i ];
				to.body_aim.value = from.bodyAim;
				to.force_shot_air.value = from.forceShotAir;
				to.force_shot.value = from.forceShot;
				to.max_fov.value = from.maxFov;
				to.hitchance.value = from.hitchance;
				to.min_damage.value = from.minDamage;
				to.min_damage_override.value = from.minDamageOverride;
				to.min_damage_override_value.value = from.minDamageOverrideValue;
				to.hitchance_override.value = from.hitchanceOverride;
				to.hitchance_override_value.value = from.hitchanceOverrideValue;
				to.pointscale.value = from.pointScale;
				to.dynamic_pointscale.value = from.dynamicPointScale;

				for ( std::size_t hitbox = 0; hitbox < to.hitboxes.values.size( ); ++hitbox )
					to.hitboxes.values[ hitbox ] = ( from.hitboxes & ( 1u << hitbox ) ) != 0;
			}
		}

	} // namespace

	void onFrameStage( int stage )
	{
		const auto settings = internal_config::ConfigManager::Snapshot( );
		if ( !g_updateCombat || !settings || !settings->rage.enabled )
		{
			return;
		}
		sync_combat_settings( settings->rage );

		// Upstream samples at stage 6, after the frame's network data has been
		// applied -- so the recorded origins and bones match what the server
		// most recently sent. Sampling from CreateMove instead would record
		// mid-tick state and defeat the point of backtracking.
		if ( stage != 6 )
		{
			return;
		}

		const auto local = systems::g_local.get( );
		if ( !local.is_valid( ) )
		{
			return;
		}

		features::combat::g_shared.lc( ).run( );

		note_once( "lagcomp sampling at frame stage 6" );
	}

	void onCreateMove( )
	{
		const auto settings = internal_config::ConfigManager::Snapshot( );
		if ( !g_updateSystems || !settings || !settings->rage.enabled )
		{
			consumeRageDecision( );
			return;
		}
		sync_combat_settings( settings->rage );

		// Fine-grained markers: each prints once, so a crash is bracketed by the
		// last marker seen. Coarse staging told us only "somewhere before stage
		// 1", which spans the entity walk, the local snapshot and the convar
		// reads -- three very different suspects.
		note_once( "1a entered bridge" );

		refresh_entities_periodically( );
		note_once( "1b entity cache rebuilt" );

		systems::g_local.update( );
		note_once( "1c local snapshot updated" );

		const auto local = systems::g_local.get( );
		if ( !local.is_alive || !local.pawn || !local.controller )
		{
			return;
		}

		note_once( "1d local alive + valid" );

		const auto movement_services = memory::safe_read<std::uintptr_t>(
			local.pawn + SCHEMA( "C_BasePlayerPawn", "m_pMovementServices" ) );

		if ( !movement_services || !*movement_services )
		{
			return;
		}

		// velocity gates on this: before the first command is processed the
		// usercmd ring is not yet meaningful.
		const auto last_cmd_processed = memory::safe_read<std::uint32_t>(
			*movement_services + SCHEMA( "CPlayer_MovementServices", "m_nLastCommandNumberProcessed" ) );

		if ( !last_cmd_processed || !*last_cmd_processed )
		{
			return;
		}

		note_once( "1e movement services + last cmd OK" );

		systems::g_input.update( );
		note_once( "1f input.update returned" );

		auto* const cmd = systems::g_input.get( );
		if ( !cmd || !cmd->csgo_user_cmd.has_base( ) )
		{
			return;
		}

		note_once( "stage 1 OK: usercmd acquired" );

		if ( !g_updateCombat )
		{
			return;
		}

		note_once( "2a entering combat stage" );

		systems::g_prediction.capture_prestate( local.pawn, *movement_services );
		note_once( "2b prestate captured" );

		// Weapon context, then the lag-compensation ring -- which walks every
		// player's bone cache. This is the first time the hitbox/bone work runs
		// from the shipping path rather than the RE probe.
		features::combat::g_shared.update( );

		note_once( "stage 2 OK: combat context + lagcomp" );

		// g_applyCommand is velocity's own write path and stays OFF -- it crashes
		// on this build (see combat_bridge.h). With g_publishDecisions on, the
		// ragebot instead publishes its angle and fire decision, and the move-CRC
		// boundary hook turns that into a CommandIntent. So on_create_move below
		// runs purely as a decision-maker: it scans, picks a target, and records
		// the answer without touching the command.
		if ( g_applyCommand )
		{
			systems::g_input.desubtick( cmd );
			note_once( "3a desubtick OK" );
		}

		if ( g_ragebot )
		{
			note_once( "3b entering ragebot" );
			features::combat::g_rage.on_create_move( cmd );
			note_once( "3c ragebot returned" );
		}

		if ( g_applyCommand )
		{
			systems::g_input.apply( );
			note_once( "stage 3 OK: command applied" );
		}
	}

	bool localAimPunch( void* localPawn, float& pitch, float& yaw )
	{
		if ( localPawn == nullptr )
		{
			return false;
		}

		const auto punch = features::combat::g_shared.get_aim_punch(
			reinterpret_cast< std::uintptr_t >( localPawn ) );

		// An unresolved pattern or a guarded call that faulted leaves the output
		// zeroed, which is indistinguishable from "no punch" and harmless. A
		// non-finite value is not: it would poison the aim angle, so reject it.
		if ( !std::isfinite( punch.x ) || !std::isfinite( punch.y ) )
		{
			return false;
		}

		pitch = punch.x;
		yaw   = punch.y;
		return true;
	}

} // namespace velocity
