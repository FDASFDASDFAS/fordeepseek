#pragma once

namespace velocity {

	// Staged rollout. Each flag enables one more layer, so the first crash
	// localises to a known stage instead of "somewhere in 7000 lines".
	//
	// None of this has ever executed against the game. Turn them on in order,
	// testing each: systems -> combat -> ragebot.

	// Entity cache, local snapshot, usercmd fetch. Read-mostly: it calls
	// get_usercmd / get_usercmd_base (both live) and reads player state. The
	// safest stage.
	inline bool g_updateSystems{ true };

	// combat::shared::update() -- weapon context, and the lag-compensation ring,
	// which walks every player's bone cache each tick. This is what exercises the
	// hitbox and bone-mapping work end to end. Heavier, and genuinely read-only:
	// it touches no outgoing command state.
	inline bool g_updateCombat{ true };

	// rage::on_create_move() -- target scanning, hitchance, and writing the aim
	// angle / attack button into the command. Reads a lot; the writes it makes
	// are confined to the command struct.
	//
	// Enabling this WITHOUT g_applyCommand is deliberately supported: the aimbot
	// runs and its decisions are visible in the log, but the protobuf mutation
	// path stays out of the picture. That separation matters because stage 2's
	// crash was in the mutation path, not in the combat logic.
	inline bool g_ragebot{ true };

	// desubtick() + input::apply() -- clearing the command's subtick moves, then
	// writing button state back through velocity's hand-rolled protobuf layout
	// and recomputing the move CRC.
	//
	// This is the suspect for the stage-2 crash. velocity reimplements the
	// protobuf memory layout by hand (proto::), so if CS2's usercmd message
	// changed shape, the mutable_* accessors write to the wrong offsets. The
	// READ side is known good -- stage 1 parsed the command and has_base()
	// succeeded -- but reading and mutating are different risks.
	// LEAVE OFF. Six bisection cycles narrowed the crash within apply() but never
	// eliminated it: with the subtick fix, the move CRC and the button writes all
	// gated or guarded, the game still crashed with only desubtick() and a
	// has-bit write remaining.
	//
	// The conclusion is that the approach is wrong rather than any single call:
	// this path mutates the game's usercmd protobuf through velocity's
	// hand-rolled model of its memory layout, plus three engine calls
	// (subtick_move_alloc, string_copy, serialize_move_crc) whose signatures were
	// never verified against this build. Null guards make a fault survivable;
	// they cannot make a wrong layout right.
	//
	// The route forward is to publish the ragebot's chosen angle through
	// TempleWare's own tw::commands pipeline -- which is proven working on this
	// build, since the triggerbot already uses it -- instead of velocity's
	// protobuf writes.
	inline bool g_applyCommand{ false };

	// Called from the CreateMove hook, after the original has run.
	// Does nothing unless at least g_updateSystems is set.
	void onCreateMove();

	// Called from FrameStageNotify. Samples the lag-compensation ring.
	//
	// This is NOT optional and NOT part of CreateMove: upstream runs it at
	// frame stage 6, and without it the record ring stays empty --
	// get_valid_records returns nothing, extrapolate has no history to work
	// from, and every candidate is discarded before the aimbot ever scans.
	// That is exactly what "13 players cached, 0 candidates" was.
	void onFrameStage( int stage );

	// Current aim punch for the local pawn, in view-angle units, as the game
	// itself computes it. There is no networked punch angle to read on this
	// build -- CS2 derives it from CCSPlayer_AimPunchServices -- so this goes
	// through the same guarded engine call the ragebot uses, and returns
	// false if the call is unavailable or hands back a non-finite value.
	//
	// Declared here so the legit aim can subtract punch without pulling the
	// whole velocity combat header into the hook translation unit.
	bool localAimPunch( void* localPawn, float& pitch, float& yaw );

} // namespace velocity
