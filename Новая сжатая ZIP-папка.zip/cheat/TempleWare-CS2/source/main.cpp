#include "debug/debug.h"

#include "includes.h"
#include "cs2/entity/C_EntitySystem/entity.h"
#include "templeware/templeware.h"
#include "templeware/renderer/icons.h"
#include "templeware/features/events/game_events.h"
#include "templeware/runtime/runtime.h"
#include "templeware/config/configmanager.h"
#include "templeware/renderer/imgui_backend_commands.h"
#include "templeware/features/model_preview/model_preview.h"

#include "../external/kiero/minhook/include/MinHook.h"
#include <CommCtrl.h>
#include <atomic>
#include <chrono>
#include <cstdint>
#include <cstring>
#include <mutex>
#include <vector>

#pragma comment(lib, "Comctl32.lib")

TempleWare templeWare;

Present oPresent;
using ResizeBuffers = HRESULT(__stdcall*)(IDXGISwapChain*, UINT, UINT, UINT, DXGI_FORMAT, UINT);
ResizeBuffers oResizeBuffers;
HWND window = NULL;
ID3D11Device* pDevice = NULL;
ID3D11DeviceContext* pContext = NULL;
ID3D11RenderTargetView* mainRenderTargetView = NULL;
std::timed_mutex rendererMutex;
std::mutex windowMessageMutex;
FILE* consoleOutput = nullptr;
FILE* consoleError = nullptr;
bool consoleAllocated = false;
UINT subclassControlMessage = 0;
DWORD windowThreadId = 0;
std::atomic_bool subclassInstalled{ false };
IDXGISwapChain* activeSwapChain = nullptr;
tw::renderer::BackendGeneration backendGeneration{};

struct WindowMessage
{
    UINT message;
    WPARAM wParam;
    LPARAM lParam;
};

std::vector<WindowMessage> windowMessages;

namespace
{
    constexpr UINT_PTR windowSubclassId = 0x544D504C;
    constexpr WPARAM installSubclass = 1;
    constexpr WPARAM removeSubclass = 2;
    HHOOK windowThreadHook = nullptr;

    template <typename T>
    void ReleaseCom(T*& object)
    {
        if (object != nullptr)
            object->Release();
        object = nullptr;
    }

    bool IsInputMessage(UINT message)
    {
        switch (message)
        {
        case WM_LBUTTONDOWN:
        case WM_LBUTTONDBLCLK:
        case WM_RBUTTONDOWN:
        case WM_RBUTTONDBLCLK:
        case WM_MBUTTONDOWN:
        case WM_MBUTTONDBLCLK:
        case WM_XBUTTONDOWN:
        case WM_XBUTTONDBLCLK:
        case WM_LBUTTONUP:
        case WM_RBUTTONUP:
        case WM_MBUTTONUP:
        case WM_XBUTTONUP:
        case WM_MOUSEWHEEL:
        case WM_MOUSEHWHEEL:
        case WM_KEYDOWN:
        case WM_SYSKEYDOWN:
        case WM_KEYUP:
        case WM_SYSKEYUP:
        case WM_CHAR:
            return true;
        default:
            return false;
        }
    }

    LRESULT CALLBACK WindowSubclassProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam,
        UINT_PTR subclassId, DWORD_PTR referenceData)
    {
        Runtime::CallbackGuard callback;
        (void)referenceData;

        if (message == subclassControlMessage && wParam == removeSubclass)
        {
            const BOOL removed = RemoveWindowSubclass(hWnd, WindowSubclassProc, subclassId);
            if (removed)
                subclassInstalled.store(false, std::memory_order_release);
            return DefSubclassProc(hWnd, message, wParam, lParam);
        }

        if (!Runtime::IsShuttingDown() && IsInputMessage(message))
        {
            std::scoped_lock lock(windowMessageMutex);
            if (windowMessages.size() < 2048)
                windowMessages.push_back({ message, wParam, lParam });
        }

        return DefSubclassProc(hWnd, message, wParam, lParam);
    }

    LRESULT CALLBACK WindowThreadHook(int code, WPARAM wParam, LPARAM lParam)
    {
        Runtime::CallbackGuard callback;
        if (code >= 0)
        {
            const auto* message = reinterpret_cast<const CWPSTRUCT*>(lParam);
            if (message != nullptr && message->hwnd == window && message->message == subclassControlMessage
                && message->wParam == installSubclass)
            {
                const BOOL installed = SetWindowSubclass(window, WindowSubclassProc, windowSubclassId, 0);
                subclassInstalled.store(installed != FALSE, std::memory_order_release);
            }
        }

        return CallNextHookEx(windowThreadHook, code, wParam, lParam);
    }

    bool InstallWindowSubclass()
    {
        if (window == nullptr || subclassControlMessage == 0)
            return false;

        windowThreadId = GetWindowThreadProcessId(window, nullptr);
        if (windowThreadId == 0)
            return false;

        if (windowThreadId == GetCurrentThreadId())
        {
            const BOOL installed = SetWindowSubclass(window, WindowSubclassProc, windowSubclassId, 0);
            subclassInstalled.store(installed != FALSE, std::memory_order_release);
            return installed != FALSE;
        }

        windowThreadHook = SetWindowsHookExW(WH_CALLWNDPROC, WindowThreadHook, nullptr, windowThreadId);
        if (windowThreadHook == nullptr)
            return false;

        DWORD_PTR result = 0;
        const LRESULT sent = SendMessageTimeoutW(window, subclassControlMessage, installSubclass, 0,
            SMTO_ABORTIFHUNG | SMTO_BLOCK, 2000, &result);
        UnhookWindowsHookEx(windowThreadHook);
        windowThreadHook = nullptr;

        return sent != 0 && subclassInstalled.load(std::memory_order_acquire);
    }

    bool RemoveWindowSubclassFromOwnerThread()
    {
        if (!subclassInstalled.load(std::memory_order_acquire))
            return true;

        if (window == nullptr || !IsWindow(window)
            || GetWindowThreadProcessId(window, nullptr) != windowThreadId)
        {
            subclassInstalled.store(false, std::memory_order_release);
            return true;
        }

        DWORD_PTR result = 0;
        const LRESULT sent = SendMessageTimeoutW(window, subclassControlMessage, removeSubclass, 0,
            SMTO_ABORTIFHUNG | SMTO_BLOCK, 2000, &result);
        if (sent == 0)
        {
            Runtime::Fail(Runtime::LifecycleError::WindowThreadUnresponsive);
            return false;
        }

        if (subclassInstalled.load(std::memory_order_acquire))
        {
            Runtime::Fail(Runtime::LifecycleError::WindowSubclassRemoveFailed);
            return false;
        }

        return true;
    }

    void ProcessWindowMessages()
    {
        std::vector<WindowMessage> messages;
        {
            std::scoped_lock lock(windowMessageMutex);
            messages.swap(windowMessages);
        }

        ImGuiIO& io = ImGui::GetIO();
        for (const WindowMessage& message : messages)
        {
            switch (message.message)
            {
            case WM_LBUTTONDOWN:
            case WM_LBUTTONDBLCLK: io.MouseDown[0] = true; break;
            case WM_RBUTTONDOWN:
            case WM_RBUTTONDBLCLK: io.MouseDown[1] = true; break;
            case WM_MBUTTONDOWN:
            case WM_MBUTTONDBLCLK: io.MouseDown[2] = true; break;
            case WM_XBUTTONDOWN:
            case WM_XBUTTONDBLCLK: io.MouseDown[GET_XBUTTON_WPARAM(message.wParam) == XBUTTON1 ? 3 : 4] = true; break;
            case WM_LBUTTONUP: io.MouseDown[0] = false; break;
            case WM_RBUTTONUP: io.MouseDown[1] = false; break;
            case WM_MBUTTONUP: io.MouseDown[2] = false; break;
            case WM_XBUTTONUP: io.MouseDown[GET_XBUTTON_WPARAM(message.wParam) == XBUTTON1 ? 3 : 4] = false; break;
            case WM_MOUSEWHEEL: io.MouseWheel += static_cast<float>(GET_WHEEL_DELTA_WPARAM(message.wParam)) / WHEEL_DELTA; break;
            case WM_MOUSEHWHEEL: io.MouseWheelH += static_cast<float>(GET_WHEEL_DELTA_WPARAM(message.wParam)) / WHEEL_DELTA; break;
            case WM_KEYDOWN:
            case WM_SYSKEYDOWN:
                if (message.wParam < 256) io.KeysDown[message.wParam] = true;
                break;
            case WM_KEYUP:
            case WM_SYSKEYUP:
                if (message.wParam < 256) io.KeysDown[message.wParam] = false;
                break;
            case WM_CHAR: io.AddInputCharacter(static_cast<unsigned int>(message.wParam)); break;
            }
        }
    }
}

bool init = false;
HRESULT __stdcall hkResizeBuffers(IDXGISwapChain* swapChain, UINT bufferCount, UINT width, UINT height, DXGI_FORMAT format, UINT flags)
{
	Runtime::CallbackGuard callback;
	std::unique_lock rendererLock(rendererMutex);
	if (Runtime::IsShuttingDown() || !init || swapChain != activeSwapChain)
		return oResizeBuffers(swapChain, bufferCount, width, height, format, flags);

	backendGeneration.onBeforeResize();
	ReleaseCom(mainRenderTargetView);
	const HRESULT result = oResizeBuffers(swapChain, bufferCount, width, height, format, flags);
	if (FAILED(result) || !pDevice)
		return result;

	ID3D11Texture2D* backBuffer = nullptr;
	if (SUCCEEDED(swapChain->GetBuffer(0, __uuidof(ID3D11Texture2D), reinterpret_cast<void**>(&backBuffer))))
		pDevice->CreateRenderTargetView(backBuffer, nullptr, &mainRenderTargetView);
	ReleaseCom(backBuffer);
	if (mainRenderTargetView)
		backendGeneration.onResourcesCreated();
	return result;
}

HRESULT __stdcall hkPresent(IDXGISwapChain* pSwapChain, UINT SyncInterval, UINT Flags)
{
	Runtime::CallbackGuard callback;
	std::unique_lock rendererLock(rendererMutex);
	if (Runtime::IsShuttingDown() || Runtime::ShouldUnload())
		return oPresent(pSwapChain, SyncInterval, Flags);

	if (!init)
    {
        ID3D11Device* device = nullptr;
        ID3D11DeviceContext* context = nullptr;
        ID3D11Texture2D* backBuffer = nullptr;
        ID3D11RenderTargetView* renderTarget = nullptr;
        DXGI_SWAP_CHAIN_DESC description{};

        if (FAILED(pSwapChain->GetDevice(__uuidof(ID3D11Device), reinterpret_cast<void**>(&device))))
            return oPresent(pSwapChain, SyncInterval, Flags);

        Runtime::SetLifecycleState(Runtime::LifecycleState::InitializingRenderer);
        device->GetImmediateContext(&context);
        const bool rendererReady = context != nullptr
            && SUCCEEDED(pSwapChain->GetDesc(&description))
            && description.OutputWindow != nullptr
            && SUCCEEDED(pSwapChain->GetBuffer(0, __uuidof(ID3D11Texture2D), reinterpret_cast<void**>(&backBuffer)))
            && SUCCEEDED(device->CreateRenderTargetView(backBuffer, nullptr, &renderTarget));

        ReleaseCom(backBuffer);
        if (!rendererReady)
        {
            ReleaseCom(renderTarget);
            ReleaseCom(context);
            ReleaseCom(device);
            Runtime::SetError(Runtime::LifecycleError::RendererResourceInitializationFailed);
            Runtime::RequestUnload();
            return oPresent(pSwapChain, SyncInterval, Flags);
        }

        pDevice = device;
        pContext = context;
        mainRenderTargetView = renderTarget;
        window = description.OutputWindow;
		activeSwapChain = pSwapChain;
		backendGeneration.onResourcesCreated();
        init = true;

        if (!templeWare.init(window, pDevice, pContext, mainRenderTargetView))
        {
			backendGeneration.onBeforeResize();
			ReleaseCom(mainRenderTargetView);
			ReleaseCom(pContext);
			ReleaseCom(pDevice);
			activeSwapChain = nullptr;
			window = nullptr;
			init = false;
            Runtime::SetError(Runtime::LifecycleError::ComponentInitializationFailed);
            Runtime::RequestUnload();
            return oPresent(pSwapChain, SyncInterval, Flags);
        }
        if (!InstallWindowSubclass())
        {
            Runtime::SetError(Runtime::LifecycleError::WindowSubclassInstallFailed);
            Runtime::RequestUnload();
            return oPresent(pSwapChain, SyncInterval, Flags);
        }
        if (!Runtime::ShouldUnload())
            Runtime::SetLifecycleState(Runtime::LifecycleState::Active);
    }
	else if (pSwapChain != activeSwapChain)
	{
		return oPresent(pSwapChain, SyncInterval, Flags);
	}

	if (!mainRenderTargetView)
	{
		ID3D11Texture2D* backBuffer = nullptr;
		if (FAILED(pSwapChain->GetBuffer(0, __uuidof(ID3D11Texture2D), reinterpret_cast<void**>(&backBuffer))))
			return oPresent(pSwapChain, SyncInterval, Flags);
		pDevice->CreateRenderTargetView(backBuffer, nullptr, &mainRenderTargetView);
		ReleaseCom(backBuffer);
		if (!mainRenderTargetView)
			return oPresent(pSwapChain, SyncInterval, Flags);
		backendGeneration.onResourcesCreated();
	}

    ImFontConfig imIconsConfig;
    imIconsConfig.RasterizerMultiply = 1.2f;

    constexpr ImWchar wIconRanges[] =
    {
        0xE000, 0xF8FF, // Private Use Area
        0
    };

    ProcessWindowMessages();
    ImGui_ImplDX11_NewFrame();
    ImGui_ImplWin32_NewFrame();
    ImGui::NewFrame();

    if (GetAsyncKeyState(VK_END) & 1) {
        templeWare.renderer.menu.toggleMenu();
    }

    templeWare.renderer.menu.render();
    (void)internal_config::ConfigManager::PublishCurrent();
	const ImVec2 displaySize = ImGui::GetIO().DisplaySize;
	templeWare.renderer.visuals.buildFrame(displaySize.x, displaySize.y, backendGeneration.current());
	tw::renderer::submitImGui(*templeWare.renderer.visuals.frame());
    templeWare.renderer.hud.render();

    templeWare.renderer.specList.OnRender();

    ImGui::Render();
    pContext->OMSetRenderTargets(1, &mainRenderTargetView, NULL);
    ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());
    return oPresent(pSwapChain, SyncInterval, Flags);
}

void init_console() {
    if (::AllocConsole()) {
        consoleAllocated = true;
        freopen_s(&consoleOutput, "CONOUT$", "w", stdout);  // Redirect stdout to console
        freopen_s(&consoleError, "CONOUT$", "w", stderr);  // Redirect stderr to console
        ::SetConsoleTitleW(L"dork.cat");

        HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);

        SetConsoleTextAttribute(hConsole, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);

        printf("[");
        SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | FOREGROUND_INTENSITY);
        printf("+");
        SetConsoleTextAttribute(hConsole, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
        printf("] dork.cat\n");
    }
}

void shutdown_console()
{
    if (!consoleAllocated)
        return;

    fflush(stdout);
    fflush(stderr);

    if (consoleOutput != nullptr)
    {
        fclose(consoleOutput);
        consoleOutput = nullptr;
    }
    if (consoleError != nullptr)
    {
        fclose(consoleError);
        consoleError = nullptr;
    }

    if (const HWND consoleWindow = GetConsoleWindow(); consoleWindow != nullptr)
        ShowWindow(consoleWindow, SW_HIDE);

    SetStdHandle(STD_OUTPUT_HANDLE, INVALID_HANDLE_VALUE);
    SetStdHandle(STD_ERROR_HANDLE, INVALID_HANDLE_VALUE);
    FreeConsole();
    consoleAllocated = false;
}

namespace
{
	struct UnloadContext
	{
		HMODULE module;
		HANDLE workerThread;
	};

	[[noreturn]] void ReleaseModuleAndExit(HMODULE module)
	{
		MEMORY_BASIC_INFORMATION memoryInfo{};
		const bool privateImage = VirtualQuery(module, &memoryInfo, sizeof(memoryInfo)) == sizeof(memoryInfo)
			&& memoryInfo.AllocationBase == module
			&& memoryInfo.Type == MEM_PRIVATE;

#ifdef _WIN64
		if (privateImage)
		{
			const HMODULE kernel32 = GetModuleHandleW(L"kernel32.dll");
			const auto virtualFree = GetProcAddress(kernel32, "VirtualFree");
			const auto exitThread = GetProcAddress(kernel32, "ExitThread");
			const auto closeHandle = GetProcAddress(kernel32, "CloseHandle");

			unsigned char code[] = {
				0x48, 0x83, 0xEC, 0x28,
				0x48, 0xB9, 0, 0, 0, 0, 0, 0, 0, 0,
				0x31, 0xD2,
				0x41, 0xB8, 0x00, 0x80, 0x00, 0x00,
				0x48, 0xB8, 0, 0, 0, 0, 0, 0, 0, 0,
				0xFF, 0xD0,
				0x85, 0xC0,
				0x74, 0x25,
				0x48, 0xB9, 0, 0, 0, 0, 0, 0, 0, 0,
				0x48, 0xB8, 0, 0, 0, 0, 0, 0, 0, 0,
				0xFF, 0xD0,
				0x31, 0xC9,
				0x48, 0xB8, 0, 0, 0, 0, 0, 0, 0, 0,
				0xFF, 0xD0,
				0xCC,
				0x48, 0x83, 0xC4, 0x28,
				0xC3
			};

			void* releaseStub = VirtualAlloc(nullptr, sizeof(code), MEM_RESERVE | MEM_COMMIT, PAGE_EXECUTE_READWRITE);
			if (virtualFree != nullptr && exitThread != nullptr && closeHandle != nullptr && releaseStub != nullptr)
			{
				const auto writeAddress = [&code](std::size_t offset, const void* address)
				{
					const auto value = reinterpret_cast<std::uintptr_t>(address);
					std::memcpy(code + offset, &value, sizeof(value));
				};

				writeAddress(6, module);
				writeAddress(24, reinterpret_cast<void*>(virtualFree));
				writeAddress(40, Runtime::singletonHandle);
				writeAddress(50, reinterpret_cast<void*>(closeHandle));
				writeAddress(64, reinterpret_cast<void*>(exitThread));
				std::memcpy(releaseStub, code, sizeof(code));
				FlushInstructionCache(GetCurrentProcess(), releaseStub, sizeof(code));

				reinterpret_cast<void(*)()>(releaseStub)();
			}

			if (releaseStub != nullptr)
				VirtualFree(releaseStub, 0, MEM_RELEASE);
			Runtime::Fail(Runtime::LifecycleError::ManualMapReleaseFailed);
			ExitThread(EXIT_FAILURE);
		}
#endif

		FreeLibraryAndExitThread(module, EXIT_SUCCESS);
	}

	DWORD WINAPI FinalizeUnload(LPVOID parameter)
	{
		const UnloadContext context = *static_cast<UnloadContext*>(parameter);
		HeapFree(GetProcessHeap(), 0, parameter);

		const DWORD waitResult = WaitForSingleObject(context.workerThread, INFINITE);
		CloseHandle(context.workerThread);
		if (waitResult != WAIT_OBJECT_0)
		{
			Runtime::Fail(Runtime::LifecycleError::FinalizerWaitFailed);
			return EXIT_FAILURE;
		}

		Runtime::Shutdown();
		ReleaseModuleAndExit(context.module);
	}

	bool StartUnloadFinalizer(HMODULE module)
	{
		HANDLE workerThread = nullptr;
		if (!DuplicateHandle(GetCurrentProcess(), GetCurrentThread(), GetCurrentProcess(), &workerThread,
			SYNCHRONIZE, FALSE, 0))
		{
			return false;
		}

		auto* context = static_cast<UnloadContext*>(HeapAlloc(GetProcessHeap(), 0, sizeof(UnloadContext)));
		if (context == nullptr)
		{
			CloseHandle(workerThread);
			return false;
		}

		context->module = module;
		context->workerThread = workerThread;

		const HANDLE finalizerThread = CreateThread(nullptr, 0, FinalizeUnload, context, 0, nullptr);
		if (finalizerThread == nullptr)
		{
			HeapFree(GetProcessHeap(), 0, context);
			CloseHandle(workerThread);
			return false;
		}

		CloseHandle(finalizerThread);
		return true;
	}

	bool ShutdownHooksAndRenderer()
	{
		Runtime::BeginShutdown();
		Runtime::SetLifecycleState(Runtime::LifecycleState::DetachingCallbacks);
		const auto hookDetached = [](const kiero::Status::Enum status)
		{
			return status == kiero::Status::Success || status == kiero::Status::NotInitializedError;
		};

		tw::model_preview::requestCleanup();
		(void)tw::model_preview::waitForCleanup(500);
		const bool previewHooksDisabled = tw::model_preview::disableHooks();
		const bool featureHooksDisabled = templeWare.hooks.disable();
		const bool presentDisabled = hookDetached(kiero::unbind(8));
		const bool resizeDisabled = hookDetached(kiero::unbind(13));
		if (!previewHooksDisabled || !featureHooksDisabled || !presentDisabled || !resizeDisabled)
		{
			Runtime::Fail(Runtime::LifecycleError::InitialHookDisableFailed);
			return false;
		}

		std::unique_lock rendererLock(rendererMutex, std::defer_lock);
		if (!rendererLock.try_lock_for(std::chrono::seconds(5)))
		{
			Runtime::Fail(Runtime::LifecycleError::RendererLockTimeout);
			return false;
		}

		const bool featureHooksStillDisabled = templeWare.hooks.disable();
		const bool presentStillDisabled = hookDetached(kiero::unbind(8));
		const bool resizeStillDisabled = hookDetached(kiero::unbind(13));
		if (!featureHooksStillDisabled || !presentStillDisabled || !resizeStillDisabled)
		{
			Runtime::Fail(Runtime::LifecycleError::FinalHookDisableFailed);
			return false;
		}

		if (!RemoveWindowSubclassFromOwnerThread())
			return false;

		Runtime::SealCallbackGate();
		rendererLock.unlock();
		Runtime::SetLifecycleState(Runtime::LifecycleState::DrainingCallbacks);

		if (Runtime::WaitForCallbacks() != WAIT_OBJECT_0)
		{
			Runtime::Fail(Runtime::LifecycleError::CallbackDrainFailed);
			return false;
		}

		Runtime::SetLifecycleState(Runtime::LifecycleState::RestoringGameState);
		H::RestoreWorldState();
		H::RestoreLevelState();

		// Drop the game-event registration before anything else is torn down.
		// CGameEventManager holds a raw pointer to our listener; leaving it
		// registered past unload means the next dispatch calls freed memory.
		tw::events::shutdown();

		if (!templeWare.hooks.shutdown())
		{
			Runtime::Fail(Runtime::LifecycleError::HookRemovalFailed);
			return false;
		}
		if (!tw::model_preview::shutdown())
		{
			Runtime::Fail(Runtime::LifecycleError::HookRemovalFailed);
			return false;
		}

		g_entitySystem->level_shutdown();
		Esp::clear_cache();
		g_spectatorlist->Clear();
		g_ctx->user_cmd = nullptr;
		g_ctx->local_pawn = nullptr;
		g_ctx->local_controller = nullptr;

		Runtime::SetLifecycleState(Runtime::LifecycleState::ReleasingResources);

		{
			std::scoped_lock lock(windowMessageMutex);
			windowMessages.clear();
		}
		const HWND renderWindow = window;
		templeWare.renderer.menu.shutdown();
		if (renderWindow != nullptr && GetCapture() == renderWindow)
			ReleaseCapture();
		window = nullptr;
		windowThreadId = 0;

		backendGeneration.onBeforeResize();
		ReleaseCom(mainRenderTargetView);
		ReleaseCom(pContext);
		ReleaseCom(pDevice);
		activeSwapChain = nullptr;
		init = false;

		kiero::shutdown();
		const MH_STATUS uninitializeStatus = MH_Uninitialize();

		if (uninitializeStatus != MH_OK && uninitializeStatus != MH_ERROR_NOT_INITIALIZED)
		{
			Runtime::Fail(Runtime::LifecycleError::MinHookUninitializeFailed);
			return false;
		}

		Runtime::SetLifecycleState(Runtime::LifecycleState::Stopped);
		return true;
	}
}

DWORD WINAPI MainThread(LPVOID lpReserved)
{
	if (!Runtime::Initialize())
		ReleaseModuleAndExit(reinterpret_cast<HMODULE>(lpReserved));

	subclassControlMessage = RegisterWindowMessageW(L"TempleWare.SubclassControl.1");
	if (subclassControlMessage == 0)
	{
		Runtime::SetError(Runtime::LifecycleError::WindowMessageRegistrationFailed);
		Runtime::Shutdown();
		ReleaseModuleAndExit(reinterpret_cast<HMODULE>(lpReserved));
	}

	init_console();
	bool init_hook = false;
	while (!Runtime::ShouldUnload())
	{
		if (!init_hook && kiero::init(kiero::RenderType::D3D11) == kiero::Status::Success)
		{
			const bool resizeBound = kiero::bind(13, reinterpret_cast<void**>(&oResizeBuffers), hkResizeBuffers) == kiero::Status::Success;
			init_hook = resizeBound && kiero::bind(8, reinterpret_cast<void**>(&oPresent), hkPresent) == kiero::Status::Success;
			if (!init_hook)
			{
				if (resizeBound)
					kiero::unbind(13);
				Runtime::SetError(Runtime::LifecycleError::PresentHookInitializationFailed);
				Runtime::RequestUnload();
			}
		}

		if (GetAsyncKeyState(VK_F4) & 1)
		{
			tw::model_preview::requestCleanup();
			(void)tw::model_preview::waitForCleanup(500);
			Runtime::RequestUnload();
		}
		else
			Runtime::WaitForUnload(50);
	}

	const bool shutdownSucceeded = ShutdownHooksAndRenderer();
	shutdown_console();
	if (!shutdownSucceeded)
		return EXIT_FAILURE;

	if (!StartUnloadFinalizer(reinterpret_cast<HMODULE>(lpReserved)))
	{
		Runtime::Fail(Runtime::LifecycleError::FinalizerCreationFailed);
		return EXIT_FAILURE;
	}

	return EXIT_SUCCESS;
}

extern "C" __declspec(dllexport) DWORD WINAPI TempleWareRequestStop(LPVOID)
{
	tw::model_preview::requestCleanup();
	(void)tw::model_preview::waitForCleanup(500);
	Runtime::RequestUnload();
	return ERROR_SUCCESS;
}

extern "C" __declspec(dllexport) unsigned char WINAPI TempleWareGetLifecycleState()
{
	return static_cast<unsigned char>(Runtime::GetLifecycleState());
}

extern "C" __declspec(dllexport) unsigned char WINAPI TempleWareGetLifecycleError()
{
	return static_cast<unsigned char>(Runtime::GetLifecycleError());
}

BOOL WINAPI DllMain(HMODULE hMod, DWORD dwReason, LPVOID lpReserved)
{
    switch (dwReason)
    {
	case DLL_PROCESS_ATTACH:
		DisableThreadLibraryCalls(hMod);
		if (const HANDLE mainThread = CreateThread(nullptr, 0, MainThread, hMod, 0, nullptr); mainThread != nullptr)
			CloseHandle(mainThread);
		else
			Runtime::Fail(Runtime::LifecycleError::WorkerThreadCreationFailed);
		break;
	case DLL_PROCESS_DETACH:
		Runtime::ReleaseSingleton();
		break;
    }
    return TRUE;
}
