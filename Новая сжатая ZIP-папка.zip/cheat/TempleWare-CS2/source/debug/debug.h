#pragma once

void initDebug();